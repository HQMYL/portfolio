<!doctype html>
<html>

<body>
<?php 
include("inc/conexion.php");
if (isset($_GET['id'])) {
	$id = $_GET['id'];
}

$sql = "DELETE FROM articulos WHERE id=:id";
$stmt = $con->prepare($sql);
$stmt->bindParam(':id', $id, PDO::PARAM_STR); 
$stmt->execute();

?>
<script>
alert('El articulo a sido Eliminado exitosamaente');
window.location.href='users.php';
</script>
</body>
</html>
