<!DOCTYPE HTML>
<html>
<body>
<?php
if (isset($_POST["nombre"])) {
$nombre = $_POST["nombre"];	
}


if (isset($_POST["correo"])) {
$correo = $_POST["correo"];	
}
if (isset($_POST["asunto"])) {
$asunto = $_POST["asunto"];	
}
if (isset($_POST["mensaje"])) {
$msj = $_POST["mensaje"];	
}


$para = 'ventas@goprint.pe';
$titulo = $asunto;
$mensaje = 'Hola, la Persona:' . $nombre . ' Te ha enviado la siguiente consulta : ' .$msj;
$cabeceras = 'From: ' . $correo .  "\r\n" .

 //La direccion de correo desde donde supuestamente se envió
    'Reply-To: ' . $correo  . "\r\n" . //La direccion de correo a donde se responderá (cuando el recepto haga click en RESPONDER)
    'X-Mailer: PHP/' . phpversion();  //información sobre el sistema de envio de correos, en este caso la version de PHP
 
mail($para, $titulo, $mensaje, $cabeceras);
?>
<script>
alert('El mensaje ha sido enviado correctamente');
window.location.href='contactenos2.php';
</script>

</body>
</html>