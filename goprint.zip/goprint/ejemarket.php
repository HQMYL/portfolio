<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <!-- Main jumbotron for a primary marketing message or call to action -->
    <?php 
     include('includes/funciones.php');
     include('includes/header.php');
     include('includes/conexion.php');
    ?>
    
    <body>
      <hr>
    <div class="jumbotron">
      <div class="container">
        <h1>BIENVENIDOS A NUESTRA APLICACIÓN</h1>
        <p>.</p>
        <p></p>
      </div>
    </div>
    <!-- Destacados -->
    <hr>
    <div class="container">
      <div class="row">
      <?php 
      

         $sql = "SELECT sku, img, nombre, descripcion FROM ofertas";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
foreach ($rows as $row) {
    echo portada($row);
}

    
 ?>
        
        
      </div>

      <hr>

      
    </div> <!-- Destacados -->
    <?php
include('includes/footer.php');
?>    
    </body>
</html>