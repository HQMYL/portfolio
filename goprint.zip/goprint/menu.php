<!DOCTYPE HTML>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="GoPrint, Servicio de Impresión en Perú">
    <meta name="author" content="GoPrint">
    <link rel="shortcut icon" href="favicon.html">

    <title>GoPrint: De la imprenta a tus manos.</title>
    
    <link href="bootstrap3/css/bootstrap.css" rel="stylesheet">

    <!-- main css -->
    <link href="css/master.css" rel="stylesheet">
    
    <!-- mobile css -->
    <link href="css/responsive.css" rel="stylesheet">
    
    <!-- FontAwesome Support -->
    <link rel="stylesheet" type="text/css" href="css/fontawesome/font-awesome.min.css" />
    <!-- FontAwesome Support -->
    
    <!-- Superfish menu -->
    <link rel="stylesheet" type="text/css" href="css/superfish/superfish.css" />
    <!-- Superfish menu -->
    
    <!-- Theme Color selector -->
    <link href="js/theme-color-selector/theme-color-selector.css" type="text/css" rel="stylesheet">
    <!-- Theme Color selector -->
    
    <!-- Owl Carousel -->
    <link rel="stylesheet" type="text/css" href="js/owl-carousel/owl.carousel.css" />
    <!-- Owl Carousel -->
    
    <!-- Typicons -->
    <link rel="stylesheet" type="text/css" href="css/typicons/typicons.min.css" />
    <!-- Typicons -->
    
    <!-- WOW animations -->
    <link rel="stylesheet" type="text/css" href="js/wow/css/libs/animate.css" />
    <!-- WOW animations -->
    
    <!-- MeanMenu (mobile) -->
    <link rel="stylesheet" type="text/css" href="js/meanmenu/meanmenu.css" />
    <!-- MeanMenu (mobile) -->
    
    <!-- Flexslider -->
    <link rel="stylesheet" type="text/css" href="js/flexslider/flexslider-post.css" />
    <!-- Flexslider -->
    
    <!-- PrettyPhoto -->
    <link rel="stylesheet" type="text/css" href="js/prettyphoto/css/prettyPhoto.css" />
    <!-- PrettyPhoto -->
    
    <!-- jQuery UI -->
    <link rel="stylesheet" type="text/css" href="css/jquery-ui/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="css/nuevo.css" />
    <!-- jQuery UI -->
        
    <!-- Development Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300italic,300,400italic,600,600italic,700,700italic,800,800italic%7COpen+Sans+Condensed:300,300italic,700%7CRaleway:400,200,300,100,600,500,700,800,900%7COswald:400,300,700%7CRoboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic%7CRoboto+Condensed:400,300,300italic,400italic,700,700italic%7CRoboto+Slab:400,100,300,700%7CLato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <!-- Development Google Fonts -->
    
  </head>


<div class="pm-nav-container">
        
            <div class="container">
            
                <div class="row">
                    
                    <div class="col-lg-8 col-md-8 col-sm-12">
                        
                        <nav class="navbar-collapse collapse" id="pm-main-navigation">
                        
                            <ul class="sf-menu pm-nav">
                        
                                <li><a href="index.php" class="fa fa-home" id="pm-home-btn"></a></li>
                                <li>
                                    <a href="index.php">Inicio</a>
                                </li>
                                
                                <li><a href="servicios.html" style="color: black;">Servicios</a></li>
                                <li><a href="blog.php" style="color: black;">Blog</a></li>
                                <li><a href="registro.html" style="color: black;">Registrarse</a></li>
                                
                                <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="">
                            <img alt="" src="img/avatar1_small.jpg">
                            </span>
                        <span style="color: black;" class=""> <?php echo " Bienvenido: " . $user; ?> </span>
                            
                        </a>
                        <ul class="dropdown-menu extended logout">
                        
                            
                            <li>
                                <a href="logout.php"><i style="color: black;" class="icon_key_alt"></i> Cerrar Sesión</a>
                            </li>
                            
                            
                            </ul>



                        
                                
                                <li><a href="contactenos.html" style="color: black;">Contactenos</a></li>
                            
                            </ul>
                        
                        </nav> 
                    
                    </div>
                    
                    <div class="col-lg-4 col-md-4 col-sm-12 pm-main-menu">
                                        
                        <ul class="pm-cart-info">
                            <li><p><strong>Comunícate con nosotros al:</strong></p></li>
                            <li><p>976048631</p></li>
                        </ul>
                                              
                    </div>
                    
                </div>
            
            </div>
        
        </div>
        </body>
</html>