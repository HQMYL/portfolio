<?php
include("inc/conexion.php");
if (isset($_POST['nombre'])) {
	$nombre = $_POST['nombre'];
}

if (isset($_POST['apellido'])) {
	$nombre = $_POST['apellido'];
}

if (isset($_POST['ciudad'])) {
	$ciudad = $_POST['ciudad'];
}

if (isset($_POST['direccion'])) {
	$direccion = $_POST['direccion'];
}

if (isset($_POST['celular'])) {
	$celular = $_POST['celular'];
	
}

$dir_subida = 'uploads';
$fichero_subido = $dir_subida . basename($_FILES['fichero_usuario']['name']);

echo '<pre>';
if (move_uploaded_file($_FILES['fichero_usuario']['uploads'], $fichero_subido)) {
    echo "El fichero es válido y se subió con éxito.\n";
} else {
    echo "¡Posible ataque de subida de ficheros!\n";
}

echo 'Más información de depuración:';
print_r($_FILES);

print "</pre>";

?> 






?>
