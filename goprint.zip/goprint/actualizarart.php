<!doctype html>
<html>
<head></head>
<body>
<?php
include("inc/conexion.php");

if (isset($_POST["id"])) {
$id = $_POST["id"];
}

if (isset($_POST["titulo"])) {
$titulo = $_POST["titulo"];
}


if (isset($_POST["autor"])) {
	$autor = $_POST["autor"];
}

if (isset($_POST["intro"])) {
	$intro = $_POST["intro"];
}

if (isset($_POST["descripcion"])) {
	$descripcion = $_POST["descripcion"];
}
	


if( $titulo == $row->titulo) {

$sql2 = " UPDATE articulos SET autor =:autor, introdescripcion =:intro, descripcion =:descripcion WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':autor', $autor, PDO::PARAM_STR); 
$stmt2->bindParam(':intro', $intro, PDO::PARAM_STR);
$stmt2->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);
$stmt2->execute();

}

if( $autor == $row->autor) {

$sql2 = " UPDATE articulos SET titulo =:titulo, introdescripcion =:intro, descripcion =:descripcion WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':titulo', $titulo, PDO::PARAM_STR); 
$stmt2->bindParam(':intro', $intro, PDO::PARAM_STR);
$stmt2->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);
$stmt2->execute();

}


if( $intro == $row->introdescripcion) {

$sql2 = " UPDATE articulos SET titulo =:titulo, autor =:autor, descripcion =:descripcion WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':titulo', $titulo, PDO::PARAM_STR); 
$stmt2->bindParam(':autor', $autor, PDO::PARAM_STR);
$stmt2->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);
$stmt2->execute();

}

if( $descripcion == $row->descripcion) {

$sql2 = " UPDATE articulos SET titulo =:titulo, autor =:autor, introdescripcion =:intro WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':titulo', $titulo, PDO::PARAM_STR); 
$stmt2->bindParam(':autor', $autor, PDO::PARAM_STR);
$stmt2->bindParam(':intro', $intro, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);
$stmt2->execute();

}


if( ( $titulo == $row->titulo)  AND ($autor == $row->autor) ) {

$sql2 = " UPDATE articulos SET introdescripcion =:intro,  descripcion =:descripcion  WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':intro', $intro, PDO::PARAM_STR);
$stmt2->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $intro == $row->introdescripcion)  AND ($descripcion == $row->descripcion) ) {

$sql2 = " UPDATE articulos SET autor =:autor, titulo =:titulo WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':autor', $autor, PDO::PARAM_STR);
$stmt2->bindParam(':titulo', $titulo, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $titulo == $row->titulo)  AND ($descripcion == $row->descripcion) ) {

$sql2 = " UPDATE articulos SET autor =:autor, introdescripcion =:intro WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':autor', $autor, PDO::PARAM_STR);
$stmt2->bindParam(':intro', $intro, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $autor == $row->autor)  AND ($intro == $row->introdescripcion) ) {

$sql2 = " UPDATE articulos SET titulo =:titulo, descripcion =:descripcion WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':titulo', $titulo, PDO::PARAM_STR);
$stmt2->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);
$stmt2->execute();

}




?>
<script>
alert('El articulo a sido actualizado exitosamaente');
window.location.href='users.php';
</script>
</body>
</html>