<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <!-- Main jumbotron for a primary marketing message or call to action -->
    <?php 
     include('includes/funciones.php');
     include('includes/header.php');
         
     ?>
    <body>
    <div class="jumbotron">
      <div class="container">
        <h1>Bienvenidos a nuestra sección de Ofertas</h1>
        <p>This is a template for a simple marketing or informational website. It includes a large callout called a jumbotron and three supporting pieces of content. Use it as a starting point to create something more unique.</p>
        <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more &raquo;</a></p>
      </div>
    </div>
    <!-- Ofertas -->
    <div class="container">
      <div class="row">
      <?php 
      foreach ($ofertas as $oferta_id => $oferta) { 
          
    echo portada($oferta_id, $oferta);
         }   
          
         

   ?>
        
        
      </div>

      <hr>

      
    </div> <!-- Ofertas -->

    
    </body>
</html>
