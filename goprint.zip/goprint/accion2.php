<!DOCTYPE HTML>
<html>
<?php
include("inc/conexion.php");
?>
<body>
<?php
if (isset($_POST["id"])) {
	$buscar = $_POST["id"];
}

if (isset($_POST["titulo"])) {
	$titulo = $_POST["titulo"];
}



if (isset($_POST["autor"])) {
	$autor = $_POST["autor"];
}

if (isset($_POST["mensaje"])) {
	$mensaje = $_POST["mensaje"];
}





$sql = " SELECT * FROM articulos WHERE id = '" .$buscar. "'";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
foreach ($rows as $row) {

if ( ($titulo == $row->Titulo)  AND ($autor == $row->autor)  ){

$sql2 = " UPDATE articulos SET descripcion =:mensaje WHERE id =:buscar ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':mensaje', $mensaje, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

if ( ($autor == $row->autor)  AND ($mensaje == $row->descripcion)  ){

$sql2 = " UPDATE articulos SET titulo =:titulo WHERE id =:buscar ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':titulo', $titulo, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

if ( ($titulo == $row->titulo)  AND ($mensaje == $row->descripcion)  ){

$sql2 = " UPDATE articulos SET autor =:autor WHERE id =:buscar ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':autor', $autor, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

}



?>
<script>
	alert('El articulo a sido actualizado exitosamaente');
window.location.href='blog1.php';


</script>
</body>
</html>