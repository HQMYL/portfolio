<!DOCTYPE HTML>
<html>
<?php
include("inc/conexion.php");
?>
<body>
<?php
if (isset($_POST["nombre"])) {
	$nombre = $_POST["nombre"];
}
if (isset($_POST["correo"])) {
	$correo = $_POST["correo"];
}

if (isset($_POST["usuario"])) {
	$usuario = $_POST["usuario"];
}



if (isset($_POST["pass"])) {
	$pass = $_POST["pass"];
}







$sql = " SELECT * FROM usuarios WHERE nombre = '" .$nombre. "'";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
foreach ($rows as $row) {

if( ( $correo == $row->correo)  AND ($usuario == $row->usuario) ) {

$sql2 = " UPDATE usuarios SET contrasena =:pass WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':pass', $pass, PDO::PARAM_STR); 
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $correo == $row->correo)  AND ($pass == $row->contrasena) ) {

$sql2 = " UPDATE usuarios SET usuario =:usuario WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
 $stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR); 
$stmt2->execute();

}

if (( $usuario == $row->usuario)  AND ($pass == $row->contrasena)) {

$sql2 = " UPDATE usuarios SET correo =:correo WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( $correo == $row->correo) {

$sql2 = " UPDATE usuarios SET contrasena =:pass, usuario =:usuario WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':pass', $pass, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( $usuario == $row->usuario) {

$sql2 = " UPDATE usuarios SET contrasena =:pass, correo =:correo WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':pass', $pass, PDO::PARAM_STR); 
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( $pass == $row->contrasena) {

$sql2 = " UPDATE usuarios SET usuario =:usuario, correo =:correo WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR); 
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}


}



?>
<script>
	alert('El usuario a sido actualizado exitosamaente');
window.location.href='users.php';


</script>
</body>
</html>