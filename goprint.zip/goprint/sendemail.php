<?php
	
    $name = @trim(stripslashes($_POST['nombre'])); 
    $email = @trim(stripslashes($_POST['correo'])); 
    $subject = @trim(stripslashes($_POST['asunto'])); 
    $message = @trim(stripslashes($_POST['mensaje']));

    if (isset($_POST['phone'])) {
        
        $phone = @trim(stripslashes($_POST['phone'])); 
     }else{
        $phone="Sin telefono";
     }
     if (isset($_POST['empresa'])) {
        
        $empresa = @trim(stripslashes($_POST['empresa'])); 
     }else{
        $empresa="Sin nombre de empresa";
     }

    $email_from = $email;
    $email_to = 'hqmus@hotmail.com';

    $body = 'Nombre: ' . $name . "\n\n" . 'Email: ' . $email . "\n\n" . 'Asunto: ' . $subject . "\n\n" . 'Telefono:' . $phone . "\n\n" . 'Empresa:' . $empresa . " \n\n" . 'Mensaje: '. "\n\n" . $message;

   
    if (mail($email_to, $subject, $body, 'De: <'.$email_from.'>')) {
        
        echo "El Mensaje ha sido enviado con exito, le contactaremos.";
        die;
    }
    

    ?>
    