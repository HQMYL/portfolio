<!DOCTYPE HTML>
<html>
<body>

<?php 
include("inc/conexion.php");

if(isset($_POST["titulo"])) {
	$titulo = $_POST["titulo"];
}
if(isset($_POST["fecha"])) {
   $fecha = $_POST["fecha"];
}

if(isset($_POST["autor"])) {
   $autor = $_POST["autor"];
}

if(isset($_POST["descripcion"])) {
	$descripcion = $_POST["descripcion"];
}






$nombre_img = $_FILES['archivo']['name'];
$tipo = $_FILES['archivo']['type'];
$tamano = $_FILES['archivo']['size'];
 
//Si existe imagen y tiene un tamaño correcto
if (($nombre_img == !NULL) && ($_FILES['archivo']['size'] <= 800000)) 
{
   //indicamos los formatos que permitimos subir a nuestro servidor
   if (($_FILES["archivo"]["type"] == "image/gif")
   || ($_FILES["archivo"]["type"] == "image/jpeg")
   || ($_FILES["archivo"]["type"] == "image/jpg")
   || ($_FILES["archivo"]["type"] == "image/png"))
   
      // Ruta donde se guardarán las imágenes que subamos
      $directorio = "./img/";
      // Muevo la imagen desde el directorio temporal a nuestra ruta indicada anteriormente
      move_uploaded_file($_FILES['archivo']['tmp_name'],$directorio.$nombre_img);
      $nombre_img = $directorio.$nombre_img;
      
$sql = "INSERT INTO articulos (titulo, introdescripcion, descripcion, autor, fecha, img) VALUES (:titulo, :breve, :descripcion, :autor, :fecha, :nombre_img)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':titulo', $titulo, PDO::PARAM_STR); 
$stmt->bindParam(':breve', $breve, PDO::PARAM_STR);
$stmt->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
$stmt->bindParam(':autor', $autor, PDO::PARAM_STR);
$stmt->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt->bindParam(':nombre_img', $nombre_img, PDO::PARAM_STR);

 $stmt->execute();
 } 

?>

<script>
alert('El articulo a sido agregado exitosamaente');
window.location.href='blog2.php';
</script>
</body>
</html>