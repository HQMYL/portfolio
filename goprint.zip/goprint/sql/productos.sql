-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 17-02-2017 a las 05:41:18
-- Versión del servidor: 5.5.24-log
-- Versión de PHP: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `goprint`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE IF NOT EXISTS `productos` (
  `nombreProd` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `stock` int(10) NOT NULL,
  `precio` float NOT NULL,
  `img` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`nombreProd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`nombreProd`, `descripcion`, `stock`, `precio`, `img`) VALUES
('Acabado Brillan', 'Tarjeta personal brillant', 56, 50, 'img/store/brillante.png'),
('Acabado Mate', 'Acabado muy profesional', 45, 60, 'img/store/mate.png'),
('Delivery', 'Entregas a todo el pais', 100, 0, 'img/store/delivery.png'),
('Item1', 'Silla', 78, 45, 'img/store/item1.jpg'),
('Volantes', 'producto novedoso', 87, 65, 'img/store/volante.png');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
