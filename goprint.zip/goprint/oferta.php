<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <!-- Main jumbotron for a primary marketing message or call to action -->
    <?php 
     include('includes/funciones.php');
     include('includes/header.php');
     include('includes/conexion.php');
     if (isset($_GET["id"])) {

         $oferta_id = $_GET["id"];

         if (isset($ofertas[$oferta_id])) {
              $oferta = $ofertas[$oferta_id];

          }
      }   
      else {
         header("Location: ofertas.php");
           exit();
         }  
     ?>
    <body>
    <div class="jumbotron">
      <div class="container">
        
      <div class="row">
        <div class="col-md-8">
          <p><img src="<?php echo $oferta["img"]; ?>" alt="<?php echo $oferta["nombre"]; ?> "> </p>
          <h2><?php echo $oferta["nombre"]; ?></h2>
          <p><?php echo $oferta["descripcion"]; ?></p>
        </div>

        <div class="col-md-4">

             <p><a class="btn-danger" href="#">Comprar: Antes <?php echo $oferta["precio"]; ?> 
              <strong> Ahora <?php echo $oferta["precioOferta"]; ?></strong> </a></p>
      </div>
    </div>
  </div>
    <!-- Ofertas -->
    
<?php
    include('includes/footer.php');
  ?>
    </body>
</html>
