

<!DOCTYPE HTML>
<html>
<?php
include("inc/conexion.php");
$pa = $_GET["id"];
 $sql = "SELECT * FROM usuarios WHERE usuario ='".$pa."'";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
foreach ($rows as $row) { ?>
<form action="" method="post">
                    	
                        
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <input name="id" class="pm-form-textfield" type="hidden" placeholder="" value="<?php echo $row->id;?>">
                            
                            <input name="nombre" class="pm-form-textfield" type="text" placeholder="" value="<?php echo $row->nombre;?>">
                        </div>
                        
                        
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <input name="apellidos" class="pm-form-textfield" type="text" placeholder="" value="<?php echo $row->apellidos;?>">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <input name="usuario" class="pm-form-textfield" type="text" placeholder="" value="<?php echo $row->usuario;?>">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <input name="pass" class="pm-form-textfield" type="text" placeholder="" value="<?php echo $row->contrasena;?>">
                        </div>
                        
                        <?php }
                        }
                         ?>
                        <div class="col-lg-12 pm-center">
                            <button type="submit" value="Actualizar" name="pm-form-submit-btn" class="pm-form-submit-btn">Actualizar</button>
                            
                        </div>
                    
                    </form>
                
                
}


 ?>
</body>
 <html>