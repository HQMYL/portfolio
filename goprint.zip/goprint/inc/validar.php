<?php
include("inc/conexion.php");

if (isset($_POST['usuario'])) {
$usuario = $_POST['usuario'];
}
if (isset($_POST['pass'])) {
	$pass = $_POST['pass'];
}


 $sth = $con->prepare("SELECT * FROM usuarios WHERE usuario = ? AND contrasena = ?");
$sth->bindParam(1, $usuario);
$sth->bindParam(2, $pass);
$sth->execute();

if ($sth->rowCount() > 0) {

foreach ($sth as $row ) {

	if ($row['tipo'] == 1) {
		session_start();
        $_SESSION['usuario'] = $usuario;
    header("Location: index.php");
} else if ($row['tipo'] == 2) {
	session_start();
	$_SESSION['usuario'] = $usuario;
    header("Location: principal2.php");
}

 }
}
?>