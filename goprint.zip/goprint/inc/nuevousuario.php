<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
include("inc/conexion.php");
$nombre = $_POST["nombre"];
$apellidos = $_POST["apellidos"];
$correo = $_POST["correo"];
$usuario = $_POST["usuario"];;
$pass = $_POST["pass"];



$sql = "INSERT INTO usuarios (nombre, apellidos,correo,usuario, contrasena) VALUES (:nombre,:nombre, :apellidos, :correo :usuario, :contrasena)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt->bindParam(':apellidos', $apellido, PDO::PARAM_STR); 
$stmt->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':contrasena', $contrasena, PDO::PARAM_STR); 
$stmt->execute();

?>

<script>
alert('El usuario a sido agregado exitosamaente');
window.location.href='blog.php';
</script>

</body>
<html>