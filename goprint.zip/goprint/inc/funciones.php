<?php
include('inc/conexion.php');

function portada($row){


 $salida = "";
 $salida = $salida . '<div class="col-lg-3">';
 $salida = $salida . '<h2>' . $row->sku . '</h2>';
 $salida = $salida . '<img src="' . $row->img . '" alt="' . $row->descripcion . '"class="img-responsive img-thumbnail">';

 $salida = $salida . '<p>' .  $row->nombre . '</p>';
 $salida = $salida . '<p>' .  $row->descripcion . '</p>';
 $salida = $salida . '</div>';
return $salida;
}

function portada2($row){


 $s = "";
 $s = $s . '<div class="col-lg-3">';
 $s = $s . '<h2>' . $row->sku . '</h2>';
 $s = $s . '<img src="' . $row->img . '" alt="' . $row->descripcion . '"class="img-responsive img-thumbnail">';

 $s = $s . '<p>' .  $row->nombre . '</p>';
 $s = $s . '<p>' .  $row->descripcion . '</p>';
 $s = $s . '</div>';
return $s;
}





?>