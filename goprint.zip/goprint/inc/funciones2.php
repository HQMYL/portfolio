
<?php

include('inc/conexion.php');

function portada($row_id, $row){


 $salida = "";
 
 
 $salida = $salida . '<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 pm-column-spacing">';
 $salida = $salida . '<a class="pm-store-post-title"><strong>' . $row->nombreProd. '</strong></a>';
 $salida = $salida . '<div class="pm-store-post-container">';
 $salida = $salida . '<div class="pm-store-post-info-container">';
 $salida = $salida . '<div class="pm-store-post-info-overlay">';
 $salida = $salida . '<p class="pm-store-post-quantity">Brillante</p>';
 $salida = $salida . '<p class="pm-store-post-excerpt">' .$row->descripcion . '</p>';
 $salida = $salida . '<a href="#" class="pm-store-post-details-btn pm-close-btn fa fa-close"></a>';
 $salida = $salida . '</div>';
 $salida = $salida . '<div class="pm-store-post-img">';
 $salida = $salida . '<img src=" ' . $row->img . '" class="img-responsive" alt="">';
 $salida = $salida . '</div>';
 $salida = $salida . '<div class="pm-store-post-tags">';
 $salida = $salida . '<a href="#" class="fa fa-chevron-up pm-store-post-expander"></a>';
 $salida = $salida . '<p>Tipo de plastificado: Brillante</p>';
 $salida = $salida . '</div>';
 $salida = $salida . '</div>';
 $salida = $salida . '</div>';

 
 $salida = $salida . '<p class="pm-store-post-price">' . $row->precio . '</p>';
 $salida = $salida . '<p><a class="btn-danger" href="solicitud.php?id='. $row_id .'">Solicitar</strong> </a></p>';
 $salida = $salida . '</div>';
return $salida;
}

function portada2($row_id,$row){


 $salida = ""; 
 $salida = $salida . '<img src=" ' . $row->img . '" class="img-responsive" width="260" height="235" alt="articulo">';
 $salida = $salida . '<a class="pm-store-post-title"><strong>' . utf8_decode($row->titulo) . '</strong></a>';
 $salida = $salida . '<p>' . utf8_decode($row->fecha) .'</p>'; 
 $salida = $salida . '<p>' . utf8_decode($row->descripcion) .'</p>'; 
 $salida = $salida . '<p><a class="btn-danger" href="descripcion.html?id='. $row_id .'">Ver Detalles</strong> </a></p>';
 return $salida;
}

/* funcion pagina administrador */
function portada21($row_id,$row){
 $salida = ""; 
 $salida = $salida . '<div class="col-sm-4 col-md-6">';
 $salida = $salida . '<div class="thumbnail">';
 $salida = $salida . '<img class="img-responsive img-thumnail" src=" ' . $row->img . '" width="300" height="250" alt="Articulo">';
 $salida = $salida . '<div class="caption">';
 $salida = $salida . '<h3>' . utf8_encode($row->titulo) . '</h3>';
 $salida = $salida . '<p>' . utf8_encode($row->fecha) .'</p>';
 $salida = $salida . '<p>' . utf8_encode($row->introdescripcion) .'</p>';
 $salida = $salida . '<p>';
 $salida = $salida . '<div class="row col-xs-12">'; 
 $salida = $salida . '<p class="col-xs-6"><a class="btn-danger" href="actualizar.php?id= ' .$row->id . '">Actualizar</strong> </a></p>';
 $salida = $salida . '<p class="col-xs-6"><a class="btn-danger" href="eliminararticulo.php?id='  .$row->id .'">Eliminar</strong> </a></p>';
 $salida = $salida . '</div>';
 $salida = $salida . '</p>';
 $salida = $salida . '</div>'; 
 $salida = $salida . '</div>';
 $salida = $salida . '</div>';
 
/* $salida = $salida . '</div>'; */
 return $salida;
}

/* funcion pagina administrador */

function portada23($row_id, $row){


 $salida = ""; 
 $salida = $salida . '<div class="col-sm-6 col-md-4">';
 $salida = $salida . '<div class="thumbnail">';
 $salida = $salida . '<img class="img-responsive img-thumbnail" src=" ' . $row->img . '" width="260" height="235" alt="Articulo">';
 $salida = $salida . '<div class="caption">';
 $salida = $salida . '<h3>' . utf8_encode($row->titulo) . '</h3>';
 $salida = $salida . '<p>' . utf8_encode($row->fecha) .'</p>';
 $salida = $salida . '<p>' . utf8_encode($row->introdescripcion) .'</p>';
 $salida = $salida . '<p>';
 $salida = $salida . '<p><a class="btn-danger" href="descripcion.html?id='. $row->id .'">Ver Detalles</strong> </a></p>';
 $salida = $salida . '</p>';
 $salida = $salida . '</div>'; 
 $salida = $salida . '</div>';
 $salida = $salida . '</div>';
 
 
return $salida;
}

function portada24($row_id, $row){


 $salida = ""; 
 $salida = $salida . '<div class="col-sm-6 col-md-4">';
 $salida = $salida . '<div class="thumbnail">';
 $salida = $salida . '<img class="img-responsive img-thumbnail" src=" ' . $row->img . '" width="260" height="235" alt="Articulo">';
 $salida = $salida . '<div class="caption">';
 $salida = $salida . '<h3>' . utf8_encode($row->titulo) . '</h3>';
 $salida = $salida . '<p>' . utf8_encode($row->fecha) .'</p>';
 $salida = $salida . '<p>' . utf8_encode($row->introdescripcion) .'</p>';
 $salida = $salida . '<p>';
 $salida = $salida . '<p><a class="btn-danger" href="descripcion2.html?id='. $row->id .'">Ver Detalles</strong> </a></p>';
 $salida = $salida . '</p>';
 $salida = $salida . '</div>'; 
 $salida = $salida . '</div>';
 $salida = $salida . '</div>';
 
 
return $salida;
}


function articulo($row2){
$salida = "";
$salida = $salida . '<p><img src=" ' . $row2->img . '" class="img-responsive" alt="' . utf8_encode($row2->titulo) . '"></p>';
$salida = $salida . '<h2>' . utf8_encode($row2->titulo) . '</h2>';
$salida = $salida . '<p>' . utf8_encode($row2->descripcion) . '</p>';

 return $salida;

}


function products($row_id, $row) {
$salida = "";

$salida = $salida .'<div class="container pm-containerPadding-top-40 pm-containerPadding-bottom-40">';
$salida = $salida .'<div class="row">';
$salida = $salida .'<div class="col-lg-12">';
$salida = $salida . '<div id="pm-brands-carousel2" class="owl-carousel owl-theme">';
$salida = $salida . '<div class="pm-brand-item">';
$salida = $salida . '<img src="'. $row->img . '" width="263" height="67" alt="' . $row->nombreProd . '"> ';
$salida = $salida . '<a href="" target="_blank">foundation-medicine.com</a>';
$salida = $salida . '</div>';
$salida = $salida . '</div>';
$salida = $salida . '</div>';
$salida = $salida . '</div>';
$salida = $salida . '</div>';
$salida = $salida . '</div>';
return $salida;

}
function products2($row_id, $row){
$salida = "";
 
 $salida = $salida . '<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 pm-column-spacing">';
 $salida = $salida . '<a class="pm-store-post-title"><strong>' . $row->nombreProd. '</strong></a>';
 $salida = $salida . '<div class="pm-store-post-container">';
 $salida = $salida . '<div class="pm-store-post-info-container">';
 $salida = $salida . '<div class="pm-store-post-info-overlay">';
 $salida = $salida . '<p class="pm-store-post-quantity">Brillante</p>';
 $salida = $salida . '<p class="pm-store-post-excerpt">' .$row->descripcion . '</p>';
 $salida = $salida . '<a href="#" class="pm-store-post-details-btn pm-close-btn fa fa-close"></a>';
 $salida = $salida . '</div>';
 $salida = $salida . '<div class="pm-store-post-img">';
 $salida = $salida . '<img src=" ' . $row->img . '" class="img-responsive" alt="Slider">';
 $salida = $salida . '</div>';
 $salida = $salida . '<div class="pm-store-post-tags">';
 $salida = $salida . '<a href="#" class="fa fa-chevron-up pm-store-post-expander"></a>';
 $salida = $salida . '<p>Tipo de plastificado: Brillante</p>';
 $salida = $salida . '</div>';
 $salida = $salida . '</div>';
 $salida = $salida . '</div>';

 
 $salida = $salida . '<p class="pm-store-post-price">' . $row->precio . '</p>';
 $salida = $salida . '<p><a class="btn-danger" href="solicitud.php?id='. $row_id .'">Solicitar</strong> </a></p>';
 $salida = $salida . '</div>';

}


function carrusel($row_id, $row){
	$salida = "";
	$salida = $salida . '<div class="col-lg-12">';
    $salida = $salida . '<div id="pm-brands-carousel2" class="owl-carousel owl-theme">';
    $salida = $salida . '<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 pm-column-spacing">';
    $salida = $salida . '<div class="pm-brand-item2">';
    $salida = $salida . '<a class="pm-store-post-title"><strong>' . $row->nombreProd . '</strong></a>';
     $salida = $salida . '<div class="pm-store-post-container2">';
     $salida = $salida . '<div class="pm-store-post-info-container2">';
     $salida = $salida . '<div class="pm-store-post-info-overlay">';
     $salida = $salida . '<p class="pm-store-post-quantity">Brillante</p>';
     $salida = $salida . '<p class="pm-store-post-excerpt">' . $row->descripcion . '</p>';
     $salida = $salida . '<a href="#" class="pm-store-post-details-btn pm-close-btn fa fa-close"></a>';
     $salida = $salida . '</div>'; /* cierre*/
     $salida = $salida . '<div class="pm-store-post-img">';
     $salida = $salida . '<img src="' . $row->img . '" class="img-responsive" alt="">';
     $salida = $salida . '</div>';
     $salida = $salida . '<div class="pm-store-post-tags">';
     $salida = $salida . '<a href="#" class="fa fa-chevron-up pm-store-post-expander"></a>';
     $salida = $salida . '<p>Tipo de plastificado: Brillante</p>';
     $salida = $salida . '</div>';
     $salida = $salida . '</div>'; /* cierre post info container */
     $salida = $salida . '</div>'; /* cierre post container */
     $salida = $salida . '<p class="pm-store-post-price">' . $row->precio . '</p>';
     $salida = $salida . '</div>'; /* cierre brand item */
    $salida = $salida . '</div>';
    $salida = $salida . '</div>'; /* cierre brands carrusel */
	$salida = $salida . '</div>'; /* cierre lg-12 */
	$salida = $salida . '</div>';
    $salida = $salida . '</div>';
    return $salida;


}

function v($row_id, $row) {

$salida = "";

$salida = $salida . '<div id="carrusel">';
$salida = $salida . '<a href="#" class="izquierda_flecha"><img src="img/next.png"></a>';
$salida = $salida . '<a href="#" class="derecha_flecha"><img src="img/next.png" /></a>';
$salida = $salida . '<div class="carrusel">';
$salida = $salida . '<div class="product" id="' .$row->id . '">';
$salida = $salida . '<img class="img_carrusel" src=" ' . $row->img . '" width="195px" height="100px">';
$salida = $salida . '<p>' . $row->nombreProd . '</p>';
$salida = $salida . '<p>' . $row->precio . '</p>';
$salida = $salida . '</div>';
$salida = $salida . '</div>';
$salida = $salida . '</div>';

 return $salida;
}






?>
