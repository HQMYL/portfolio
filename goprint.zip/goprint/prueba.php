<!DOCTYPE html>
<html lang="en">
<?php 
include("inc/funciones2.php");
?>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="Goprint, Empresa de Servicio de Impresión">
    <meta name="author" content="GoPrint">
    <link rel="shortcut icon" href="favicon.html">

    <title>GoPrint: De la imprenta a tus manos.</title>
    
    <link href="bootstrap3/css/bootstrap.css" rel="stylesheet">

    <!-- main css -->
    <link href="css/master.css" rel="stylesheet">
    
    <!-- mobile css -->
    <link href="css/responsive.css" rel="stylesheet">
    
    <!-- FontAwesome Support -->
    <link rel="stylesheet" type="text/css" href="css/fontawesome/font-awesome.min.css" />
    <!-- FontAwesome Support -->
    
    <!-- Superfish menu -->
    <link rel="stylesheet" type="text/css" href="css/superfish/superfish.css" />
    <!-- Superfish menu -->
    
    <!-- Theme Color selector -->
    <link href="js/theme-color-selector/theme-color-selector.css" type="text/css" rel="stylesheet">
    <!-- Theme Color selector -->
    
    <!-- Owl Carousel -->
    <link rel="stylesheet" type="text/css" href="js/owl-carousel/owl.carousel.css" />
    <!-- Owl Carousel -->
    
    <!-- Typicons -->
    <link rel="stylesheet" type="text/css" href="css/typicons/typicons.min.css" />
    <!-- Typicons -->
    
    <!-- WOW animations -->
    <link rel="stylesheet" type="text/css" href="js/wow/css/libs/animate.css" />
    <!-- WOW animations -->
    
    <!-- Pulse Slider -->
    <link rel="stylesheet" type="text/css" href="js/pulse/pm-slider.css" />
    <!-- Pulse Slider -->
    
    <!-- MeanMenu (mobile) -->
    <link rel="stylesheet" type="text/css" href="js/meanmenu/meanmenu.css" />
    <!-- MeanMenu (mobile) -->
    
    <!-- Flexslider -->
    <link rel="stylesheet" type="text/css" href="js/flexslider/flexslider-post.css" />
    <!-- Flexslider -->
    
    <!-- PrettyPhoto -->
    <link rel="stylesheet" type="text/css" href="js/prettyphoto/css/prettyPhoto.css" />
    <!-- PrettyPhoto -->
    
    <!-- jQuery UI -->
    <link rel="stylesheet" type="text/css" href="css/jquery-ui/jquery-ui.css" />
    <!-- jQuery UI -->
        
    <!-- Development Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300italic,300,400italic,600,600italic,700,700italic,800,800italic%7COpen+Sans+Condensed:300,300italic,700%7CRaleway:400,200,300,100,600,500,700,800,900%7COswald:400,300,700%7CRoboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic%7CRoboto+Condensed:400,300,300italic,400italic,700,700italic%7CRoboto+Slab:400,100,300,700%7CLato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <!-- Development Google Fonts -->
    
  </head>

  <body>
    
  <!-- Theme color selector -->
  <div id="pm_theme_color_selector">
        <a class="pm_theme_color_selector_btn"><i class="typcn typcn-cog"></i></a>
        <p class="pm_theme_color_selector_title">Style Sampler</p>

        <div class="pm_theme_color_selector_container">
        	<p>Layout Style</p>
        	<select name="pm_theme_color_selector_mode" id="pm_theme_color_selector_mode">
        	  <option value="pm-full-mode" selected>Fullscreen</option>
              <option value="pm-boxed-mode">Boxed Mode</option>
        	</select>
        </div>
        <div class="pm_theme_color_selector_container">
        	<p>Patterns for Boxed Mode</p>
        	<ul class="pm_theme_img_selector" id="pm_theme_pattern_selector">
                <li><a href="#" id="pattern1-lg"><img src="img/boxed-patterns/pattern1.png" alt="pattern1"></a></li>
                <li><a href="#" id="pattern2-lg"><img src="img/boxed-patterns/pattern2.png" alt="pattern2"></a></li>
                <li><a href="#" id="pattern3-lg"><img src="img/boxed-patterns/pattern3.png" alt="pattern3"></a></li>
                <li><a href="#" id="pattern4"><img src="img/boxed-patterns/pattern4.png" alt="pattern4"></a></li>
                <li><a href="#" id="pattern5"><img src="img/boxed-patterns/pattern5.png" alt="pattern5"></a></li>
                <li><a href="#" id="pattern6"><img src="img/boxed-patterns/pattern6.png" alt="pattern6"></a></li>
            </ul>
        </div>
        
        <div class="pm_theme_color_selector_container">
        	<p>Backgrounds for Boxed Mode</p>
        	<ul class="pm_theme_img_selector" id="pm_theme_background_selector">
                <li><a href="#" id="1a"><img src="img/boxed-bgs/1.jpg" alt="bg1"></a></li>
                <li><a href="#" id="2a"><img src="img/boxed-bgs/2.jpg" alt="bg2"></a></li>
                <li><a href="#" id="3a"><img src="img/boxed-bgs/3.jpg" alt="bg3"></a></li>
                <li><a href="#" id="4a"><img src="img/boxed-bgs/4.jpg" alt="bg4"></a></li>
                <li><a href="#" id="5a"><img src="img/boxed-bgs/5.jpg" alt="bg5"></a></li>
            </ul>
        </div>
   
    </div>
    <!-- Theme color selector -->
    

	<div id="pm_layout_wrapper" class="pm-full-mode"><!-- Use wrapper for wide or boxed mode -->
        
    	<!-- Sub-Menu -->
    	<div class="pm-sub-menu-container">
        
        	<div class="container">
            
            	<div class="row">
                	
                    <div class="col-lg-4 col-md-4 col-sm-12">
                    	
                        <div class="pm-sub-menu-info">
                        	
                            <ul class="pm-micro-navigation">
                            	<li><p style="color: #ffffff; font-size: 20px"><strong>Envíos a todo el Perú</strong></p></li>
                            </ul>
                            
                        </div>
                                                
                    </div>
                    
                    
                    <div class="col-lg-8 col-md-8 col-sm-12">
                    
                    	<ul class="pm-social-navigation">
                        	<li class="pm_tip_static_bottom" title="Twitter"><a href="#" class="fa fa-twitter"></a></li>
                            <li class="pm_tip_static_bottom" title="Facebook"><a href="https://facebook.com/GoPrint-350146991985225 
" class="fa fa-facebook"></a></li>
                            <li class="pm_tip_static_bottom" title="Google Plus"><a href="#" class="fa fa-google-plus"></a></li>
                            <li class="pm_tip_static_bottom" title="Linkedin"><a href="#" class="fa fa-linkedin"></a></li>
                            <li class="pm_tip_static_bottom" title="YouTube"><a href="#" class="fa fa-youtube"></a></li>
                            <li class="pm_tip_static_bottom" title="Reddit"><a href="#" class="fa fa-reddit"></a></li>
                        </ul>
                    
                    	
                        
                    </div>
                    
                </div>
            
            </div>
            
        </div>
        <!-- /Sub-header -->
        
        <!-- Request appointment form -->
        <div class="pm-request-appointment-form" id="pm-appointment-form">
        	
            <div class="container">
            	<div class="row">
                	
                    <form action="#" method="post">
                        <div class="col-lg-4 col-md-4 col-sm-6">
                        	<input name="" type="text" class="pm-request-appointment-form-textfield" placeholder="Full Name">
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-6">
                        	<input name="" type="email" class="pm-request-appointment-form-textfield" placeholder="Email Address">
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-6">
                        	<input name="" type="email" class="pm-request-appointment-form-textfield" placeholder="Phone Number">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6">
                        	<input name="" class="pm-request-appointment-form-textfield appointment-form-datepicker" type="text" placeholder="Date of Appointment" id="datepicker">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                        	<input name="" class="pm-request-appointment-form-textfield appointment-form-datepicker" type="text" placeholder="Time of Appointment (ex. 10:30am)">
                        </div>
                        <div class="col-lg-12 pm-clear-element" style="padding-top:20px;">
                        	<input type="submit" value="Submit Request" class="pm-square-btn appointment-form" />
                            <p class="pm-appointment-form-notice">All fields are required.</p>                            <a href="#" class="pm-appointment-form-close" id="pm-close-appointment-form"><i class="fa fa-close"></i> Close Appointment form</a>
                        </div>
                        
                    </form>
                    
                </div>
            </div>
            
        </div>
        <!-- Request appointment form end -->
            
    	<!-- Header area -->
        <header>
                
        	<div class="container">
            
            	<div class="row">
                
                	<div class="col-lg-4 col-md-4 col-sm-12">
                    
                    	 <div class="pm-header-logo-container">
                            <a href="index.html"><img src="img/logo.png" class="img-responsive pm-header-logo" alt="GoPrint"></a> 
                        </div>
                        
                    </div>
                    
                    <div class="col-lg-8 col-md-8 col-sm-12">
                    	
                        <ul class="pm-header-info">
                        	<li><p><i class="fa fa-mobile-phone"></i> + 555 05555</p></li>
                            <li><p> <i class="fa fa-inbox"></i> &nbsp;<a href="mailto:ventas@goprint.pe">www.goprint.pe</a></p></li>
                        </ul>
                        
                        <ul class="pm-search-container">
                        	<li>
                            	<div class="pm-search-field-container">
                                	<a href="#" class="fa fa-search"></a>
                                	<form action="#" method="post">
                                    	<input name="pm-search-field" class="pm-search-field" type="text" placeholder="buscar...">
                                    </form>
                                </div>
                            </li>
                        </ul>
                        
                    </div>
                    
                </div>
            
            </div>
                    
        </header>
        <!-- /Header area end -->
        
        <!-- Navigation area -->
        <div class="pm-nav-container">
        
        	<div class="container">
            
                <div class="row">
                    
                    <div class="col-lg-8 col-md-8 col-sm-12">
                        
                        <nav class="navbar-collapse collapse" id="pm-main-navigation">
                        
                            <ul class="sf-menu pm-nav">
                        
                        		<li><a href="index.html" class="fa fa-home" id="pm-home-btn"></a></li>
                                <li>
                                	<a href="medical-staff.html">Inicio</a>
                                </li>
                                
                                <li><a href="contactenos.html">Contactenos</a></li>
                                <li><a href="services.html">Servicios</a></li>
                            
                            </ul>
                        
                        </nav> 
                    
                    </div>
                    
                    <div class="col-lg-4 col-md-4 col-sm-12 pm-main-menu">
                                        
                        <ul class="pm-cart-info">
                        	<li><p><strong>Comunícate con nosotros al:</strong></p></li>
                            <li><p>976048631</p></li>
                        </ul>
                                              
                    </div>
                    
                </div>
            
            </div>
        
        </div>
        <!-- Navigation area end -->
                
        <!-- SLIDER AREA -->
        
        <div class="pm-pulse-container" id="pm-pulse-container">
                

            
        
        </div>
        <div id="myCarousel" class="carousel slide" data-interval="3000" data-ride="carousel">
      <!-- Carousel indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol>
      <!-- Carousel items -->
      <div class="carousel-inner">
        <div class="item active">
          <img src="img/slide.png" alt="First Slide">
          <div class="carousel-caption">
            <h3>Imagen 1</h3>
            <p>Bienvenidos a nuestro Sitio Web</p>
          </div>
        </div>
        <div class="item">
          <img src="img/slide2.png" alt="Second Slide">
          <div class="carousel-caption">
            <h3></h3>
            <p></p>
          </div>
        </div>
        <div class="item">
          <img src="img/slide3.png" alt="Third Slide">
          <div class="carousel-caption">
            <h3></h3>
            <p></p>
          </div>
        </div>
      </div>
      <!-- Carousel nav -->
      <a class="carousel-control left" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      </a>
      <a class="carousel-control right" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      </a>
    </div>

 		<!-- SLIDER AREA end -->
        
        <!-- BODY CONTENT starts here -->
        
       	<!-- PANEL 1 -->
        <div class="container pm-containerPadding-top-40 pm-containerPadding-bottom-40">
        
            <div class="row">
                
                
<?php
 $sql = "SELECT * FROM articulos";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row_id => $row) {
    echo portada23($row_id,$row);
}

?>
                    
                     
            </div><!-- /.row -->
        
        </div>
        <!-- PANEL 1 end -->
        
        <!-- PANEL 2 -->
        <div class="pm-column-container pm-parallax-panel" style="background-color:#205663" data-stellar-background-ratio="0.5" data-stellar-vertical-offset="100">
        
        	<!-- Column message -->
        	<div class="pm-column-container-message">
            	<p><strong>Preguntas Frecuentes?</strong></p>
            </div>
            <!-- Column message end -->
        
        	<div class="container pm-containerPadding-top-50 pm-containerPadding-bottom-80">
            
            	<div class="row">
                	<!--<div class="col-lg-6 col-md-6 col-sm-12 pm-column-spacing">
                    
                        <h4>Take a tour of our medical facility</h4>
                        <p class="light">Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                        
                        <div class="pm-video-container" style="background-image:url(img/home/video.jpg);">
                        
                        	<div class="pm-video-overlay">
                                <a href="https://www.youtube.com/watch?v=5ZxQ7UHjPXA" data-rel="prettyPhoto" class="pm-video-activator-btn fa fa-play expand lightbox"></a>
                            </div>
                        	
                        </div>
                        
                        <a href="gallery.html" class="pm-rounded-btn pm-center-align">View our gallery <i class="fa fa-plus"></i></a>
                        
                    </div>-->
                    
                    <div class="col-lg-12 col-md-12 col-sm-12">
                    	
                        <h4>En GoPrint</h4>
                        <p class="light" style="text-align:justify;">Esta sección está dedicada a autoresponder todas tus dudas antes del primer contacto con nosotros, pero no te preocupes, si no encuentras en esta F.A.Q. la respuesta a tu duda, dirígite a nuestro formulario de contacto para plantearnos tus inquietudes o comunícate a los números que te dejamos en el encabezado, muchas gracias.</p>
                        
                        <!-- Bootstrap accordion system -->
                        <div id="accordion" class="panel-group">
                        
                            <!-- accordion item 1 -->
                            <div class="panel panel-default">
                            
                                <div class="panel-heading">
                                    <h4 class="panel-title"><i class="fa fa-plus"></i><a class="pm-accordion-link collapsed" href="#collapse0" data-parent="#accordion" data-toggle="collapse"><strong>Ya tengo mi diseño, como lo envío.</strong></a></h4>
                                </div>
                                
                                <div class="panel-collapse collapse" id="collapse0" style="height: 0px;">
                                    <div class="panel-body">
                                    	<p>Una vez que tengas tu diseño en formato .cdr lo puedes enviar a este correo ventas@goprint.pe conteniendo los siguientes datos:</p>
                                        <p>Nombres:</p>
                                        <p>Apellidos:</p>
                                        <p>Celular:</p>
                                        <p>Ciudad:</p>
                                        <p>Dirección:</p>
                                        <br>
                                        <p>PD: El diseño debe estar en vectores, en tal caso comuniquese antes con nosotros.</p>
                                    </div>
                                </div>
                                
                            </div>
                            <!-- accordion item 1 end -->
                            
                            <!-- accordion item 2 -->
                            <div class="panel panel-default">
                            
                                <div class="panel-heading">
                                    <h4 class="panel-title"><i class="fa fa-plus"></i><a class="pm-accordion-link collapsed" href="#collapse1" data-parent="#accordion" data-toggle="collapse"><strong>Quiero mis tarjetas, pero no tengo diseño.</strong></a></h4>
                                </div>
                                
                                <div class="panel-collapse collapse" id="collapse1">
                                    <div class="panel-body">
                                        <p>En caso no cuentes con un diseño uno de nuestros diseñadores te ayudará, el único requisito es tener un logo que identifique a tu empresa y que vaya en las tarjetas que desees, del resto nos encargamos nosotros. </p>
                                        
                                    </div>
                                </div>
                            
                            </div>
                            <!-- accordion item 2 end -->
                            
                            <!-- accordion item 3 -->
                            <div class="panel panel-default">
                            
                                <div class="panel-heading">
                                    <h4 class="panel-title"><i class="fa fa-plus"></i><a class="pm-accordion-link collapsed" href="#collapse2" data-parent="#accordion" data-toggle="collapse"><strong>Que tamaño deben de tener mis tarjetas?</strong></a></h4>
                                </div>
                                
                                <div class="panel-collapse collapse" id="collapse2">
                                    <div class="panel-body">
                                    	<p>El tamaño ideal para tus tarjetas debe ser de 9cm x 5.5cm.</p>
                                        <img src="img/home/tamaño.png" width="340" height="195" class="pull-left" style="margin-right:20px;" alt="baby"> 
                                    </div>
                                </div>
                            
                            </div>
                            <!-- accordion item 3 end -->
                            
                            <!-- accordion item 4 -->
                            <div class="panel panel-default">
                            
                                <div class="panel-heading">
                                    <h4 class="panel-title"><i class="fa fa-plus"></i><a class="pm-accordion-link collapsed" href="#collapse3" data-parent="#accordion" data-toggle="collapse"><strong>El millar de mis tarjetas pueden tener 2 o más nombres diferentes?</strong></a></h4>
                                </div>
                                
                                <div class="panel-collapse collapse" id="collapse3">
                                    <div class="panel-body">
                                    	<p>No, el millar de tarjetas que soliciten solo llevará los datos de una persona.</p>
                                    </div>
                                </div>
                            
                            </div>
                            <!-- accordion item 4 end -->
                            
                            <!-- accordion item 5 -->
                            <div class="panel panel-default">
                            
                                <div class="panel-heading">
                                    <h4 class="panel-title"><i class="fa fa-plus"></i><a class="pm-accordion-link collapsed" href="#collapse4" data-parent="#accordion" data-toggle="collapse"><strong>En cuanto tiempo estarán listas mis tarjetas?</strong></a></h4>
                                </div>
                                
                                <div class="panel-collapse collapse" id="collapse4">
                                    <div class="panel-body">
                                    	<p>Tus tarjetas estarán listas en 48 horas luego de recibir y confirmar los datos de tu diseño, en el caso de provincias nos comunicaremos con usted pasadas las 48 horas para pactar el envío de sus tarjetas.</p>
                                    </div>
                                </div>
                            
                            </div>
                            <!-- accordion item 5 end -->
                            
                            <!-- accordion item 6 -->
                            <div class="panel panel-default">
                            
                                <div class="panel-heading">
                                    <h4 class="panel-title"><i class="fa fa-plus"></i><a class="pm-accordion-link collapsed" href="#collapse5" data-parent="#accordion" data-toggle="collapse"><strong>Realiza envíos a provincias?</strong></a></h4>
                                </div>
                                
                                <div class="panel-collapse collapse" id="collapse5">
                                    <div class="panel-body">
                                    	<p>Si realizamos envíos a provincias, al momento de enviar sus diseños les pediremos sus datos completos para que no haya ningún inconveniente en el envío, de todas formas un personal de nuestra empresa se comunicará con usted para confirmar el envío.</p>
                                        </div>
                                </div>
                            
                            </div>
                            <!-- accordion item 6 end -->
                            
                            <!-- accordion item 7 -->
                            <div class="panel panel-default">
                            
                                <div class="panel-heading">
                                    <h4 class="panel-title"><i class="fa fa-plus"></i><a class="pm-accordion-link collapsed" href="#collapse6" data-parent="#accordion" data-toggle="collapse"><strong>Costo de envío a mi ciudad?</strong></a></h4>
                                </div>
                                
                                <div class="panel-collapse collapse" id="collapse6">
                                    <div class="panel-body">
                                    	<p>El envío es completamente gratuito a todas las ciudades del Perú.</p>
                                    </div>
                                </div>
                            
                            </div>
                            <!-- accordion item 7 end -->

                            <!-- accordion item 8 -->
                            <div class="panel panel-default">
                            
                                <div class="panel-heading">
                                    <h4 class="panel-title"><i class="fa fa-plus"></i><a class="pm-accordion-link collapsed" href="#collapse7" data-parent="#accordion" data-toggle="collapse"><strong>Donde realizo el depósito?</strong></a></h4>
                                </div>
                                
                                <div class="panel-collapse collapse" id="collapse7">
                                    <div class="panel-body">
                                        <p>El depósito lo realizarás a este número de cuenta Interbank.</p>
                                    </div>
                                </div>
                            
                            </div>
                            <!-- accordion item 8 end -->

                            <!-- accordion item 9 -->
                            <div class="panel panel-default">
                            
                                <div class="panel-heading">
                                    <h4 class="panel-title"><i class="fa fa-plus"></i><a class="pm-accordion-link collapsed" href="#collapse8" data-parent="#accordion" data-toggle="collapse"><strong>Cual es el horario de atención?</strong></a></h4>
                                </div>
                                
                                <div class="panel-collapse collapse" id="collapse8">
                                    <div class="panel-body">
                                        <p>Tos horarios de atención son:</p>
                                        <p>Lunes a Viernes de 9 a.m - 6 p.m</p>
                                        <p>Sábados de 9 a.m - 12 p.m</p>
                                    </div>
                                </div>
                            
                            </div>
                            <!-- accordion item 9 end -->
                            
                        </div>
                        <!-- Bootstrap accordion system end -->
                        
                    </div>
                    
                </div>
            
            </div>
        
        </div>
        <!-- PANEL 2 end -->
        
                <!-- PANEL 7 -->
        <div class="container pm-containerPadding-top-100 pm-containerPadding-bottom-120">
        
            <div class="row">
                <div class="col-lg-12 pm-columnPadding30 pm-center">
                    
                    <h5>Nuestros Clientes &amp; Partners</h5>
                    <div class="pm-column-title-divider">
                        <img height="29" width="29" src="img/loguito.png" alt="icon">
                    </div>
                    
                </div>
            </div>
        
            <div class="row">
            
                <div class="col-lg-12">
                    
                    <!-- carousel -->
                    <div id="pm-brands-carousel" class="owl-carousel owl-theme">
                        <div class="pm-brand-item">
                            
                            
                            <img src="img/home/client-carousel1.jpg" width="263" height="67" alt="Foundation Medicine"> 
                            <a href="http://www.google.com/" target="_blank">foundation-medicine.com</a>
                        </div>
                        <div class="pm-brand-item">
                            
                            
                            <img src="img/home/client-carousel2.jpg" width="263" height="67" alt="Hansen Medical"> 
                            <a href="http://www.google.com/" target="_blank">hansenmedical.com</a>
                        </div>
                        <div class="pm-brand-item">
                            
                            
                            <img src="img/home/client-carousel3.jpg" width="263" height="67" alt="Clinica Sant Jordi"> 
                            <a href="http://www.google.com/" target="_blank">santjordit.com</a>
                        </div>
                        <div class="pm-brand-item">
                            
                            
                            <img src="img/home/client-carousel4.jpg" width="263" height="67" alt="Sensile Medical"> 
                            <a href="http://www.google.com/" target="_blank">sensilemedical.com</a>
                        </div>
                        <div class="pm-brand-item">
                            
                            
                            <img src="img/home/client-carousel5.jpg" width="263" height="67" alt="Medical Advantages Group Inc."> 
                            <a href="http://www.google.com/" target="_blank">maginc.com</a>
                        </div>
                    </div>
                    <!-- carousel end -->
                    
                    <!-- carousel controls -->
                    <div class="pm-brand-carousel-btns">
                        <a class="btn pm-owl-prev fa fa-chevron-left"></a>
                        <!--<a class="btn pm-owl-play fa fa-play" id="pm-owl-play"></a>
                        <a class="btn pm-owl-stop fa fa-stop"></a>-->
                        <a class="btn pm-owl-next fa fa-chevron-right"></a>
                    </div>
                    <!-- carousel controls end -->
                    
                </div>
            
            </div>
        
        </div>
        <!-- PANEL 7 end -->
        
        <!-- PANEL 4 -->
        <div class="pm-column-container testimonials pm-parallax-panel" style="background-color:#205663" data-stellar-background-ratio="0.5" data-stellar-vertical-offset="-50">
        
        	<div class="container pm-containerPadding110">
            	<div class="row">
                
                	<div class="col-lg-12 pm-center">
                    
                    	<h5 class="light">Suscríbete</h5>
                        
                        <p class="light">Te enviaremos las mejores promociones</p>
                    	
                        
                        <div class="pm-newsletter-form-container">
                        	<form novalidate target="_blank" class="validate" name="mc-embedded-subscribe-form" id="mc-embedded-subscribe-form" method="post" action="http://pulsarmedia.us4.list-manage.com/subscribe/post?u=2aa9334fc1bc18c8d05500b41&amp;id=dbcb577c4d">  
                                <input type="text" placeholder="Nombre" id="MERGE1" name="MERGE1" class="placeholder">
                                <input type="text" placeholder="Email" id="MERGE0" name="MERGE0" class="placeholder">
                                <input type="submit" class="pm-newsletter-submit-btn" value="suscribete &plus;" id="mc-embedded-subscribe" name="subscribe">
                            </form>
                        </div>
                        
                    </div>
                
                </div><!-- /.row -->
            </div><!-- /.container -->
        
        </div>
        <!-- PANEL 4 end -->
        
        
        

        
        
        <!-- BODY CONTENT end -->
        
        <div class="pm-fat-footer pm-parallax-panel" data-stellar-background-ratio="0.5">
        	
            <div class="container">
                <div class="row">
                
                    <div class="col-lg-3 col-md-3 col-sm-12 pm-widget-footer">
                    
                    	<h6 class="pm-fat-footer-title"><span>Acerca de:</span> GoPrint</h6>
                        <div class="pm-fat-footer-title-divider"></div>
                        
                        <p>GoPrint is a premium medical template designed by Pulsar Media.</p>
                        
                        <p>GoPrint is perfect for anyone in the medical and health industry and can be used by health facilities, hospitals, walk-in clinics, dental offices, chiropractors, physiotherapists, pediatricians etc.</p>
                        <p>GoPrint offers many great features such as a custom slider system, testimonials carousel and a clean modern design.</p>
                        
                    </div>
                    
                    
                    <div class="col-lg-3 col-md-3 col-sm-12 pm-widget-footer">
                    
                       <h6 class="pm-fat-footer-title"> <span>Contacte con</span> GoPrint</h6>
                       <div class="pm-fat-footer-title-divider"></div>
                       
                       <ul class="pm-general-icon-list">
                       	  <li>
                          	<span class="fa fa-mobile-phone pm-general-icon"></span>
                       		<p>+ 488 (0) 333.444.212</p>
                          </li>
                          <li>
                          	<span class="fa fa-inbox pm-general-icon"></span>
                       		<p><a href="mailto:info@GoPrint.com">ventas@goprint.pe</a></p>
                          </li>
                       </ul>
                        
                    </div>
                    
                    <!--<div class="col-lg-3 col-md-3 col-sm-12 pm-widget-footer">
                    
                        <h6 class="pm-fat-footer-title"><span>Latest</span> Tweets</h6>
                        <div class="pm-fat-footer-title-divider"></div>
                        
                        <ul class="tweet_list">
                        
                            <li class="tweet_first">
                                <div class="tweet_container">
                                    <span class="tweet_time"><a title="view tweet on twitter" href="#">about 14 days ago</a></span>
                                    <span class="tweet_join"></span>
                                    <span class="tweet_text"><a href="#">#Propranolol</a> is used in thyrotoxicosis due to it's antithyroid activity in addition the B blocker activity.  <a href="#">bit.ly/1szLobl</a></span>
                                </div>
                            </li>
                            
                            <li class="tweet_first">
                                <div class="tweet_container">
                                    <span class="tweet_time"><a title="view tweet on twitter" href="#">about 21 days ago</a></span>
                                    <span class="tweet_join"></span>
                                    <span class="tweet_text">Insulin is an anabolic hormone, promotes fuel storage. <a href="#">bit.ly/1szLobl</a></span>
                                </div>
                            </li>
                            
                            <li class="tweet_first">
                                <div class="tweet_container">
                                    <span class="tweet_time"><a title="view tweet on twitter" href="#">about 26 days ago</a></span>
                                    <span class="tweet_join"></span>
                                    <span class="tweet_text">CO2 diffuses 1st before O2 in respiration (alveolar gas exchange), due to higher solubility. <a href="#">bit.ly/1szLobl</a></span>
                                </div>
                            </li>
                            
                        </ul>
                        
                    </div>-->
                    
                    <div class="col-lg-3 col-md-3 col-sm-12 pm-widget-footer">
                    
                        <h6 class="pm-fat-footer-title"><span>Popular</span> Posts</h6>
                        <div class="pm-fat-footer-title-divider"></div>
                        
                        <ul class="pm-recent-blog-posts">
                            <!-- Post -->
                            <li>
                                <div style="background-image:url(img/home/p1.jpg);" class="pm-recent-blog-post-thumb"></div>
                                <div class="pm-recent-blog-post-details">
                                    <a href="news-post.html">Severe stroke patients recover better with prompt stent action</a>
                                    <p class="pm-date">Jan 29, 2015</p>
                                    <div class="pm-recent-blog-post-divider"></div>
                                </div>
                            </li>
                            <!-- Post end -->
                            <!-- Post -->
                            <li>
                                <div style="background-image:url(img/home/p2.jpg);" class="pm-recent-blog-post-thumb"></div>
                                <div class="pm-recent-blog-post-details">
                                    <a href="news-post.html">High fitness levels reduce hypertension risk</a>
                                    <p class="pm-date">Jan 25, 2015</p>
                                    <div class="pm-recent-blog-post-divider"></div>
                                </div>
                            </li>
                            <!-- Post end -->
                        </ul>
                        
                    </div>
                    
                </div>	
            </div>
            
        </div>
        
        <footer>

            
            <div class="container pm-containerPadding20">
            	<div class="row">
                
                	<div class="col-lg-4 col-md-4 col-sm-12 pm-center-mobile">
               	    	<img src="img/logo02.png" width="264" height="81" class="img-responsive pm-inline" alt="GoPrint">
                    </div>
                    
                    <div class="col-lg-8 col-md-8 col-sm-12">
                    	<ul class="pm-footer-navigation">
                        	<li><a href="index.html" class="active">Inicio</a></li>
                            <li><a href="contactenos.html">Contactenos</a></li>
                        </ul>
                    </div>
                
                </div>
            </div>

                
        </footer>
                
       
    
    </div><!-- /pm_layout-wrapper -->
    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery-2.1.3.min.js"></script>
    <script src="js/jquery.viewport.mini.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="bootstrap3/js/bootstrap.min.js"></script>
    <script src="js/modernizr.custom.js"></script>
    <script src="js/owl-carousel/owl.carousel.js"></script>
    <script src="js/main.js"></script>
    <script src="js/jquery.tooltip.js"></script>
    <script src="js/superfish/superfish.js"></script>
    <script src="js/superfish/hoverIntent.js"></script>
    <script src="js/stellar/jquery.stellar.js"></script>
    <script src="js/theme-color-selector/theme-color-selector.js"></script>
    <script src="js/pulse/jquery.PMSlider.js"></script>
    <script src="js/meanmenu/jquery.meanmenu.min.js"></script>
    <script src="js/flexslider/jquery.flexslider.js"></script>
    <script src="js/jquery.testimonials.js"></script>
    <script src="js/wow/wow.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.js"></script>
    <script src="js/prettyphoto/js/jquery.prettyPhoto.js"></script>
    <script src="js/tinynav.js"></script>
    <script src="js/jquery-ui.js"></script>
        
    <p id="back-top" class="visible-lg visible-md visible-sm"></p>
    
  </body>
</html>
