<?php
include("inc/conexion.php");

if (isset($_POST["id"])) {
	$pa = $_POST["id"];
}



 $sql = "SELECT * FROM usuarios WHERE usuario ='".$pa."'";
 $total = "SELECT COUNT(*) FROM usuarios";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {

echo '<table class="table-responsive table-bordered">';
echo '<tr>';
echo '<th>Nombre</th>';
echo '<th>Apellidos</th>';
echo '<th>Correo</th>';
echo '<th>Usuario</th>';
echo '<th>Contraseña</th>';


echo '</tr>';
echo '<tr>';
 echo '<td>' .  $row->nombre . '</td>';
 echo '<td>' .  $row->apellidos . '</td>';
 echo '<td>' .  $row->correo . '</td>';
 echo '<td>' .  $row->usuario . '</td>';
 echo '<td>' .  $row->contrasena . '</td>';
 echo '</table>';

}

 ?>