<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
include("inc/conexion.php");


if (isset($_POST["nombre"])) {
	$nombre = $_POST["nombre"];
}

if (isset($_POST["apellidos"])) {
	$apellidos = $_POST["apellidos"];
}

if (isset($_POST["correo"])) {
	$correo = $_POST["correo"];
}

if (isset($_POST["usuario"])) {
	$usuario = $_POST["usuario"];
}

if (isset($_POST["pass"])) {
	$pass = $_POST["pass"];
}

if (isset($_POST["tipo"])) {
	$tipo = $_POST["tipo"];
}





$sql = "INSERT INTO usuarios (nombre, apellidos,correo,usuario, contrasena, tipo) VALUES (:nombre, :apellidos,:correo, :usuario, :pass, :tipo)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR); 
$stmt->bindParam(':apellidos', $apellidos, PDO::PARAM_STR); 
$stmt->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt->execute();

?>
<script>
alert('El usuario a sido agregado exitosamaente');
window.location.href='registro.php';
</script>

</body>
<html>