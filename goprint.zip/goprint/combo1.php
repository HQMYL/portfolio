<?php
include("inc/conexion.php");



$sql = "SELECT * FROM usuarios"; 
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
echo '<table id="batsi" class="table-responsive table-bordered">';
echo '<tr>';
echo '<th>Nombre</th>';
echo '<th>Apellidos</th>';
echo '<th>Correo</th>';
echo '<th>Usuario</th>';
echo '<th>Contraseña</th>';
echo '</tr>';
$total = 0;
foreach ($rows as $row) {


 echo '<tr>';
 echo '<td>' .  $row->nombre . '</td>';
 echo '<td>' .  $row->apellidos . '</td>';
 echo '<td>' .  $row->correo . '</td>';
 echo '<td>' .  $row->usuario . '</td>';
 echo '<td>' .  $row->contrasena . '</td>';
 echo '</tr>';
 $total = $total + 1;
 }
echo '<p class="orochi">El Total de Usuarios Registrados es: ' . $total . '</p>';

 ?>