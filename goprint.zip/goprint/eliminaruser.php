<!DOCTYPE html>
<html lang="es">
<?php
session_start();
include("inc/conexion.php");

if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
?>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="GoPrint, Servicio de Impresión en Perú">
    <meta name="author" content="GoPrint">
    <link rel="shortcut icon" href="favicon.html">

    <title>GoPrint: De la imprenta a tus manos.</title>
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-92972113-1', 'auto');
  ga('send', 'pageview');

</script>
    
    <link rel="shortcut icon" href="img/favicon.ico">
    <link  type="text/javascript" href="js/jquery-3.js" />
    
    <link href="bootstrap3/css/bootstrap.css" rel="stylesheet">

    <!-- main css -->
    <link href="css/master.css" rel="stylesheet">
    
    <!-- mobile css -->
    <link href="css/responsive.css" rel="stylesheet">
    
    <!-- FontAwesome Support -->
    <link rel="stylesheet" type="text/css" href="css/fontawesome/font-awesome.min.css" />
    <!-- FontAwesome Support -->
    
    <!-- Superfish menu -->
    <link rel="stylesheet" type="text/css" href="css/superfish/superfish.css" />
    <!-- Superfish menu -->
    
    <!-- Theme Color selector -->
    <link href="js/theme-color-selector/theme-color-selector.css" type="text/css" rel="stylesheet">
    <!-- Theme Color selector -->
    
    <!-- Owl Carousel -->
    <link rel="stylesheet" type="text/css" href="js/owl-carousel/owl.carousel.css" />
    <!-- Owl Carousel -->
    
    <!-- Typicons -->
    <link rel="stylesheet" type="text/css" href="css/typicons/typicons.min.css" />
    <!-- Typicons -->
    
    <!-- WOW animations -->
    <link rel="stylesheet" type="text/css" href="js/wow/css/libs/animate.css" />
    <!-- WOW animations -->
    
    <!-- MeanMenu (mobile) -->
    <link rel="stylesheet" type="text/css" href="js/meanmenu/meanmenu.css" />
    <!-- MeanMenu (mobile) -->
    
    <!-- Flexslider -->
    <link rel="stylesheet" type="text/css" href="js/flexslider/flexslider-post.css" />
    <!-- Flexslider -->
    
    <!-- PrettyPhoto -->
    <link rel="stylesheet" type="text/css" href="js/prettyphoto/css/prettyPhoto.css" />
    <!-- PrettyPhoto -->
    
    <!-- jQuery UI -->
    <link rel="stylesheet" type="text/css" href="css/jquery-ui/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="css/nuevo.css" />
    <!-- jQuery UI -->
        
    <!-- Development Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300italic,300,400italic,600,600italic,700,700italic,800,800italic%7COpen+Sans+Condensed:300,300italic,700%7CRaleway:400,200,300,100,600,500,700,800,900%7COswald:400,300,700%7CRoboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic%7CRoboto+Condensed:400,300,300italic,400italic,700,700italic%7CRoboto+Slab:400,100,300,700%7CLato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <!-- Development Google Fonts -->
    
<script type="text/javascript">

$(document).ready(function() {
$(#batsi).click(function() {
var id=$("#user").val();
      $('#consi').load('consulta.php?id='+id);

});
});  
</script>

<script>
function enviar (){

  // el input del formulario

if (confirm('esta seguro que quiere eliminar este usuario?')){
    
return true;
     }

else{
return false;
}

}

</script> 

  </head>

  <body>
    
    <!-- Theme color selector -->
    

	<div id="pm_layout_wrapper" class="pm-full-mode"><!-- Use wrapper for wide or boxed mode -->
    
    	<!-- Sub-Menu -->
    	<div class="pm-sub-menu-container">
        
        	<div class="container">
            
            	<div class="row">
                	
                    <div class="col-lg-6 col-md-6 col-sm-12">
                    	
                        <div class="pm-sub-menu-info">
                        	
                            <ul class="pm-micro-navigation">
                            	<li><p style="color: #ffffff; font-size: 20px"><strong>Envíos a todo el Perú</strong></p></li>
                                </ul>
                            
                        </div>
                                                
                    </div>
                    
                    
                    <div class="col-lg-6 col-md-6 col-sm-12">
                    
                    	<ul class="pm-social-navigation">
                        	<li class="pm_tip_static_bottom" title="Twitter"><a href="https://twitter.com/GoPrintPeru
" class="fa fa-twitter"></a></li>
                            <li class="pm_tip_static_bottom" title="Facebook"><a href="https://facebook.com/GoPrint-350146991985225 
" class="fa fa-facebook"></a></li>
                            <li class="pm_tip_static_bottom" title="Google Plus"><a href="#" class="fa fa-google-plus"></a></li>
                            <li class="pm_tip_static_bottom" title="Linkedin"><a href="#" class="fa fa-linkedin"></a></li>
                            <li class="pm_tip_static_bottom" title="YouTube"><a href="#" class="fa fa-youtube"></a></li>
                            <li class="pm_tip_static_bottom" title="Reddit"><a href="#" class="fa fa-reddit"></a></li>
                        </ul>
                    
                    	<ul class="pm-sub-navigation">
                        	<li>
                                <div class="pm-dropdown pm-language-selector-menu">
                                    
                                    <div class="pm-dropmenu-active">
                                        <ul>
                                           <li><a href="#">English</a></li>
                                           <li><a href="#">French</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </li>
                        </ul>
                        
                    </div>
                    
                </div>
            
            </div>
            
        </div>
        <!-- /Sub-header -->
        
        <!-- Request appointment form -->
        <div class="pm-request-appointment-form" id="pm-appointment-form">
        	
            <div class="container">
            	<div class="row">
                	
                    <form action="#" method="post">
                        <div class="col-lg-4 col-md-4 col-sm-6">
                        	<input name="" type="text" class="pm-request-appointment-form-textfield" placeholder="Full Name">
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-6">
                        	<input name="" type="email" class="pm-request-appointment-form-textfield" placeholder="Email Address">
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-6">
                        	<input name="" type="email" class="pm-request-appointment-form-textfield" placeholder="Phone Number">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6">
                        	<input name="" class="pm-request-appointment-form-textfield appointment-form-datepicker" type="text" placeholder="Date of Appointment" id="datepicker">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                        	<input name="" class="pm-request-appointment-form-textfield appointment-form-datepicker" type="text" placeholder="Time of Appointment (ex. 10:30am)">
                        </div>
                        <div class="col-lg-12 pm-clear-element" style="padding-top:20px;">
                        	<input type="submit" value="Submit Request" class="pm-square-btn appointment-form" />
                            <p class="pm-appointment-form-notice">All fields are required.</p>                            <a href="#" class="pm-appointment-form-close" id="pm-close-appointment-form"><i class="fa fa-close"></i> Close Appointment form</a>
                        </div>
                        
                    </form>
                    
                </div>
            </div>
            
        </div>
        <!-- Request appointment form end -->
            
    	<!-- Header area -->
        <header>
                
        	<div class="container">
            
            	<div class="row">
                
                	<div class="col-lg-4 col-md-4 col-sm-12">
                    
                    	 <div class="pm-header-logo-container">
                            <a href="index.html"><img src="img/logo.png" class="img-responsive pm-header-logo" alt="Medical-Link Template"></a> 
                        </div>
                        
                    </div>
                    
                    <div class="col-lg-8 col-md-8 col-sm-12">
                    	
                        <ul class="pm-header-info">
                        	<li><p><i class="fa fa-mobile-phone"></i> + 51 976048631</p></li>
                            <li><p> <i class="fa fa-inbox"></i> &nbsp;<a href="mailto:ventas@goprint.pe">goprint@goprint.pe</a></p></li>
                        </ul>
                        
                        <ul class="pm-search-container">
                            <ul class="sf-menu pm-nav">

                            <li><a class="btn-danger"><?php echo " Bienvenido: " . $usuario; ?></a></li>
                        	<li><a class="btn-danger" href="users.php">Administración de Usuarios</a></li>
                            <li><a class="btn-danger" href="logout.php"> Cerrar Sesión</a></li>
                            </li>
                            </ul>
                        </ul>
                        
                    </div>
                    
                </div>
            
            </div>
                    
        </header>
        <!-- /Header area end -->
        
        <!-- Navigation area -->
        <div class="pm-nav-container">
        
            <div class="container">
            
                <div class="row">
                    
                    <div class="col-lg-8 col-md-8 col-sm-12">
                        
                        <nav class="navbar-collapse collapse" id="pm-main-navigation">
                        
                            <ul class="sf-menu pm-nav">
                        
                                <li><a href="index1.html" class="fa fa-home" id="pm-home-btn"></a></li>
                                <li>
                                    <a href="index1.html">Inicio</a>
                                </li>
                                <li><a href="servicios1.html">Servicios</a></li>
                                <li><a href="blog1.html">Blog</a></li>

                                <li><a href="contactenos1.html">Contactenos</a></li>
                            
                                
                            </ul>
                        
                        </nav> 
                    
                    </div>
                    
                    <div class="col-lg-4 col-md-4 col-sm-12 pm-main-menu">
                                        
                        <ul class="pm-cart-info">
                            <li><p><strong>Comunícate con nosotros al:</strong></p></li>
                            <li><p> + 51 976048631</p></li>
                        </ul>
                                              
                    </div>
                    
                </div>
            
            </div>
        
        </div>
        <!-- Navigation area end -->
                
        <!-- Sub-header area -->
        
        <div class="pm-sub-header-container">
        
        	<div class="pm-sub-header-info">
            	
                <div class="container">
                	<div class="row">
                    	<div class="col-lg-12">
                        	
                            <p class="pm-page-title">USUARIOS</p>
                            <p class="pm-page-message"></p>
                            
                        </div>
                    </div>
                </div>
                
            </div>
            
            <div class="pm-sub-header-breadcrumbs">
            	
                <div class="container">
                	<div class="row">
                    	<div class="col-lg-12">
                        	
                            
                            
                            <!--<ul class="pm-post-navigation">
                            	<li class="pm_tip_static_top" title="Prev. Post"><a href="#" class="fa fa-angle-left"></a></li>
                                <li class="pm_tip_static_top" title="Next Post"><a href="#" class="fa fa-angle-right"></a></li>
                            </ul>-->
                            
                        </div>
                    </div>
                </div>
                
            </div>
        
        </div>
        
 		<!-- Sub-header area end -->
        
        <!-- BODY CONTENT starts here -->
                
        <!-- PANEL 1 -->
        
        <!-- PANEL 2 -->
        <div class="container pm-containerPadding110">
        
        	<div class="row">
            	<div class="col-lg-12 pm-center pm-column-spacing">
                	<h2> Eliminación de Usuarios</h2>
                    <div class="pm-column-title-divider">
                    	<img height="29" width="29" src="img/loguito.png" alt="icon">
                    </div>
                </div>
            </div>
            <form class="form-horizontal" method="POST" action="eliminarusuario.html" onsubmit=" return enviar()">
                <div class="form-group">
    <label for="nombre" class="col-sm-2 control-label">Digite el Usuario que desea eliminar :</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="user" placeholder="Usuario"  autofocus>
    </div>
  </div>
<div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit"  class="btn-danger">Eliminar</input>
    </div>
  </div>
    </form>
    <div id="consi">

    </div>
            
                   
        </div>
        <!-- PANEL 2 end -->
        
        <!-- BODY CONTENT end -->
        
        <div class="pm-fat-footer pm-parallax-panel" data-stellar-background-ratio="0.5">
        	
            <div class="container">
                <div class="row">
                
                    <div class="col-lg-3 col-md-3 col-sm-12 pm-widget-footer">
                    
                    	<h6 class="pm-fat-footer-title"><span>Acerca de</span> GoPrint</h6>
                        <div class="pm-fat-footer-title-divider"></div>
                        
                        <p>GoPrint es una empresa dedicada a brindarle al público en general de un servicio de la más alta calidad</p>
                        
                        
                    </div>
                    
                    
                    <div class="col-lg-3 col-md-3 col-sm-12 pm-widget-footer">
                    
                       <h6 class="pm-fat-footer-title"> <span>Contacte con</span>Goprint</h6>
                       <div class="pm-fat-footer-title-divider"></div>
                       
                       <ul class="pm-general-icon-list">
                       	  <li>
                          	<span class="fa fa-mobile-phone pm-general-icon"></span>
                       		<p> + 51 976048631</p>
                          </li>
                          <li>
                          	<span class="fa fa-inbox pm-general-icon"></span>
                       		<p><a href="mailto:ventas@goprint.pe">ventas@goprint.pe</a></p>
                          </li>
                          <li>
                          	
                       </ul>
                        
                    </div>
                    
                    <div class="col-lg-3 col-md-3 col-sm-12 pm-widget-footer">
                        
                    </div>
                    
                    <div class="col-lg-3 col-md-3 col-sm-12 pm-widget-footer">
                        <ul class="pm-recent-blog-posts">
                            
                     <!-- inicio row -->
                <div id="inner">    
                
<form action="//goprint.us15.list-manage.com/subscribe/post?u=464c045f483e19e26622a8abe&amp;id=55ce164225" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
   
<div class="col-lg-6 col-md-6 col-sm-12">
               <h2>Descuento Especial</h2>             
    <label for="mce-EMAIL">CORREO</label>
  <input type="email" value="" name="EMAIL" class="placeholder" id="mce-EMAIL">
  <label for="mce-FNAME">NOMBRE </label>
  <input type="text" value="" name="FNAME" class="placeholder" id="mce-FNAME">

</div>
  
      <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
    <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_464c045f483e19e26622a8abe_55ce164225" tabindex="-1" value=""></div>
<div class="clear"><button type="submit" value="OBTENER AHORA" name="subscribe" id="mc-embedded-subscribe" class="btn-danger">OBTENER AHORA</button></div>
<div id="mce-responses" class="clear">
    <div class="response" id="mce-error-response" style="display:none"></div>
    <div class="response" id="mce-success-response" style="display:none"></div>
  </div>    
</form>

</div>

<script type='text/javascript' src='//s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js'></script><script type='text/javascript'>(function($) {window.fnames = new Array(); window.ftypes = new Array();fnames[0]='EMAIL';ftypes[0]='email';fnames[1]='FNAME';ftypes[1]='text';fnames[2]='LNAME';ftypes[2]='text';}(jQuery));var $mcj = jQuery.noConflict(true);</script>
 <!-- fin col-lg-3 col-md-4 -->
 <!-- fin row -->
                
</div>
                    <div class="pm-newsletter-form-container">
                            <!-- Begin MailChimp Signup Form -->

<!--End mc_embed_signup-->
                        </div>
                        </div>
                    
                        
                        <ul class="pm-recent-blog-posts">
                            <!-- Post -->
                            
                            <!-- Post end -->
                            <!-- Post -->
                            
                            <!-- Post end -->
                        </ul>
                        
                    </div>
                    
                </div>  
            </div>
            
        </div>
        
        
        <footer>

            
            <div class="container pm-containerPadding20">
            	<div class="row">
                
                	<div class="col-lg-4 col-md-4 col-sm-12 pm-center-mobile">
               	    	<img src="img/logo02.png" width="264" height="81" class="img-responsive pm-inline" alt="GoPrint">
                    </div>
                    
                    <div class="col-lg-8 col-md-8 col-sm-12">
                    	<ul class="pm-footer-navigation">
                        	<li><a href="index1.html" class="active">Inicio</a></li>
                            <li><a href="servicios1.html">Servicios</a></li>
                                <li><a href="blog1.html">Blog</a></li>
                                
                                <li><a href="contactenos1.html">Contactenos</a></li>
                        </ul>
                    </div>
                
                </div>
            </div>

                
        </footer>
                
       
    
    </div><!-- /pm_layout-wrapper -->
    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery-2.1.3.min.js"></script>
    <script src="js/jquery.viewport.mini.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="bootstrap3/js/bootstrap.min.js"></script>
    <script src="js/modernizr.custom.js"></script>
    <script src="js/owl-carousel/owl.carousel.js"></script>
    <script src="js/main.js"></script>
    <script src="js/jquery.tooltip.js"></script>
    <script src="js/superfish/superfish.js"></script>
    <script src="js/superfish/hoverIntent.js"></script>
    <script src="js/stellar/jquery.stellar.js"></script>
    <script src="js/theme-color-selector/theme-color-selector.js"></script>
    <script src="js/meanmenu/jquery.meanmenu.min.js"></script>
    <script src="js/flexslider/jquery.flexslider.js"></script>
    <script src="js/jquery.testimonials.js"></script>
    <script src="js/wow/wow.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.js"></script>
    <script src="js/prettyphoto/js/jquery.prettyPhoto.js"></script>
    <script src="js/tinynav.js"></script>
    <script src="js/jquery-ui.js"></script>
        
    <p id="back-top" class="visible-lg visible-md visible-sm"></p>
    
  </body>
</html>
