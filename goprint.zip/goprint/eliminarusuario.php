<!doctype html>
<html>

<body>
<?php 
include("inc/conexion.php");
if (isset($_POST['user'])) {
	$user = $_POST['user'];
}

$sql = "DELETE FROM usuarios WHERE usuario=:user";
$stmt = $con->prepare($sql);
$stmt->bindParam(':user', $user, PDO::PARAM_STR); 
$stmt->execute();

?>
<script>
alert('El usuario a sido Eliminado exitosamaente');
window.location.href='users.php';
</script>
</body>
</html>
