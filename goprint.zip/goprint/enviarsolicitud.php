<!DOCTYPE HTML>
<html>
<?php
include("inc/class.phpmailer.php");

if (isset($_POST["producto"])) {
	$prod = $_POST["producto"];
}

if (isset($_POST["nombre"])) {
	$nombre = $_POST["nombre"];
}

if (isset($_POST["apellido"])) {
	$apellido = $_POST["apellido"];
}

if (isset($_POST["ciudad"])) {
	$ciudad = $_POST["ciudad"];
}

if (isset($_POST["direccion"])) {
	$direccion = $_POST["direccion"];
}

if (isset($_POST["celular"])) {
	$celular = $_POST["celular"];
}

if (isset($_FILES["archivo"])) {
	$archivo = $_FILES["archivo"];
}


$varname = $_FILES['archivo']['name'];
$vartemp = $_FILES['archivo']['tmp_name'];
$archivo=$_FILES['archivo']; 
$mail = new PHPMailer();

//desde que correo va a llegar
$mail->FromName = $nombre;
$mail->Subject = 'Solicitud de Producto';//el asunto del mail
$mail->AddAddress('ventas@goprint.pe');//te van a llegar a ti los CV
if ($archivo['name'] != "") { //si no esta vacio el nombre adjunta el archivo al correo
$mail->AddAttachment($vartemp, $varname);
}
$mensaje = "La persona : " . $nombre  .  $apellido  . " Del lugar : " . $ciudad . " Numero de Telefono : " . $celular . " Dirección : " . $direccion . " Solicita el siguiente producto: " . $prod;
$mail->Body = $mensaje;//se asigna como cuerpo del mensaje la variable
//interpretará HTML ya que hemos usado la etiqueta <strong>
$mail->Send();//envia el correo
?>
<script>
alert('Tu solicitud ha sido enviada correctamente');
window.location.href='index.php';
</script>


</body>
</html>