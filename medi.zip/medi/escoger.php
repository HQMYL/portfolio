<?php
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}

$pa = "";
if (isset($_GET["id"])) {
	$pa = $_GET["id"];
}


 $sql = "SELECT * FROM especialidad WHERE id_colectivo ='".$pa."'";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
foreach ($rows as $row) {

echo '<div class="width-100" style="margin-left:50px">';
  echo '<div class="left"><input type="checkbox" id="recibirMail" name="espec[]"    style="-webkit-logical-width: 30px!important" value="'. utf8_encode($row->especialidad) .'">';
  echo '</div>';
  echo '<div class="width-75 left"><label class="label-checkbox" for="ajustes_inbox_recibirMail">';
  echo utf8_encode($row->especialidad);
  echo '</label>';
  echo '</div>';
  echo '</div>';
    
}


 ?>