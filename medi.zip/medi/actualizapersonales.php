<?php
include("conexion.php");
session_start();
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}

if (isset($_POST["correo"])) {
	$correo = $_POST["correo"];
}

if (isset($_POST["telefono"])) {
	$tel = $_POST["telefono"];
}







 $sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {

if($correo == $row->correo) {

$sql2 = " UPDATE usuarios SET telefono =:tel WHERE usuario =:usuario ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':tel', $tel, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();

}

if($tel == $row->telefono) {

$sql2 = " UPDATE usuarios SET correo =:correo WHERE usuario =:usuario ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();

}





}

 ?>