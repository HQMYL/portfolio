<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}



if (isset($_POST["homologregion"])) {
	$homolog = utf8_decode($_POST["homologregion"]);
}


if (isset($_POST["homologanyo"])) {
	$homologanyo = utf8_decode($_POST["homologanyo"]);
}




$sql = "INSERT INTO homologacion (usuario,homologado,homologanyo) VALUES (:usuario,:homolog,:homologanyo)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':homolog', $homolog, PDO::PARAM_STR);
$stmt->bindParam(':homologanyo', $homologanyo, PDO::PARAM_STR);
$stmt->execute();
 
?>

<script>
alert('La Homologación a sido agregada exitosamaente');
window.location.href='curriculum.php';
</script>

</body>
<html>