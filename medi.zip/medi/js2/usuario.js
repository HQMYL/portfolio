/**
 * Handlers de eventos
 */

var onAjaxError = function(jqxhr, error, status) {
	console.log(error);
};

var onClickDesinscribirme = function(event){
	event.preventDefault();
	event.stopPropagation();
	
	var papasito = $(this).parents("tr");
	
	if($(this).hasClass("desinscribirme")){
		papasito.after(	"<tr class='no-hover-rechazo'>" +
							"<td colspan='5' style='padding:2%;'>" +
								"<form action='" + $(this).attr('href') + "' method='post'>" +
									"<p><strong>Ayudanos a mejorar Mediempleo: ¿Por qué quieres desinscribirte de esta oferta?</strong></p>" +
									"<label style='margin-right: 5px;margin-top: 5px;'>Motivo del rechazo:</label>" +
									"<select name='motivo' id='motivo-rechazo' style='margin-bottom: 5px; width: 49% !important;'>" +
										"<option value='He cambiado de opinión'>He cambiado de opinión</option>" +
										"<option value='Salario insuficiente'>Salario insuficiente</option>" +
										"<option value='No quiero desplazarme al lugar de la oferta'>No quiero desplazarme al lugar de la oferta</option>" +
										"<option value='No me gusta el puesto ofertado'>No me gusta el puesto ofertado</option>" +
									"</select>" +
									"<textarea name='comentario' style='width:98%'></textarea><br />" +
									"<input class='button button-blue submit rounded-corners-5 submit-desuscripcion' type='submit' value='Desinscribirme'>" +
								"</form>" +
							"</td>" +
						"</tr>"
		);
		
		$(this).removeClass("desinscribirme");
	}
	
	return false;
};

var onClickSubmitDesuscripcion = function(event){
	event.preventDefault();
	event.stopPropagation();
};

var onSuccessDestacarCurriculum = function(json){
	if(json.error==0){
		$("#inscripcion-"+json.id).html("<span class='glyphicon glyphicon-star' title='Destacado!'></span>");
		$("#flash-destacar").show('fast', function(){
			setTimeout(function(){
				$("#flash-destacar").fadeOut('fast');
			}, 5000);
		});
	}else{
		alert("No se ha podido destacar tu inscripción");
	}
};

var onClickDestacarCurriculum = function(){
	var puntos = $(this).attr('data-precio');
	
	if($("#puntosDisponibles").val() < puntos){
		alert("Créditos insuficientes! Por favor, compra más créditos si deseas destacar tu oferta.");
		return false;
	}
	
	var inscripcion = $(this).attr("data-inscripcion");
	var target = Routing.generate('ajax_destacar_inscripcion', {'inscripcion': inscripcion});
	
	if(confirm("Destacar tu currículum tiene un coste de " + puntos + " créditos. Estas seguro de continuar?")){
		$.ajax({
			url: target,
			type:'get',
			dataType: 'json',
			success: onSuccessDestacarCurriculum,
			error: onAjaxError,
			//beforeSend: mostrarCargando,
			//complete: ocultarCargando
		});
	}
};

var onClicEfectoTab = function(){
	$(".efecto-tab").each(function(index,tab){
		var target = $(this).data("target");
		if($(this).hasClass("enlace")){
			$(this).removeClass("enlace");
			$(this).addClass("activo");
			$(target).show();
		} else {
			$(this).removeClass("activo");
			$(this).addClass("enlace");
			$(target).hide();
		}
	});
};

/**
 * Bindings
 */
$(document).ready(function(){
	$(".desinscribirme").on("click", onClickDesinscribirme);
	$(".submit-desuscripcion").on("click", onClickSubmitDesuscripcion);
	$("[data-action='destacar-cv']").on("click", onClickDestacarCurriculum);
    $('#cod-referencia').popover('show');
    $('#cod-referencia').popover('hide');
    $(".efecto-tab").on("click",onClicEfectoTab);
});