/**
 * Variables y configuraciones
 */
var calendarConf = {
		monthNames : ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
		monthNamesShort : ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"],
		dayNames : ["Domingo", "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado"],
		dayNamesMin : ["D", "L", "M", "X", "J", "V", "S"],
		dayNamesShort : ["Dom", "Lun", "Mar", "Mie", "Jue", "Vie", "Sab"],
		dateFormat : "dd/mm/yy",
		firstDay : 1,
		changeMonth : true,
		changeYear : true
};

/**
 * Handlers eventos
 */

var mostrarCargando = function(){
	$("#cargando").show();
};

var ocultarCargando = function(){
	$("#cargando").hide();
};

var onAjaxError = function(jqxhr, status, error){
	console.log("Error de conectividad: " + error);
};

var onSuccessGenerarNotificacion = function(json){
    if(json.error == 0){
        alert("Se ha enviado una notificación a los usuarios");
    }else{
        alert("Error al mandar las notificaciones");
    }
};

var onPaisEstadisticaSuccess = function(json){
	var select = $("#estadisticas-provincia");
    var selectCiudades = $("#estadisticas-ciudad");
	var options = "<option value=' '>Todas</option>";
    if(json.estadisticas.pais == "España")
    {
        $("#div-prov").toggle();
        $.each(json.provincias, function(index, provincia){
            options += "<option value='" + provincia.slug + "'>" + provincia.nombre + "</option>";
        });
        
        select.html(options);
        selectCiudades.html("<option value=' '>Todas</option>");
    }
    else{
        $("#div-prov").hide();
        $.each(json.ciudades, function(index, ciudad){
            options += "<option value='" + ciudad.slug +"'>" + ciudad.nombre + "</option>";
        });
        select.html("<option value=' '>Todas</option>");
        selectCiudades.html(options);
    }
    
	$("#num-empresas").html(json.estadisticas.empresas);
	$("#num-ofertas").html(json.estadisticas.ofertas);
};

var onPaisEstadisticaChange = function(){
	var pais = $(this).val();
	var target = Routing.generate('change_pais', true);
	$.ajax({
		url: target,
		type: "get",
		data: "pais="+pais,
		dataType: "json",
		success: onPaisEstadisticaSuccess,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
};

var onCiudadEstadisticaSuccess = function(estadisticas){
	$("#num-empresas").html(estadisticas.empresas);
	$("#num-ofertas").html(estadisticas.ofertas);
};

var onProvinciaEstadisticaSuccess = function(estadisticas){
    var select = $("#estadisticas-ciudad");
	var options = "<option value=' '>Todas</option>";
	$.each(estadisticas.ciudades, function(index, ciudad){
		options += "<option value='" + ciudad.slug + "'>" + ciudad.nombre + "</option>";
	});
	
	select.html(options);
	$("#num-empresas").html(estadisticas.empresas);
	$("#num-ofertas").html(estadisticas.ofertas);
};

var onCiudadEstadisticaChange = function(){
	var ciudad = $(this).val();
    var provincia = $("#estadisticas-provincia").val();
    var pais = $("#select-paises").val();
	var target = $(this).siblings("label").attr("data-target");
	$.ajax({
		url: target,
		type: "get",
		data: "ciudad="+ciudad+"&provincia="+provincia+"&pais="+pais,
		dataType: "json",
		success: onCiudadEstadisticaSuccess,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
};

var onProvinciaEstadisticaChange = function(){
    var provincia = $(this).val();
    var pais = $("#select-paises").val();
    var target = $(this).siblings("label").attr("data-target");
    $.ajax({
        url: target,
        type: "get",
        data: "provincia="+provincia+"&pais="+pais,
        dataType: "json",
        success: onProvinciaEstadisticaSuccess,
        error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
    });
};

var onClickMenuItem = function(){
	var submenu = $("#"+$(this).attr("data-target"));
	submenu.toggle();			
};	

var onSubmitBuscarCandidatosSuccess = function(json){		
    if(json.usuarios.length > 0){ 
    	$("#div-resultado-busqueda-candidatos").show();
        var precioTotal = 0;
        var template = $("#template-resultados-busqueda").html();
        template = template.replace(/#total#/, json.results);
        template = template.replace(/#num-resultados#/, json.usuarios.length);
        
        if(json.login == true){
	        template = template.replace(/#checkbox#/,"<th>#</th>");
       	} else {
	        template = template.replace(/#checkbox#/,"");
        }
        $("#tabla-resultados-usuarios").html(template);
        $.each(json.usuarios, function(index, user){
            var tr = '<tr data-slug="'+user.slug+'">';
            var target;
            if(json.login == true){
            	target = Routing.generate("pdf_incompleto", {'slug':user.slug});
            } else {
            	target = Routing.generate("login");
            }
            
            if(json.login == true && $.inArray(user.id,json.notificados) < 0){
                tr += '<td><input type="checkbox" name="check-user" class="check-curriculum-user" id="'+user.id+'"/></td>';
            }
            else{
                tr += '<td></td>';
            }
            tr +=   '<td class="user-name">Usuario #'+user.id+'</td>'+
                    '<td>'+user.colectivo+'</td>'+
                    '<td>'+user.pais+'</td>';
                    if(user.pais == "España"){
                    	tr += '<td>'+user.provincia+'</td>';
                    } else {
                    	tr += '<td>-</td>';
                    }
            tr += '<td>'+user.ciudad+'</td>';
            tr += '<td><a href="'+target+'" class="button button-blue" target="_blank">';
            		if(json.login == true){
                        tr += 'Ver';
                   } else {
                        tr += 'Regístrate';
                   }
            tr += '</a></td></tr>';
            $("#tabla-candidatos").append(tr);
        });
        $("#tabla-resultados-usuarios").append("</table></div></div></div>");
        if(json.oferta != null){
            $("#tabla-resultados-usuarios").append('<input type="button" class="button button-blue" value="Notificar usuarios" id="notificar-usuarios" />');
        }
        
        $("#tabla-resultados-usuarios").append("<div id='opciones-tabla' style='width:100%;margin-bottom:20px;float:left;'>");
        if(json.login == true){
            var slugs = "";
            slugs = slugs.substring(0,slugs.length-1);
            var oferta = $("#slug-oferta").val();
            //var ruta = Routing.generate("notificar_usuarios", {"slugs": slugs});
            var templateNotificar = $("#template-notificar").html(); 
            //templateNotificar = templateNotificar.replace(/#ruta-notificar-candidatos#/, ruta);
            $("#opciones-tabla").append(templateNotificar);
        }
        
        var offset = $("#tabla-candidatos tbody tr").length;  
        
        if(offset < json.results){      
	        var templateBtnSiguiente = $("#template-boton-siguiente").html();
	        templateBtnSiguiente = templateBtnSiguiente.replace(/#offset#/, offset);        
        	$("#opciones-tabla").append(templateBtnSiguiente);
        }
        
        $("#tabla-resultados-usuarios").append("</div>");
    
    	$("#select-oferta-notificar").show();
    }
    else{
        $("#tabla-resultados-usuarios").html("<strong>Listado de usuarios</strong><br /><br /><table id='tabla-candidatos' class='resultados-busqueda'><thead><th>Nombre</th><th>Colectivo</th><th>País</th><th>Provincia</th><th>Ciudad</th><th>Nacionalidad</th></thead>");
        var tr = "<tr><td colspan='7' align='center'>No existen datos</td></tr></table></div></div>";
        $("#tabla-candidatos").append(tr);
    }
};

var onSubmitBuscarCandidatos = function(){
	var target =  Routing.generate('ajax_buscar_candidatos', true);
	
	$.ajax({
		url: target,
		type: "post",
		data: $("#form-buscador").serialize(),
		dataType: "json",
		success: onSubmitBuscarCandidatosSuccess,
		error: onAjaxError,
		beforeSend: mostrarCargando,
		complete: ocultarCargando
	});
};

var appendResultadosCandidatos = function(json){
	if(json.usuarios.length > 0){   
		$("#div-resultado-busqueda-candidatos").show();
        $.each(json.usuarios, function(index, user){
            var tr = '<tr data-slug="'+user.slug+'">';
            var target;
            if(json.login == true){
            	target = Routing.generate("pdf_incompleto", {'slug':user.slug});
            } else {
            	target = Routing.generate("login");
            }
            
            if(json.login == true && $.inArray(user.id,json.notificados) < 0){
                tr += '<td><input type="checkbox" name="check-user" class="check-curriculum-user" id="'+user.id+'"/></td>';
            }else{
                tr += '<td></td>';
            }
            tr +=   '<td class="user-name">Usuario #'+user.id+'</td>'+
                    '<td>'+user.colectivo+'</td>'+
                    '<td>'+user.pais+'</td>';
                    if(user.pais == "España"){
                    	tr += '<td>'+user.provincia+'</td>';
                    } else {
                    	tr += '<td>-</td>';
                    }
            tr += '<td>'+user.ciudad+'</td>';
            tr += '<td><a href="'+target+'" class="button button-blue">';
            		if(json.login == true){
                        tr += 'Ver';
                   } else {
                        tr += 'Regístrate';
                   }
            tr += '</a></td></tr>';
            $("#tabla-candidatos").append(tr);
        });
        $("#tabla-resultados-usuarios").append("</table></div></div>");
        if(json.oferta != null){
            $("#opciones-tabla").append('<input type="button" class="button button-blue" value="Notificar usuarios" id="notificar-usuarios" />');
        }
        
        var offset = ($("#tabla-candidatos tbody tr").length) - 1;
        
        if(offset < json.results){
	        var template = $("#template-boton-siguiente").html();        
	        template = template.replace(/#offset#/, offset);
	        $("#opciones-tabla").append(template);
	        $("#num-items").html(offset);
        }else{
        	$("#num-items").html(json.results);
        }
        
        
        
    }
};

var busquedaCandidatosAjax = function(){
    var offset = $(this).attr('data-offset');
    var target = Routing.generate("ajax_buscar_candidatos", {'offset':offset }, true);
    $(this).parent().remove();
    
    $.ajax({
        url: target,
        type: "post",
        data: $("#form-buscador").serialize(),
        dataType: "json",
        success: appendResultadosCandidatos,
        error: onAjaxError,
        beforeSend: function(){
        	$("#tabla-candidatos").append("" +
        			"<tr id='ajax-loader'>" +
        				"<td colspan='7' style='text-align:center'>" +
        				"<img src='/bundles/comun/img/ajax-loader.gif' />"+
        				"</td>" +
        			"</tr>");
        },
        complete: function(){
        	$("#ajax-loader").remove();
        }
    });
};

var onTipoColectivoChangeSuccess = function(json){
	if(json.error == 0){
		if(json.especialidades.length > 0){
			$("#buscador-colectivo").html("");
			var option = "<option value=''>Todos</option>";
			$.each(json.especialidades,function(index,especialidad){
				option += "<option value='"+especialidad.id+"'>"+especialidad.nombre+"</option>";
			});
			$("#buscador-colectivo").append(option);
		}else{
			$("#buscador-colectivo").html("<option value=''>Selecciona un colectivo</option>");
		}
	}
};

var onTipoColectivoChange = function(){
	var colectivo = $("#buscador-tipoColectivo").val();
	$.ajax({
		url: Routing.generate("ajax_cargar_especialidades"),
		type: "get",
		data: {tipoColectivo:colectivo},
		dataType: "json",
		success: onTipoColectivoChangeSuccess,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
};

var onSuccessNotificarUsers = function(json){
	if(json.error == 0){
		alert("Notificación enviada con éxito");
	} else {
		alert("Error al notificar los usuarios "+json.msg);
	}
};

var onSubmitNotificarUsers = function()
{ 
    //event.preventDefault();
    var slugs = "";
    var oferta = $(this).data("oferta");
    
    $("#tabla-candidatos tbody tr td > input").each(function(index, element){
        if($(element).is(":checked")){
            slugs+=$(element).parent().parent().attr('data-slug')+"|";
            $(element).parent().html("");
        }
    });
    
    if(slugs != ""){
    	var ruta;
	    slugs = slugs.substring(0,slugs.length-1);
	    if(oferta != ""){
	    	ruta = Routing.generate("notificar_usuarios", {"slugs": slugs, "oferta":oferta});
	    } else {
	    	ruta = Routing.generate("notificar_usuarios", {"slugs": slugs});
	    }
	    $("#notificar-usuarios").attr("data-target", ruta);
	    
	    $.ajax({
	        url: ruta,
	        type: "get",
	        dataType: "json",
	        error: onAjaxError,
			beforeSend: mostrarCargando,
			complete: ocultarCargando,
	        success: onSuccessNotificarUsers
	    });
	} else {
		alert("Seleccione primero algun usuario");
	}
};

var onSelectPaisChangeSuccess = function(json){
    var selectProvincias = "";
    if($("#estadisticas-provincia").val() != null){
        selectProvincias = $("#estadisticas-provincia");
    }
    else{
        selectProvincias = $("#select-provincias");
    }
    
    var selectCiudades = $("#select-ciudades");
    var options = "<option value=' '>Todas</option>";
    
    if(json.pais == "espana")
    {
        selectProvincias.removeAttr("disabled");
        $.each(json.datos, function(index, provincia){
            options += "<option value='" + provincia.id + "'>" + provincia.nombre + "</option>";
        });
        
        selectProvincias.html(options);
        selectCiudades.html("<option value=' '>Todas</option>");
    }
    else{
        selectProvincias.attr("disabled", "disabled");
        $.each(json.datos, function(index, ciudad){
            options += "<option value='" + ciudad.id +"'>" + ciudad.nombre + "</option>";
        });
        selectProvincias.html("<option value=' '>Todas</option>");
        selectCiudades.html(options);
    }
};

var onSelectPaisesChange = function(){
    var pais = $(this).val();
    var target = Routing.generate('change_pais', true);
    
    $.ajax({
       url: target,
       type: "post",
       data: "pais="+pais,
       dataType: 'json',
       success: onSelectPaisChangeSuccess,
       error: onAjaxError,
       //beforeSend: mostrarCargando,
       //complete: ocultarCargando,
    });
            
};

var onSelectProvinciasChangeSuccess = function(json){
    var selectCiudades = $("#select-ciudades");
    var options = "<option value=' '>Todas</option>";
    
    if(json.length > 0){
        $.each(json, function(index, ciudad){
            options += "<option value='" + ciudad.id + "' >"+ ciudad.nombre + "</option>";
        });
        
        selectCiudades.html(options);
    }
};

var onProvinciaChanged = function(){
    var pais = $("#select-paises").val();
    var provincia = $(this).val();
    var target = Routing.generate('change_provincia', true);
    
    $.ajax({
        url: target,
        type: "post",
        data: "pais=" + pais + "&provincia=" + provincia,
        dataType: "json",
        success: onSelectProvinciasChangeSuccess,
        error: onAjaxError,
        //beforeSend: mostrarCargando,
        //complete: ocultarCargando,
    });
};

var onClickVerDescripcion = function(){
	var objeto = "#"+$(this).attr("data-toggle");
	$(objeto).slideToggle("slow", function() {
		// Animation complete.
	});
};

var onChangeSelectPais = function(){
    if($(this).val() == "espana"){
        $("#id-prov").toggle();
        $("#div-ciudad").toggle();
    }
    else{
        $("#id-prov").hide();
        $("#div-ciudad").hide();
        $("#select-provincias").val("");
        $("#select-ciudad").val("");
    }
};

var onSuccessChangeProvincia = function(json){
    var selectCiudades = $("#select-ciudades");
    var options = "";
    
    if($("#buscador_usuarios_pais").val() != undefined){
    	options = "<option value=' '>Todas</option>";
    }
    
    if(json.length > 0){
        $.each(json, function(index, ciudad){
            options += "<option value='" + ciudad.id + "' >"+ ciudad.nombre + "</option>";
        });
        
        selectCiudades.html(options);
    }
};

var onChangeProvincia = function(){
    var pais = "";
    
    if($("#mediempleo_empresabundle_editardatosfacturacionempresatype_pais").val() != undefined){
        pais = $("#mediempleo_empresabundle_editardatosfacturacionempresatype_pais").val();
    }
    else if($("#mediempleo_empleobundle_centrotype_pais").val() != undefined){
    	pais = $("#mediempleo_empleobundle_centrotype_pais").val();
    }
    else if($("#select-paises").val() != undefined){
        pais = $("#select-paises").val();
    }
    else if($("#movilidad_curriculum_pais").val() != undefined){
        pais = $("#movilidad_curriculum_pais").val();
    }
    else if($("#buscador_usuarios_pais").val() != undefined){
    	pais = $("#buscador_usuarios_pais").val();
    }
    else{
        pais = $("#select-pais").val();
    }
    
    var provincia = $(this).val();
    var target = Routing.generate('change_provincia', true);
            
    $.ajax({
        url: target,
        type: "get",
        data: "pais=" + pais + "&provincia=" + provincia,
        dataType: "json",
        success: onSuccessChangeProvincia,
        error: onAjaxError
        //beforeSend: mostrarCargando,
        //complete: ocultarCargando,
    });
};

var onSuccessSugerenciaFiltro = function(json){
	$("#formFiltros").modal('hide');
	$('#myModal').on('hidden.bs.modal', function () {
		if(json.error == 0){
			alert("Gracias por tu colaboración!");
		}else{
			alert("Tu formulario no se ha podido enviar. Intentalo de nuevo más tarde");
		}
	});
};

var submitSugerenciaFiltro = function(){
	var nombre = $("#nombre-filtro").val();
	var descripcion = $("#descripcion-filtro").val();
	var target = Routing.generate('form_filtro_sugerido');
	
	$.ajax({
		url: target,
		type: "post",
		dataType:"json",
		data: "nombre="+nombre+"&descripcion="+descripcion,
		success: onSuccessSugerenciaFiltro,
		error: onAjaxError
        //beforeSend: mostrarCargando,
        //complete: ocultarCargando,
	});
};

var onClickCheckBoxCurriculum = function(){
    var precio = parseInt($("#precio-curriculum").val());
    var elementos = parseInt($(".check-curriculum-user:checked").length);
    
    $("#casilla-importe").text(precio*elementos);
    
    if($(this).is(":checked")){
        if(parseInt($("#casilla-importe").html()) > parseInt($("#saldo-empresa").val())){
            alert("Tu saldo de créditos es insuficiente para la selección realizada");
        }
    }
};

var onSubmitComprarSeleccionados = function(){
    var seleccionados = $(".check-curriculum-user:checked");
    var param = "";
    var oferta = $(this).data("oferta");
    $.each(seleccionados, function(index, item){
		param+=$(item).attr("id")+"|";
	});
	param = param.substring(0, param.length-1);

    if(parseInt($("#casilla-importe").html()) < parseInt($("#saldo-empresa").val())){
        var targetCompra = Routing.generate("compra_curriculum_sin_oferta", {id: param}, true);
        if(oferta != undefined && oferta != ""){
        	targetCompra += "?oferta="+oferta;
        }
        
        $("#ref-compra").attr("href", targetCompra);
    }
    else{
        alert("Tu saldo de créditos es insuficiente para la selección realizada");
    }
};

var onClickCompraPuntosInSitu = function(){
    $("#formulario-compra-insitu").toggle();
};

var onSuccessChangePais = function(json){
    var selectProvincias = $("#select-provincias");
    var selectCiudades = $("#select-ciudades");
    //var options = "<option value=' '>Todas</option>";
    var options = "";
    
    if(json.pais == "espana"){
        $("#select-provincias").removeAttr("disabled");
        $.each(json.datos, function(index, provincia){
                options += "<option value='" + provincia.id + "'>" + provincia.nombre + "</option>";
        });
        selectProvincias.html("");
        selectProvincias.html(options);
        selectCiudades.html("<option value=' '></option>");
    }
    else{
        $("#select-provincias").html("<option value=' '> </option>");
        $("#select-provincias").attr("disabled", "disabled");
        $.each(json.datos, function(index, ciudad){
            options += "<option value='" + ciudad.id + "'>" + ciudad.nombre + "</option>";
        });
        
        selectProvincias.html("");
        selectCiudades.html("");
        selectCiudades.html(options);
    }
};

var onChangePais = function(){
    var pais = $(this).val();
    var target = Routing.generate('change_pais', true);
    
	$.ajax({
		url: target,
		dataType: "json",
		data: "pais=" + pais,
		type: "post",
		success: onSuccessChangePais,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
};

var onClicVerMas = function(event){
	if($("#ver-mas").val() == "Ver más"){
		$("#ver-mas").val("Ocultar");
		$("#grupo-colectivos").css("max-height","");
	} else {
		$("#ver-mas").val("Ver más");
		$("#grupo-colectivos").css("max-height","145px");
	}
};

var onClickCompraPuntosPopUp = function(){
    window.open($(this).attr("href"), $(this).attr("target"), style='width=800,height=600');
    return false;
};

var validateEmail = function(email) {
	var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
	
	if (!filter.test(email)) {
		return false;
	}
	
	return true;
};

var onClickAccionAvanzadaVisto = function(){
    var target = Routing.generate("habilitar_ver_empresas_visto_curriculum", true);
    
    var res = confirm("Esta acción te descontará 3 puntos ¿Deseas continuar?");
    
    if(res == true){
        $.ajax({
            url: target,
            dataType: "json",
            type: "post",
            success: function(){ location.reload(); },
            error: onAjaxError
	        //beforeSend: mostrarCargando,
	        //complete: ocultarCargando,
        });
    }
};


var onClickAccionAvanzadaCompra = function(){
    var target = Routing.generate("habilitar_ver_empresas_comprado_curriculum", true);
    
    var res = confirm("Esta acción te descontará 3 puntos ¿Deseas continuar?");
    
    if(res == true){
        $.ajax({
            url: target,
            dataType: "json",
            type: "post",
            success: function(){ location.reload(); },
            error: onAjaxError
	        //beforeSend: mostrarCargando,
	        //complete: ocultarCargando,
        });
    }
};

var onClickNuevoInputIdioma = function(){
    var template = $("#template-btn-add-idioma").html();
    $("#gap-idiomas").append(template);
    
    var numeroInputs = $(".form-control.idioma").length;
    $("#num-inputs-language").val(numeroInputs);
    
    var inputsIdioma = $(".form-control.idioma");
    inputsIdioma[numeroInputs - 1].name = "idioma"+numeroInputs;
};

var onFocusInputIdiomaPadre = function(){
    $("#nivel-idiomas").toggle();
};

var onClickBannerMedicalEnglish = function(event){
	event.preventDefault();
	
	var url = Routing.generate("log_link",{tipo:"MedicalEnglish",url:"https://www.medpharmjobs.com/medical-english/landing?a_aid=53343e9085647&a_bid=d6b2c4c5&a_rid=11421235"});
	
	window.open(url,'_blank');
};

var onChangeTipoEmpresa = function(){
	var opcion = $(this).val();
	$("#mediempleo_empresabundle_registroempresatype_tipo").val(opcion);
	if(opcion == ""){
		$("#tipo-empresa").show();
	} else {
		$("#tipo-empresa").hide();
	}
};

/**
 * Triggers y bindings
 */
$(document).ready(function(){
	$(".datepicker").datepicker(calendarConf);
    
	$(".menu-titulo").on("click",onClickMenuItem);
    
	$("#submit-buscar-candidatos").on("click", onSubmitBuscarCandidatos);
	$("#buscador-tipoColectivo").on("change",onTipoColectivoChange);
    $("#tabla-resultados-usuarios").on("click", "#notificar-usuarios", onSubmitNotificarUsers);
    $("#propuesta-candidatos").on("click", "#notificar-usuarios", onSubmitNotificarUsers);
    
    $("#select-pais").on("change", onChangeSelectPais);
    $("#select-provincias").on("change", onChangeProvincia);
    $(".ver-descripcion").on("click",onClickVerDescripcion);

    $("a[data-role='dropdown-menu-cabecera']").on("click",function(event){
        event.preventDefault();
        var id = $(this).attr("data-submenu");
        $(".menu-dropdown[id!='" + id + "']").hide();
        $(this).siblings(".menu-dropdown").toggle();
    });
    
    
    $("#submit-form-filtro").on("click", submitSugerenciaFiltro);
    $("[data-rel='marcar-curriculum']").on("click",".check-curriculum-user" , onClickCheckBoxCurriculum);
    $("[data-rel='marcar-curriculum']").on("click","#comprar-curriculums-seleccionados" , onSubmitComprarSeleccionados);
    
    $("#texto-compra-puntos").on("click", onClickCompraPuntosInSitu);
    
    $("#buscador_usuarios_pais").on("change", onSelectPaisesChange);
    
    $("#carga-ajax").on("click", "#buscar-candidatos-siguiente", busquedaCandidatosAjax);
    
    $("#ver-mas").on("click",onClicVerMas);

    $("#tabla-resultados-usuarios").on("click", "#buscar-candidatos-siguiente", busquedaCandidatosAjax);
    
    $("#compra-puntos-popup").on("click", onClickCompraPuntosPopUp);
    
    $('.caracteristicas-avanzadas-visto').popover('show');
    $('.caracteristicas-avanzadas-visto').popover('hide');
    
    $('.caracteristicas-avanzadas-compra').popover('show');
    $('.caracteristicas-avanzadas-compra').popover('hide');
    
    $("#enable-accion-avanzada-visto").on("click", onClickAccionAvanzadaVisto);
    $("#enable-accion-avanzada-compra").on("click", onClickAccionAvanzadaCompra);
    
    $("#btn-add-idioma").on("click", onClickNuevoInputIdioma);
    $("#input-idioma-padre").on("focus", onFocusInputIdiomaPadre);
    
    $("#form-recomendar").on("change", ".input-incremental", function(){		
		if(validateEmail($(this).val())) {
			$(this).parents(".input-group").removeClass("has-error");
			$(this).next("span").remove();
			var tmpl = $("#template-input-email").html();
			var index = parseInt($(this).attr("data-index")) + 1;
			tmpl = tmpl.replace(/#/g, index);
			$("#emails-block").append(tmpl);
			$("input[data-index='" + index + "']").focus();
		}else if($(this).val()==''){
			if(!$(this).hasClass('fixed')){
				$(this).parents(".input-group").remove();
			}
		}else{
			$(this).parents(".input-group").addClass("has-error");
			$(this).next("span").show();
		}
	});
	
	$(".banner-medical-english").on('click',onClickBannerMedicalEnglish);
	
	$("#mediempleo_empresabundle_registroempresatype_opcionesTipo").on("change",onChangeTipoEmpresa);
});
