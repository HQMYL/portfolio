/**
 * Handlers de eventos
 */

var onAjaxError = function(jqxhr, error, status){
	console.log(error);
}

var onEliminarAvatarSuccess = function(json){
	if(json.error == 0){
		$("#texto-porcentaje").html(json.porcentaje+" %");
		
		var relativa = $("#avatar").attr("src");
		relativa = relativa.substr(0,relativa.lastIndexOf("/")+1);
		$("#avatar").attr("src", relativa+json.avatar);
		$("#eliminar-avatar").remove();
		console.log(relativa+json.avatar);
	}else{
		alert(json.message);
	}
}

var onClickEliminarAvatar = function(event){
	event.preventDefault();
	
	var target = Routing.generate('curriculum_delete_avatar', true);
	
	$.ajax({
		url: target,
		type: "post",
		dataType: "json",
		success: onEliminarAvatarSuccess,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
}

var onAddIdiomaSuccess = function(json){
	if(json.error==0){
		$("#texto-porcentaje").html(json.porcentaje+" %");
		var target = Routing.generate('curriculum_del_idioma',{id:json.idioma.id}, true);
		
		var tr = "<tr id='idioma-"+json.idioma.id+"'>"+
				"<td>"+json.idioma.nombre+
				"</td><td>"+json.idioma.nivelHablado+
				"</td><td>"+json.idioma.nivelEscrito+
				"</td><td>"+json.idioma.nivelLeido+
				'</td><td style="text-align:right;"><img src="/bundles/comun/img/iconos/trash-26.png" alt="Eliminar idioma" width="15" data-target="'+target+'" data-rel="delete-idioma" /></td></tr>"';
		if($("#tabla-idiomas tbody tr:first td").length == 1){
			$("#tabla-idiomas tbody").html(tr);
		}else{
			$("#tabla-idiomas tbody").append(tr);
		}
		
		$("#idioma_curriculum_idioma option[value='"+json.idioma.idIdioma+"']").remove();
	}else{
		var msg = "Ha ocurrido un error al añadir el idioma\n";
		$.each(json.message,function(index,campo){
			msg += index+": "+campo+'\n';
		});
		alert(msg);
	}
}

var onClickAddIdioma = function(event){
	event.preventDefault();
	
	var target = Routing.generate('curriculum_add_idioma', true);
	
	$.ajax({
		url: target,
		type: "post",
		data: $("#form-idioma").serialize(),
		dataType: "json",
		success: onAddIdiomaSuccess,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
}

var onAddCursoSuccess = function(json){
	if(json.error==0){
		$("#texto-porcentaje").html(json.porcentaje+" %");
		var target = Routing.generate('curriculum_del_curso',{id:json.curso.id}, true);
		
		var tr = "<tr id='curso-"+json.curso.id+"'>"+
				"<td>"+json.curso.nombre+"</td>"+
				"<td>"+json.curso.horas+
				"h</td><td>"+json.curso.creditos+
				"</td><td>"+json.curso.fechaFin+				
				"</td><td>"+json.curso.lugar+
				'</td><td style="text-align:right;"><img src="/bundles/comun/img/iconos/trash-26.png" alt="Eliminar curso" width="15" data-target="'+target+'" data-rel="delete-curso" /></td></tr>"';
		if($("#tabla-cursos tbody tr:first td").length == 1){
			$("#tabla-cursos tbody").html(tr);
		}else{
			$("#tabla-cursos tbody").append(tr);
		}
	}else{
		var msg = "Ha ocurrido un error al añadir el curso\n";
		$.each(json.message,function(index,campo){
            if(index == "fechaFin") msg += "fecha de fin: "+campo+"\n"
            else msg += index+": "+campo+'\n';
		});
		alert(msg);
	}
}

var onClickAddCurso = function(event){
	event.preventDefault();
	
	var target = Routing.generate('curriculum_add_curso', true);
	console.log(target);
	
	$.ajax({
		url: target,
		type: "post",
		data: $("#form-curso").serialize(),
		dataType: "json",
		success: onAddCursoSuccess,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
}

var onAddEspecialidadSuccess = function(json){
	if(json.error==0){
		$("#texto-porcentaje").html(json.porcentaje+" %");
		var target = Routing.generate('curriculum_del_especialidad',{id:json.especialidad.id}, true);
		
		var tr = "<tr id='especialidad-"+json.especialidad.id+"'>"+
				"<td>"+json.especialidad.nombre+
				"</td><td>"+json.especialidad.anyo+
				"</td><td>"+json.especialidad.lugar+
				"</td><td>"+json.especialidad.cursada+
				"</td><td>"+json.especialidad.pais+
				'</td><td style="text-align:right;"><img src="/bundles/comun/img/iconos/trash-26.png" alt="Eliminar especialidad" width="15" data-target="'+target+'" data-rel="delete-especialidad" /></td></tr>"';
		if($("#tabla-especialidades tbody tr:first td").length == 1){
			$("#tabla-especialidades tbody").html(tr);
		}else{
			$("#tabla-especialidades tbody").append(tr);
		}
		
		$("#especialidad_curriculum_especialidad option[value='"+json.especialidad.idEspecialidad+"']").remove();
	}else{
		var msg = "Ha ocurrido un error al añadir la especialidad\n";
		$.each(json.message,function(index,campo){
			msg += index+": "+campo+'\n';
		});
		alert(msg);
	}
}

var onClickAddEspecialidad = function(event){
	event.preventDefault();
	
	var target = Routing.generate('curriculum_add_especialidad', true);
	
	$.ajax({
		url: target,
		type: "post",
		data: $("#form-especialidad").serialize(),
		dataType: "json",
		success: onAddEspecialidadSuccess,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
}

var onAddExperienciaSuccess = function(json){
	if(json.error==0){
		$("#texto-porcentaje").html(json.porcentaje+" %");
		var target = Routing.generate('curriculum_del_experiencia',{id:json.experiencia.id}, true);
		
		var tr = "<tr id='experiencia-"+json.experiencia.id+"'>"+
				"<td>"+json.experiencia.empresa+
				"</td><td>"+json.experiencia.fechaInicio+
				"</td><td>"+json.experiencia.fechaFin+
				"</td><td>"+json.experiencia.unidad+
				"</td><td>"+json.experiencia.funcion+
				"</td><td>"+json.experiencia.pais+
				'</td><td style="text-align:right;"><img src="/bundles/comun/img/iconos/trash-26.png" alt="Eliminar experiencia" width="15" data-target="'+target+'" data-rel="delete-experiencia" /></td></tr>"';
		if($("#tabla-experiencias tbody tr:first td").length == 1){
			$("#tabla-experiencias tbody").html(tr);
		}else{
			$("#tabla-experiencias tbody").append(tr);
		}
	}else{
		var msg = "Ha ocurrido un error al añadir la experiencia\n";
		$.each(json.message,function(index,campo){
			msg += index+": "+campo+'\n';
		});
		alert(msg);
	}
}

var onClickAddExperiencia = function(event){
	event.preventDefault();
	
	var target = Routing.generate('curriculum_add_experiencia', true);
	
	$.ajax({
		url: target,
		type: "post",
		data: $("#form-experiencia").serialize(),
		dataType: "json",
		success: onAddExperienciaSuccess,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
}

var onAddMovilidadSuccess = function(json){
    if(json.error == 0){ 
        var ciudad = "";
        if(json.movilidad.ciudad == null) ciudad = "Todas";
        else ciudad = json.movilidad.ciudad;
        var target = Routing.generate("curriculum_del_movilidad", {id:json.movilidad.id}, true);
        
        var tr = "<tr id='movilidad-"+json.movilidad.id+"'>"+
				"<td>"+json.movilidad.pais+
				"</td><td>"+ciudad+
				'</td><td style="text-align:right;"><img src="/bundles/comun/img/iconos/trash-26.png" alt="Eliminar movilidad" width="15" data-target="'+target+'" data-rel="delete-movilidad" /></td></tr>"';
		if($("#tabla-movilidad tbody tr:first td").length == 1){
			$("#tabla-movilidad tbody").html(tr);
		}else{
			$("#tabla-movilidad tbody").append(tr);
		}
    }
    else{
        var msg = "Ha ocurrido un error al añadir la movilidad\n";
		$.each(json.message,function(index,campo){
			msg += index+": "+campo+'\n';
		});
		alert(msg);
    }
}

var onClickAddMovilidad = function(event){
    event.preventDefault();
    
    var target = Routing.generate("curriculum_add_movilidad", true);
    
    $.ajax({
        url: target,
        type: "post",
        data: $("#form-movilidad").serialize(),
        dataType: "json",
        success: onAddMovilidadSuccess,
        error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
    });
}

var onAddHomologacionSuccess = function(json){
	if(json.error==0){
		$("#texto-porcentaje").html(json.porcentaje+" %");
		var target = Routing.generate('curriculum_del_homologacion',{id:json.homologacion.id}, true);
		
		var tr = "<tr id='homologacion-"+json.homologacion.id+"'>"+
				"<td>"+json.homologacion.region+
				"</td><td>"+json.homologacion.anyo+
				'</td><td style="text-align:right;"><img src="/bundles/comun/img/iconos/trash-26.png" alt="Eliminar homologación" width="15" data-target="'+target+'" data-rel="delete-homologacion" /></td></tr>"';
		
		if($("#tabla-homologaciones tbody tr:first td").length == 1){
			$("#tabla-homologaciones tbody").html(tr);
		}else{
			$("#tabla-homologaciones tbody").append(tr);
		}
		
	}else{
		var msg = "Ha ocurrido un error al añadir la homologación\n";
		$.each(json.message,function(index,campo){
			msg += index+": "+campo+'\n';
		});
		alert(msg);
	}
}

var onClickAddHomologacion = function(event){
	event.preventDefault();
	
	var target = Routing.generate('curriculum_add_homologacion', true);
	
	$.ajax({
		url: target,
		type: "post",
		data: $("#form-homologacion").serialize(),
		dataType: "json",
		success: onAddHomologacionSuccess,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
}

var onClickDelIdiomaSuccess = function(json){
	if(json.error==0){
		$("#idioma-"+json.id).fadeOut(1000,function(){ $(this).remove(); });
		var ultimo = $("#tabla-idiomas tbody tr").length;
		if( ultimo == 1){
			$("#tabla-idiomas tbody ").html("<tr><td style='text-align:center;' colspan='5'>No has añadido todavía ningún curso. A que esperas!</td></tr>");
		}
		$("#texto-porcentaje").html(json.porcentaje+" %");
		
		var option = "<option value='"+json.idIdioma+"'>"+json.nombre+"</option>";
		$("#idioma_curriculum_idioma").append(option);
	}else{
		alert("No se ha podido eliminar el idioma");
	}
}

var onClickDelIdioma = function(event){
	var respuesta = confirm("Esta a punto de eliminar un idioma. ¿Seguro que quiere eliminarlo?");
	
	if(respuesta){
		var target = $(this).attr("data-target");
		
		$.ajax({
			url: target,
			type: "post",
			dataType: "json",
			success: onClickDelIdiomaSuccess,
			error: onAjaxError,
			//beforeSend: mostrarCargando,
			//complete: ocultarCargando,
		});
	} else {
		return false;
	}
}

var onClickDelEspecialidadSuccess = function(json){
	if(json.error==0){
		$("#especialidad-"+json.id).fadeOut(1000,function(){ $(this).remove(); });
		var ultimo = $("#tabla-especialidades tbody tr").length;
		if( ultimo == 1){
			$("#tabla-especialidades tbody ").html("<tr><td style='text-align:center;' colspan='6'>No has añadido todavía ninguna especialidad. A que esperas!</td></tr>");
		}
		$("#texto-porcentaje").html(json.porcentaje+" %");
		
		var option = "<option value='"+json.idEspecialidad+"'>"+json.nombre+"</option>";
		$("#especialidad_curriculum_especialidad").append(option);
	}else{
		alert("No se ha podido eliminar la especialidad");
	}
}

var onClickDelEspecialidad = function(event){
	var respuesta = confirm("Esta a punto de eliminar una especialidad. ¿Seguro que quiere eliminarla?");
	
	if(respuesta){
		var target = $(this).attr("data-target");
		
		$.ajax({
			url: target,
			type: "post",
			dataType: "json",
			success: onClickDelEspecialidadSuccess,
			error: onAjaxError,
			//beforeSend: mostrarCargando,
			//complete: ocultarCargando,
		});
	} else {
		return false;
	}
}

var onClickDelCursoSuccess = function(json){
	if(json.error==0){
		$("#curso-"+json.id).fadeOut(1000,function(){ $(this).remove(); });
		var ultimo = $("#tabla-cursos tbody tr").length;
		if( ultimo == 1){
			$("#tabla-cursos tbody ").html("<tr><td style='text-align:center;' colspan='5'>No has añadido todavía ningún curso. A que esperas!</td></tr>");
		}
		$("#texto-porcentaje").html(json.porcentaje+" %");
	}else{
		alert("No se ha podido eliminar el curso");
	}
}

var onClickDelCurso = function(event){
	var respuesta = confirm("Esta a punto de eliminar un curso. ¿Seguro que quiere eliminarlo?");
	
	if(respuesta){
		var target = $(this).attr("data-target");
		
		$.ajax({
			url: target,
			type: "post",
			dataType: "json",
			success: onClickDelCursoSuccess,
			error: onAjaxError,
			//beforeSend: mostrarCargando,
			//complete: ocultarCargando,
		});
	} else {
		return false;
	}
}

var onClickDelExperienciaSuccess = function(json){
	if(json.error==0){
		$("#experiencia-"+json.id).fadeOut(1000,function(){ $(this).remove(); });
		var ultimo = $("#tabla-experiencias tbody tr").length;
		if( ultimo == 1){
			$("#tabla-experiencias tbody ").html("<tr><td style='text-align:center;' colspan='7'>No has añadido todavía ninguna especialidad. A que esperas!</td></tr>");
		}
		$("#texto-porcentaje").html(json.porcentaje+" %");
	}else{
		alert("No se ha podido eliminar la experiencia");
	}
}

var onClickDelExperiencia = function(event){
	var respuesta = confirm("Esta a punto de eliminar una experiencia laboral. ¿Seguro que quiere eliminarla?");
	
	if(respuesta){
		var target = $(this).attr("data-target");
		
		$.ajax({
			url: target,
			type: "post",
			dataType: "json",
			success: onClickDelExperienciaSuccess,
			error: onAjaxError,
			//beforeSend: mostrarCargando,
			//complete: ocultarCargando,
		});
	} else {
		return false;
	}
}

var onDelHomologacionSuccess = function(json){
	if(json.error==0){
		$("#homologacion-"+json.id).fadeOut(1000,function(){ $(this).remove(); });
		var ultimo = $("#tabla-homologaciones tbody tr").length;
		if( ultimo == 1){
			$("#tabla-homologaciones tbody ").html("<tr><td style='text-align:center;' colspan='3'>No has añadido ninguna homologación</td></tr>");
		}
		$("#texto-porcentaje").html(json.porcentaje+" %");
	}else{
		alert("No se ha podido eliminar la homologación");
	}
}

var onClickDelHomologacion = function(event){
	var respuesta = confirm("Esta a punto de eliminar una homologación. ¿Seguro que quiere eliminarla?");
	
	if(respuesta){
		var target = $(this).attr("data-target");
		
		$.ajax({
			url: target,
			type: "post",
			dataType: "json",
			success: onDelHomologacionSuccess,
			error: onAjaxError,
			//beforeSend: mostrarCargando,
			//complete: ocultarCargando,
		});
	} else {
		return false;
	}
}

var onClickDelMovilidadSuccess = function(json){
    if(json.error == 0){
        $("#movilidad-"+json.id).fadeOut(1000, function(){ $(this).remove(); });
        var ultimo = $("#tabla-movilidad tbody tr").length;
        if(ultimo == 1){
            $("#tabla-movilidad tbody").html("<tr><td style='text-align:center;' colspan='3'>No has añadido ninguna homologación</td></tr>");
        }
    }
    else{
        alert("No se ha podido eliminar el registro de movilidad");
    }
}

var onClickDelMovilidad = function(json){
    var respuesta = confirm("Está a punto de eliminar un registro de movilidad geográfica. ¿Está seguro?");
    
    if(respuesta)
    {
        var target = $(this).attr("data-target");
        
        $.ajax({
            url: target,
            type: "post",
            dataType: "json",
            success: onClickDelMovilidadSuccess,
            error: onAjaxError,
			//beforeSend: mostrarCargando,
			//complete: ocultarCargando,
        });
    }
}

var onClickCarreraTerminada = function(){
	if(this.checked == true){
		$("#curso-actual").hide();
		$("#curso-actual").val(" ");
		$("#anyo-finalizacion").show();
	} else {
		$("#anyo-finalizacion").hide();
		$("#anyo-finalizacion").val(" ");
		$("#curso-actual").show();
	}
}


var onChangeColegiado = function(){
    if($("#curriculum_colegiado").val() == "Sí"){ 
        $(".curriculum_numColegiado").removeClass("no-visible");
    }
    else{
        $(".curriculum_numColegiado").addClass("no-visible");
        $("#curriculum_numColegiado").val("");
    }  
}

var onSuccessChangeProvincias = function(json){
	var select = $("#select-ciudades-movilidad");
    var options = "<option value='Todas'>Todas</option>";
    
    if(json != "")
    {
        $.each(json, function(index, ciudad){
            options += "<option value='" + ciudad.id + "'>" + ciudad.nombre + "</option>";
        });
    }
	
	select.html(options);
}

var onChangePaisMovilidad = function(){
    if($("#movilidad_curriculum_pais option:selected").html() == "España")
    {
        $("#prov-mov").attr("style", "visibility:visible");
        $("#ciudad-mov").attr("style", "visibility:visible");
    }
    else
    {
        $("#prov-mov").attr("style", "visibility:hidden");
        $("#ciudad-mov").attr("style", "visibility:hidden");
    }
}

var onChangeProvinciasMovilidad = function(json){
    var pais = $("#movilidad_curriculum_pais").val();
    var provincia = $(this).val();
	var target = $(this).siblings("label").attr("data-target");
    
	$.ajax({
		url: target,
		dataType: "json",
		data: "pais=" + pais +"&provincia=" + provincia,
		type: "get",
		success: onSuccessChangeProvincias,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
};

var onKeyPressPresentacionCurriculum = function(event){
    if(event.charCode >= 48 && event.charCode <= 57){
        alert("No se pueden insertar valores numéricos en este campo");
        event.preventDefault();
    }
    
};

/**
 * Bindings
 */
$(document).ready(function(){
	$("#eliminar-avatar").on("click", onClickEliminarAvatar);
	$("#add-idioma").on("click", onClickAddIdioma);
	$("#add-curso").on("click", onClickAddCurso);
	$("#add-especialidad").on("click", onClickAddEspecialidad);
	$("#add-experiencia").on("click", onClickAddExperiencia);
	$("#add-homologacion").on("click", onClickAddHomologacion);
	$("#tabla-idiomas").on("click", "[data-rel='delete-idioma']", onClickDelIdioma);
	$("#tabla-especialidades").on("click", "[data-rel='delete-especialidad']", onClickDelEspecialidad);
	$("#tabla-cursos").on("click", "[data-rel='delete-curso']", onClickDelCurso);
	$("#tabla-experiencias").on("click", "[data-rel='delete-experiencia']", onClickDelExperiencia);
	$("#tabla-homologaciones").on("click", "[data-rel='delete-homologacion']", onClickDelHomologacion);
    $("#tabla-movilidad").on("click", "[data-rel='delete-movilidad']", onClickDelMovilidad);
	$("#carrera-terminada").on("click",onClickCarreraTerminada);
    $("#curriculum_colegiado").on("change", onChangeColegiado);
    $("#movilidad_curriculum_pais").on("change", onChangePaisMovilidad);
    //$("#form-movilidad").on("change", "#select-provincias", onChangeProvinciasMovilidad);
    $("#add-movilidad").on("click", onClickAddMovilidad);
    $("a[rel='fancybox']").fancybox({
        'hideOnContentClick': true, 
        'showCloseButton': true, 
        'easingIn': 'swing',
        'easingOut': 'swing',
        'transitionIn': 'elastic',
        'transitionOut': 'elastic',
        'enableEscapeButton': true
    });
    $("#curriculum_presentacion").on("keypress", onKeyPressPresentacionCurriculum);
});