/**
 * Handlers
 */

var onSuccessMarcarLeido = function(json){
	if(json.error == 0){
		$("#mensaje-"+json.id).removeClass("no-leido").addClass("leido");
		var nuevoInput = "<input data-rel='marcar-no-leido' data-item='"+json.id+"' type='image' style='height:24px;' title='Marcar como no leído' src='/bundles/usuario/img/mail-read-fondo.png' />";
		$("#mensaje-"+json.id+" [data-rel='marcar-leido']").replaceWith(nuevoInput);
	}else{
		alert(json.msg);
	}
};

var onClickMarcarLeido = function(){
	var id = $(this).attr("data-item");
	var target = Routing.generate('usuario_inbox_leido', {'id': id}, true);
	
	$.ajax({
		url: target,
		type: "get",
		dataType: "json",
		success: onSuccessMarcarLeido,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
};

var onSuccessMarcarNoLeido = function(json){
	if(json.error == 0){
		$("#mensaje-"+json.id).removeClass("leido").addClass("no-leido");
		var nuevoInput = "<input data-rel='marcar-leido' data-item='"+json.id+"' type='image' style='height:24px;' title='Marcar como leído' src='/bundles/usuario/img/mail-unread-fondo.png' />";
		$("#mensaje-"+json.id+" [data-rel='marcar-no-leido']").replaceWith(nuevoInput);
	}else{
		alert(json.msg);
	}
};

var onClickMarcarNoLeido = function(){
	var id = $(this).attr("data-item");
	var target = Routing.generate('usuario_inbox_no_leido', {'id': id}, true);
	
	$.ajax({
		url: target,
		type: "get",
		dataType: "json",
		success: onSuccessMarcarNoLeido,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
};


var onSuccessEliminarMensaje = function(json){
	if(json.error == 0){
		$("#mensaje-"+json.id).fadeOut("slow", function(){ $(this).remove() });
	}else{
		alert(json.msg);
	}
};

var onClickEliminarMensaje = function(){
	var id = $(this).attr("data-item");
	var target = Routing.generate('usuario_inbox_eliminar_mensaje', {'id': id}, true);
	
	if(confirm("Estas seguro de querer eliminar este mensaje?\n\nLos mensajes eliminados no pueden ser recuperados.")) {
		$.ajax({
			url: target,
			type: "get",
			dataType: "json",
			success: onSuccessEliminarMensaje,
			error: onAjaxError,
			//beforeSend: mostrarCargando,
			//complete: ocultarCargando,
		});
	}
	
};


var togglePeriodicidad = function(){
	if($("#ajustes_inbox_recibirMail").is(":checked")){
		$("#ajustes_inbox_periodicidad").removeAttr("disabled");
	}else {
		$("#ajustes_inbox_periodicidad").attr("disabled", "disabled");
	}
};

var getSeleccionados = function(){
	var seleccionados = $(".selector-mensajes:checked");
	var q = "";
	
	$.each(seleccionados, function(index, item){
		q+=$(item).val()+"-";
	});
	q = q.substring(0, q.length-1);

	return q;
};

var onSuccessMarcarConjuntoLeidos = function(json){
	if(json.error==0){
		$.each(json.ids, function(index, id){
			$("#mensaje-"+id).removeClass("no-leido").addClass("leido");
			var nuevoInput = "<input data-rel='marcar-no-leido' data-item='"+id+"' type='image' style='height:24px;' title='Marcar como no leído' src='/bundles/usuario/img/mail-read-fondo.png' />";
			$("#mensaje-"+id+" [data-rel='marcar-leido']").replaceWith(nuevoInput);
		});
	}else{
		alert(json.msg);
	}
};

var marcarConjuntoLeidos = function(){
	var q = getSeleccionados();
	
	var target = Routing.generate('usuario_inbox_conjunto_leidos', {'ids': q}, true);
	
	$.ajax({
		url: target,
		dataType: "json",
		success: onSuccessMarcarConjuntoLeidos,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
	
};

var onSuccessEliminarConjunto = function(json){
	if(json.error==0){
		$.each(json.ids, function(index, id){
			setTimeout(function(){
					$("#mensaje-"+id).fadeOut("slow", function(){ $(this).remove(); });
				}, 
				index*1000
			);
		});
	}else{
		alert(json.msg);
	}
};


var eliminarMarcados = function(){
	var q = getSeleccionados();
	
	var target = Routing.generate('usuario_inbox_eliminar_conjunto_mensajes', {'ids': q}, true);
	
	$.ajax({
		url: target,
		dataType: "json",
		success: onSuccessEliminarConjunto,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
};

var onSuccessCambiarRecibirEspecialidad = function(json){
	if(json.error == 0){
		alert("Cambios realizados correctamente");
	} else {
		alert(json.msg);	
	}
};

var cambiarRecibirEspecialidad = function(){
	var notificar = 0;
	if($(this).is(":checked")){
		notificar = 1;
	}
	var target = Routing.generate("habilitar_permitir_notificaciones_especialidad",{"notificar":notificar});
	
	$.ajax({
		url: target,
		dataType: "json",
		type: "get",
		success: onSuccessCambiarRecibirEspecialidad,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
};


/**
 * Bindings
 */
$(document).ready(function(){
	$(".toolbar-container").on("click", "[data-rel='marcar-leido']", onClickMarcarLeido);
	$(".toolbar-container").on("click", "[data-rel='marcar-no-leido']", onClickMarcarNoLeido);
	$(".toolbar-container").on("click", "[data-rel='eliminar-mensaje']", onClickEliminarMensaje);
	$("#ajustes_inbox_recibirMail").on("change", togglePeriodicidad);
	$("#ajustes_inbox_recibirMail").trigger("change");
	$("#marcar-leidos").on("click", marcarConjuntoLeidos);
	$("#eliminar-marcados").on("click", eliminarMarcados);
	$("#ajustes_inbox_recibirEspecialidad").on("change", cambiarRecibirEspecialidad);
	$(".fancybox").fancybox();
});