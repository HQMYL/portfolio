/**
 * Handlers de eventos 
 */


var onAjaxError = function(jqxhr,status,msg){
	console.log("Error conexión: " + msg);
};

var onSuccessEliminarRegistro = function(json){
	if(json.error==0){
		$("#centro-"+json.registro).fadeOut(1000,function(){ $(this).remove(); });
	}else{
		alert(json.msg);
		return false;
	}
};

var onClickEliminarRegistro = function(){
	if(confirm("¿Quiere eliminar un centro?")){
		var target = $(this).attr("data-target");
		
		$.ajax({
			url: target,
			type: "get",
			dataType: "json",
			success: onSuccessEliminarRegistro,
			error: onAjaxError,
			//beforeSend: mostrarCargando,
			//complete: ocultarCargando,
		});
	} else {
		return false;
	}
};

var onSuccessEliminarOferta = function(json){
	if(json.error==0){
		alert("Oferta eliminada correctamente");
		$("#oferta-"+json.registro).fadeOut(1000,function(){ $(this).remove(); });
	}else{
		alert(json.msg);
		return false;
	}
};

var onClickEliminarOferta = function(){
	if(confirm("¿Quiere eliminar una oferta, sus inscripciones y los currículums pendientes de compra?")){
		var target = $(this).attr("data-target");
		
		$.ajax({
			url: target,
			type: "get",
			dataType: "json",
			success: onSuccessEliminarOferta,
			error: onAjaxError,
			//beforeSend: mostrarCargando,
			//complete: ocultarCargando,
		});
	} else {
		return false;
	}
};

var onClickMeses = function(){
    $("#finp").attr("style", "display:inline;float:right;");
};

var onChangeProvinciasNuevoCentro = function(){
    var pais = $("#mediempleo_empleobundle_centrotype_pais").val();
    var provincia = $(this).val();
    var target = Routing.generate('change_provincia', true);
    $("#select-provincias").removeAttr("disabled");
    
	$.ajax({
		url: target,
		dataType: "json",
		data: "provincia="+ provincia +"&pais="+ pais ,
		type: "get",
		success: onSuccessChangeProvincias,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
};

var onChangePaisNuevoCentro = function(){
    var pais = $(this).val();
    var target = Routing.generate('change_pais', true);
    
	$.ajax({
		url: target,
		dataType: "json",
		data: "pais=" + pais,
		type: "post",
		success: onSuccessChangePais,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
};

var onCheckOfertaDestacada = function(){
	if($(this).is(':checked')){
		$("#empresa_ofertas_nueva_destacadaPeriodo option[value='']").remove();
		$("#periodo-destacada").show();
	} else {
		$("#empresa_ofertas_nueva_destacadaPeriodo").prepend("<option value='' selected='selected'></option>");
		$("#periodo-destacada").hide();
	}
};

var onClickAdquirir = function(){
    var precio = $("#pvp-curriculum").text();
    var respuesta = confirm("Se le descontarán " + precio + " ¿Está seguro que desea adquirir el siguiente curriculum?");
    
    if(respuesta){
		var target = $(this).attr("data-target");
		document.location.href=target;
	} else {
		return false;
	}
};

var onClickNotificarUsuario = function(){
    var precio = $("#pvp-curriculum").text();
    var target = $(this).attr("data-target");
	document.location.href = target;
};

var onOfertaNuevaTipoColectivoChangeSuccess = function(json){
	if(json.error == 0){
		if(json.especialidades.length > 0){
			$("#empresa_ofertas_nueva_colectivo").html("");
			var option = "";
			$.each(json.especialidades,function(index,especialidad){
				option += "<option value='"+especialidad.id+"'>"+especialidad.nombre+"</option>";
			});
			$("#empresa_ofertas_nueva_colectivo").append(option);
		}
	}
};

var onOfertaNuevaTipoColectivoChange = function(){
	var colectivo = $(this).val();
	$.ajax({
		url: Routing.generate("ajax_cargar_especialidades"),
		type: "get",
		data: {tipoColectivo:colectivo},
		dataType: "json",
		success: onOfertaNuevaTipoColectivoChangeSuccess,
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
};

var onClickSeleccionarVerMas = function(){
	var alto = $("#div-tabla-candidatos").height() + 552;
	var total = $(this).data("total");
	var offset = $("#num-items").data("offset") + 10;
	if(offset <= total){
		$("#div-tabla-candidatos").css("max-height",alto);
		$("#num-items").data("offset",offset);
		$("#num-items").html(offset);
	}
	if(offset >= total) {
		$("#num-items").html(total);
		$(this).hide();
	}
};

var onClickComprarCurriculum = function(){
	var notificacionId = $(this).data("target");
	var url = Routing.generate("compra_curriculum_notificado");
	window.location = url + "?notificacion=" + notificacionId; 
};

var onClickEliminarRechazados = function(){
	var url = Routing.generate("empresa_eliminar_notificaciones_rechazadas");
	if(confirm("¿Seguro que quieres eliminar las notificaciones rechazadas?")){
		window.location = url;
	}
};

var onClickSeleccionarUsuario = function(event){
	event.preventDefault();
	var enlace = $(this).attr("href");
	
	var fin = inicio = 0;
	var esCurriculum = enlace.indexOf("curriculum/");
	var oferta = "";
	
	if(esCurriculum > 0){
		inicio = esCurriculum+11;
		fin = enlace.indexOf("/",inicio);
		oferta = enlace.substr(fin+1);
	} else {
		inicio = enlace.indexOf("ofertas/")+8;
		fin = enlace.indexOf("/",inicio);
		oferta = enlace.substr(inicio,fin-inicio);
	}
	
	var curriculum = $(this).data("target");
	
	$.ajax({
		url: Routing.generate("empresa_curriculum_seleccionar",{"slug":curriculum,"oferta":oferta}),
		type: "get",
		dataType: "json",
		success: function(){
			window.location = enlace;
		},
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
};

var onClickRechazarUsuario = function(event){
	event.preventDefault();
	var enlace = $(this).attr("href");
	
	var fin = inicio = 0;
	var esCurriculum = enlace.indexOf("curriculum/");
	var oferta = "";
	
	if(esCurriculum > 0){
		inicio = esCurriculum+11;
		fin = enlace.indexOf("/",inicio);
		oferta = enlace.substr(fin+1);
	} else {
		inicio = enlace.indexOf("ofertas/")+8;
		fin = enlace.indexOf("/",inicio);
		oferta = enlace.substr(inicio,fin-inicio);
	}
	
	var curriculum = $(this).data("target");
	
	$.ajax({
		url: Routing.generate("empresa_curriculum_rechazar",{"slug":curriculum,"oferta":oferta}),
		type: "get",
		dataType: "json",
		success: function(){
			window.location = enlace;
		},
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
};

var onClickPendienteUsuario = function(event){
	event.preventDefault();
	var enlace = $(this).attr("href");
	
	var fin = inicio = 0;
	var esCurriculum = enlace.indexOf("curriculum/");
	var oferta = "";
	
	if(esCurriculum > 0){
		inicio = esCurriculum+11;
		fin = enlace.indexOf("/",inicio);
		oferta = enlace.substr(fin+1);
	} else {
		inicio = enlace.indexOf("ofertas/")+8;
		fin = enlace.indexOf("/",inicio);
		oferta = enlace.substr(inicio,fin-inicio);
	}
	
	var curriculum = $(this).data("target");
	
	$.ajax({
		url: Routing.generate("empresa_curriculum_pendiente",{"slug":curriculum,"oferta":oferta}),
		type: "get",
		dataType: "json",
		success: function(){
			window.location = enlace;
		},
		error: onAjaxError,
		//beforeSend: mostrarCargando,
		//complete: ocultarCargando,
	});
};

/**
 * Triggers 
 */
$(document).ready(function(){
	$("#select-provincias").on("change", onChangeProvincia);
    $("#select-provincias-buscador").on("change", onChangeProvincia);
    $("#select-provincias-nuevo-centro").on("change", onChangeProvinciasNuevoCentro);
	$("#tabla-centros").on("click","[data-rel='eliminar-registro']", onClickEliminarRegistro);
	$(".tabla-ofertas-empresa").on("click","[data-rel='eliminar-registro']", onClickEliminarOferta);
    $("#mediempleo_empresabundle_editardatosfacturacionempresatype_pais").on("change",onChangePais);
    $("#mediempleo_empleobundle_centrotype_pais").on("change",onChangePaisNuevoCentro);
    $("#add-meses").on("click", onClickMeses);
    $("#empresa_ofertas_nueva_destacada").on("change",onCheckOfertaDestacada);
    $("#adquirir-boton, #adquirir-img").on("click", onClickAdquirir);
    $("#notificar-boton, #notificar-img").on("click", onClickNotificarUsuario);
	$("#empresa_ofertas_nueva_tipoColectivo").on("change",onOfertaNuevaTipoColectivoChange);
	$("#seleccionar-ver-mas").on("click",onClickSeleccionarVerMas);
	$(".comprar-curriculum").on("click",onClickComprarCurriculum);
	$("#eliminar-rechazados").on("click",onClickEliminarRechazados);
	
	$("#cerrar-oferta").on("click", function(event){
    	var message = "Esta seguro de que desea cerrar esta oferta?\nAl cerrar una oferta, los usuarios inscritos son notificados y\npueden retirar su candidatura";
    	if(confirm(message)) {
    		return true;
    	}
    	
    	return false;
    });
    
    $("#seleccionar-usuario").on("click",onClickSeleccionarUsuario);
    $("#rechazar-usuario").on("click",onClickRechazarUsuario);
    $("#pendiente-usuario").on("click",onClickPendienteUsuario);
});
