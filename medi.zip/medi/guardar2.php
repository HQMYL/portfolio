<!DOCTYPE HTML>
<html>
<?php
session_start();
include("conexion.php");
$cadena = "";
$tipo = "";
$creditos = "";
$pagovisitas = "";
$pagocurri = "";
$curr1 = "";
$curr2 = "";

$foto = "";
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
?>
<head></head>
<body>
<?php



if (isset($_POST["cmbcolectivo"])) {
$arri = array();
$col = utf8_decode($_POST["cmbcolectivo"]);

$sth = $con->prepare("SELECT * FROM colectivo WHERE id = ?");
$sth->bindParam(1, $col);

$sth->execute();

if ($sth->rowCount() > 0) {

foreach ($sth as $row ) {
$arri[0] = $row["nombre"];

}

$colectiv = $arri[0];
}

}



$especialidad =  array();

if(!empty($_POST['espec'])) {
    foreach($_POST['espec'] as $espec) {
        $especialidad[] = $espec;                
    }
}

$cadena = implode(",", $especialidad);
$cadena = utf8_decode($cadena);



$nombre = "";
if (isset($_POST["nombre"])) {
	$nombre = utf8_decode($_POST["nombre"]);
}


$apellido1 = "";

if (isset($_POST["apellido1"])) {
	$apellido1 = utf8_decode($_POST["apellido1"]);
}


if (isset($_POST["apellido2"])) {
	$apellido2 = utf8_decode($_POST["apellido2"]);
}

if (isset($_POST["fecha"])) {
	$fecha = $_POST["fecha"];
}


if (isset($_POST["nif"])) {
	$nif = $_POST["nif"];
}

if (isset($_POST["cmbpais"])) {
	$nac = utf8_decode($_POST["cmbpais"]);
}

if (isset($_POST["correo"])) {
	$correo = utf8_decode($_POST["correo"]);
}



if (isset($_POST["dir"])) {
	$dir = utf8_decode($_POST["dir"]);
}

if (isset($_POST["ncalle"])) {
	$calle = utf8_decode($_POST["ncalle"]);
}

if (isset($_POST["piso"])) {
	$piso = utf8_decode($_POST["piso"]);
}

if (isset($_POST["dep"])) {
	$dep = utf8_decode($_POST["dep"]);
}

if (isset($_POST["cp"])) {
	$cp = utf8_decode($_POST["cp"]);
}

if (isset($_POST["loc"])) {
	$loc = utf8_decode($_POST["loc"]);
}

if (isset($_POST["provincia"])) {
	$prov = utf8_decode($_POST["provincia"]);
}


if (isset($_POST["user2"])) {
	$user = utf8_decode($_POST["user2"]);
}


if (isset($_POST["pass2"])) {
	$pass = utf8_decode($_POST["pass2"]);
}
	  



$tipo = "Profesional";

$creditos = 50;
$pagovisitas = 0;
$pagocurri = 0;
$curr1 = 0;
$curr2 = 0;

$sql = "INSERT INTO usuarios (nif,colectivo,especialidad, nombre,apellido1,apellido2,Nacimiento, pais, correo,dir,Ncalle,piso,departamento,CodigoPostal,localidad,provincia,usuario, pass, tipo, creditos, pagovisitas, pagocurri,curr1,curr2) VALUES (:nif,:colectiv,:cadena,:nombre, :apellido1, :apellido2,:fecha,:nac,:correo,:dir,:calle,:piso,:dep,:cp,:loc,:prov, :user, :pass, :tipo, :creditos,:pagovisitas,:pagocurri,:curr1,:curr2)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':nif', $nif, PDO::PARAM_STR);
$stmt->bindParam(':colectiv', $colectiv, PDO::PARAM_STR);
$stmt->bindParam(':cadena', $cadena, PDO::PARAM_STR);
$stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt->bindParam(':apellido1', $apellido1, PDO::PARAM_STR); 
$stmt->bindParam(':apellido2', $apellido2, PDO::PARAM_STR); 
$stmt->bindParam(':fecha', $fecha, PDO::PARAM_STR); 
$stmt->bindParam(':nac', $nac, PDO::PARAM_STR);
$stmt->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt->bindParam(':calle', $calle, PDO::PARAM_STR);
$stmt->bindParam(':piso', $piso, PDO::PARAM_STR);
$stmt->bindParam(':dep', $dep, PDO::PARAM_STR);
$stmt->bindParam(':cp', $cp, PDO::PARAM_STR);
$stmt->bindParam(':loc', $loc, PDO::PARAM_STR);
$stmt->bindParam(':prov', $prov, PDO::PARAM_STR);
$stmt->bindParam(':user', $user, PDO::PARAM_STR);
$stmt->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt->bindParam(':creditos', $creditos, PDO::PARAM_STR);
$stmt->bindParam(':pagovisitas', $pagovisitas, PDO::PARAM_STR);
$stmt->bindParam(':pagocurri', $pagocurri, PDO::PARAM_STR);
$stmt->bindParam(':curr1', $curr1, PDO::PARAM_STR);
$stmt->bindParam(':curr2', $curr2, PDO::PARAM_STR);
 
$stmt->execute();



$foto = "user-64.png";
$sql = "INSERT INTO perfil (usuario,userPic) VALUES (:user,:foto)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':user', $user, PDO::PARAM_STR);
$stmt->bindParam(':foto', $foto, PDO::PARAM_STR);
$stmt->execute();



?>




<script>
alert('El usuario a sido agregado exitosamaente');
window.location.href='usuario.php';
</script>

</body>
<html>