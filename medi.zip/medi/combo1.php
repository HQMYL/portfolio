<?php
include("conexion.php");

if (isset($_POST["id"])) {
	$pa = $_POST["id"];
}



 $sql = "SELECT * FROM empresas WHERE nombre ='".$pa."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {

echo '<table class="table table-bordered table-hover">';
echo '<thead>';
echo '<tr>';

echo '<th>Contacto</th>';
echo '<th>Dirección</th>';
echo '<th>Correo</th>';
echo '<th>Teléfono</th>';
echo '<th>Usuario</th>';
echo '<th>Contraseña</th>';
echo '</tr>';
echo '</thead>';

echo '<tbody>';
echo '<tr>';
 echo '<td>' .  $row->nombre . '</td>';
 echo '<td>' .  $row->dir . '</td>';
 echo '<td>' .  $row->correo . '</td>';
 echo '<td>' .  $row->tel . '</td>';
 echo '<td>' .  $row->user . '</td>';
 echo '<td>' .  $row->pass . '</td>';
 echo '</tr>';
 echo '</tbody>';
 echo '</table>';

}

 ?>