<?php
include("conexion.php");

if (isset($_POST["id"])) {
	$pa = $_POST["id"];
}



 $sql = "SELECT * FROM empresas";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);



echo '<table class="table table-bordered table-hover">';
echo '<thead>';
echo '<tr>';

echo '<th>Nombre</th>';
echo '<th>Contacto</th>';
echo '<th>Dirección</th>';
echo '<th>Localidad</th>';
echo '<th>Código Postal</th>';
echo '<th>Correo</th>';
echo '<th>Teléfono Fijo</th>';
echo '<th>Acciones</th>';
echo '</tr>';
echo '</thead>';
foreach ($rows as $row) {

echo '<tbody>';
echo '<tr>';
 echo '<td>' .  utf8_encode($row->social) . '</td>';
 echo '<td>' .  utf8_encode($row->nombre) . '</td>';
 echo '<td>' .  utf8_encode($row->dir) . '</td>';
 echo '<td>' .  utf8_encode($row->localidad) . '</td>';
 echo '<td>' .  utf8_encode($row->codigoPostal) . '</td>';
 echo '<td>' .  utf8_encode($row->correo) . '</td>';
 echo '<td>' .  utf8_encode($row->fijo) . '</td>';
  echo '<td><a class="btn btn-danger" href="actualizarem.php?id='. $row->id .'">Actualizar</strong> </a> </td>';
  echo '<td><a class="btn btn-danger" href="eliminaremp.php?id='. $row->id .'">Eliminar</strong> </a> </td>';
 echo '</tr>';
 echo '</tbody>';
 

}

 ?>