<!DOCTYPE html>

<html lang="es">
<?php

session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}

if (isset($_GET["id"])) {
    $id = $_GET["id"];
}


?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DemiJob</title>

    <!-- Bootstrap Core CSS -->
    <link href="css3/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css3/sb-admin.css" rel="stylesheet">
    <link href="css3/new.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css3/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
        .navbar-brand {
color: blue;
}

.btn-danger {
            
            padding: 10px;
        }

    </style>

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" style="color: #fff;" href="admin.php">Inicio</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="index.html"><i class=""></i> Panel de Control</a>
                    </li>
                    
                    
                    
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo"><i></i> Usuarios <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="agregarusuario.php">Agregar Usuario</a>
                            </li>
                            <li>
                                <a href="consultarusuario.php">Consultar Usuario</a>
                            </li>
                            
                        </ul>
                    </li>

                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo1"> Empresas <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo1" class="collapse">
                            <li>
                                <a href="agregarempresa.php">Agregar Empresa</a>
                            </li>
                            <li>
                                <a href="consultarempresa.php">Consultar Empresa</a>
                            </li>
                            
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo3"><i></i> Empleos <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo3" class="collapse">
                            <li>
                                <a href="agregarempleo.php">Agregar Empleos</a>
                            </li>
                            <li>
                                <a href="consultarempleo.php">Consultar Empleos</a>
                            </li>
                            
                        </ul>
                    </li>   
                 <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo4"><i></i> Oposiciones <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo4" class="collapse">
                            <li>
                                <a href="agregaroposicion.php">Agregar Oposición</a>
                            </li>
                            <li>
                                <a href="consultaroposicion.php">Consultar Oposición</a>
                            </li>
                            <li>
                                <a href="actualizaroposicion.php">Actualizar Oposición</a>
                            </li>
                            <li>
                                <a href="eliminaroposicion.php">Eliminar Oposición</a>
                            </li>

                        </ul>
                    </li>
                   <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo5"><i></i> Reportes <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo5" class="collapse">
                            <li>
                                <a href="ventas.php">Ventas</a>
                            </li>
                            <li>
                                <a href="curriculums-comprados.php">Curriculums Adquiridos</a>
                            </li>



                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Actualizar Oposición
                        </h1>
                        <ol class="breadcrumb">
                            
                        </ol>
                    </div>
                </div>
                <div>    
 <form class="form" name="formi" method="POST" action="actualizar5.php">
                <fieldset>
                   <?php
         $sql = "SELECT * FROM oposiciones WHERE id = '".$id."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as  $row) { ?>    
                    <div class="col-md-6">
                        <label>FECHA <span class="tooltip">?</span></label>
                        <input type="text" class="select-centros" name="fecha" id="fecha" value="<?php echo $row->fecha;?>">
                    </div>
                        <div class="col-md-6">
                        <label>DESCRIPCIÓN <span class="tooltip">?</span></label>
                        <input type="text" class="select-centros" readonly="true" name="desc" id="desc" value="<?php echo utf8_encode($row->descripcion);?>">
                        </div>
                        <div class="col-md-6">
                        <label>CONVOCANTE<span class="tooltip">?</span></label>
                        <input type="text" class="select-centros" name="emp" id="emp" value="<?php echo utf8_encode($row->convocante);?>">
                        </div>

                        <div class="col-md-6">
                         <label>TITULACIÓN<span class="tooltip">?</span></label>
                        <input type="text" class="select-centros" name="tuti" id="tuti" value="<?php echo utf8_encode($row->titulacion);?>">
                    </div>
                    <div class="col-md-6">
                        <label>NÚMERO DE PLAZAS<span class="tooltip">?</span></label>
                        <input type="text" class="select-centros" name="plazas" id="plazas" value="<?php echo $row->plazas;?>">
                        <input type="hidden" name="id" id="id" value="<?php echo $row->id;?>">                        
  <?php } ?>            
  </div>        
                </fieldset>
                <button class="btn btn-danger" type="submit">Actualizar</button>

            </form>
            </div>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js3/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js3/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js3/plugins/morris/raphael.min.js"></script>
    <script src="js3/plugins/morris/morris.min.js"></script>
    <script src="js3/plugins/morris/morris-data.js"></script>

</body>

</html>
