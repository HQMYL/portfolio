<!DOCTYPE HTML>
<html>
<?php
include("inc/conexion.php");
?>
<body>
<?php

if (isset($_POST["social"])) {
	$social = $_POST["social"];
}


if (isset($_POST["correo"])) {
	$correo = $_POST["correo"];
}

if (isset($_POST["dir"])) {
	$dir = $_POST["dir"];
}

if (isset($_POST["nombre"])) {
	$contacto = $_POST["nombre"];
}




if (isset($_POST["tel"])) {
	$tel = $_POST["tel"];
}


if (isset($_POST["user"])) {
	$user = $_POST["user"];
}



if (isset($_POST["pass"])) {
	$pass = $_POST["pass"];
}

if (isset($_POST["tipoem"])) {
	$tipoem = $_POST["tipoem"];
}










$sql = " SELECT * FROM empresas WHERE contacto = '" .$contacto. "'";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
foreach ($rows as $row) {

if( ( $social == $row->social)  AND ($correo == $row->correo) ) {

$sql2 = " UPDATE empresas SET dir =:dir, telef =:telef, user =:user, pass =:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':dir', $dir, PDO::PARAM_STR); 
$stmt2->bindParam(':telef', $telef, PDO::PARAM_STR);
$stmt2->bindParam(':user', $user, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $social == $row->social)  AND ($dir == $row->dir) ) {

$sql2 = " UPDATE empresas SET correo =:correo, telef =:telef, user =:user, pass =:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
$stmt2->bindParam(':telef', $telef, PDO::PARAM_STR);
$stmt2->bindParam(':user', $user, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);

$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $social == $row->social)  AND ($tel == $row->tel) ) {

$sql2 = " UPDATE empresas SET correo =:correo, dir =:dir, user =:user, pass =:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':user', $user, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $social == $row->social)  AND ($tel == $row->tel) ) {

$sql2 = " UPDATE empresas SET correo =:correo, dir =:dir, user =:user, pass =:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':user', $user, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $social == $row->social)  AND ($user == $row->user) ) {

$sql2 = " UPDATE empresas SET correo =:correo, dir =:dir, telef =:tel, pass =:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $social == $row->social)  AND ($pass == $row->pass) ) {

$sql2 = " UPDATE empresas SET correo =:correo, dir =:dir, telef =:tel, user =:user WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':user', $user, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $correo == $row->correo)  AND ($dir == $row->dir) ) {

$sql2 = " UPDATE empresas SET social =:social, telef =:tel, user =:user, pass =:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':social', $social, PDO::PARAM_STR); 
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':user', $user, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}






if( ( $correo == $row->correo)  AND ($tel == $row->telef) ) {

$sql2 = " UPDATE empresas SET social =:social, dir =:dir, user =:user, pass =:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':social', $social, PDO::PARAM_STR); 
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':user', $user, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $correo == $row->correo)  AND ($user == $row->user) ) {

$sql2 = " UPDATE empresas SET social =:social, dir =:dir, telef =:tel, pass =:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':social', $social, PDO::PARAM_STR); 
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $correo == $row->correo)  AND ($pass == $row->pass) ) {

$sql2 = " UPDATE empresas SET social =:social, dir =:dir, telef =:tel, user =:user WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':social', $social, PDO::PARAM_STR); 
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $dir == $row->dir)  AND ($tel == $row->telef) ) {

$sql2 = " UPDATE empresas SET social =:social, correo=:correo, dir =:dir, user =:user, pass=:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':social', $social, PDO::PARAM_STR); 
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $dir == $row->dir)  AND ($user == $row->user) ) {

$sql2 = " UPDATE empresas SET social =:social, correo=:correo, telef =:tel,  pass=:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':social', $social, PDO::PARAM_STR); 
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $dir == $row->dir)  AND ($pass == $row->pass) ) {

$sql2 = " UPDATE empresas SET social =:social, correo=:correo, telef =:tel,  user=:user WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':social', $social, PDO::PARAM_STR); 
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':user', $user, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $tel == $row->telef)  AND ($user == $row->user) ) {

$sql2 = " UPDATE empresas SET social =:social, correo=:correo, dir =:dir,  pass=:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':social', $social, PDO::PARAM_STR); 
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $tel == $row->telef)  AND ($pass == $row->pass) ) {

$sql2 = " UPDATE empresas SET social =:social, correo=:correo, dir =:dir,  user=:user WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':social', $social, PDO::PARAM_STR); 
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':user', $user, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( $social == $row->social) {

$sql2 = " UPDATE empresas SET correo=:correo,  dir=:dir, telef=:tel, user =:user, pass=:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
 $stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
 $stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
 $stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}





if( $correo == $row->correo) {

$sql2 = " UPDATE empresas SET social =:social,  dir=:dir, telef=:tel, user =:user, pass=:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':social', $social, PDO::PARAM_STR); 
 $stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
 $stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
 $stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}


if( $dir == $row->dir) {

$sql2 = " UPDATE empresas SET social =:social, telef=:tel, correo=:correo, user =:user, pass=:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':social', $social, PDO::PARAM_STR); 
 $stmt2->bindParam(':tel', $tel, PDO::PARAM_STR); 
 $stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR); 
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( $tel == $row->telef) {

$sql2 = " UPDATE empresas SET social =:social, correo=:correo, dir=:dir,  user =:user, pass=:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':social', $social, PDO::PARAM_STR);
  $stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
   $stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}

if( $user == $row->user) {

$sql2 = " UPDATE empresas SET social =:social, telef=:tel, correo=:correo, dir=:dir,   pass=:pass WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':social', $social, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
  $stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
   $stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}


if( $pass == $row->pass) {

$sql2 = " UPDATE empresas SET social =:social, telef=:tel, correo=:correo, dir=:dir,   user=:user WHERE nombre =:contacto ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':social', $social, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
  $stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
   $stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':user', $user, PDO::PARAM_STR);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt2->execute();

}




}



?>
<script>
	alert('El usuario a sido actualizado exitosamaente');
window.location.href='actualizarempresa.php';


</script>
</body>
</html>