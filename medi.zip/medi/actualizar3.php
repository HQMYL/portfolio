<!DOCTYPE HTML>
<html>
<?php
include("conexion.php");
?>
<body>
<?php

if (isset($_POST["social"])) {
	$social = utf8_decode($_POST["social"]);
}


if (isset($_POST["correo"])) {
	$correo = utf8_decode($_POST["correo"]);
}

if (isset($_POST["dir"])) {
	$dir = utf8_decode($_POST["dir"]);
}


if (isset($_POST["tel1"])) {
	$tel1 = utf8_decode($_POST["tel1"]);
}


if (isset($_POST["tel2"])) {
	$tel2 = $_POST["tel2"];
}


if (isset($_POST["ncalle"])) {
	$ncalle = $_POST["ncalle"];
}

if (isset($_POST["piso"])) {
	$piso = utf8_decode($_POST["piso"]);
}

if (isset($_POST["dep"])) {
	$dep = utf8_decode($_POST["dep"]);
}


if (isset($_POST["cp"])) {
	$cp = $_POST["cp"];
}

if (isset($_POST["loc"])) {
	$loc = utf8_decode($_POST["loc"]);
}

if (isset($_POST["prov"])) {
	$prov = utf8_decode($_POST["prov"]);
}


if (isset($_POST["nacional"])) {
	$nacional = utf8_decode($_POST["nacional"]);
}


if (isset($_POST["provincial"])) {
	$provincial = utf8_decode($_POST["provincial"]);
}


if (isset($_POST["tipoem"])) {
	$tipoem = utf8_decode($_POST["tipoem"]);
}



if (isset($_POST["nombre"])) {
	$contacto = utf8_decode($_POST["nombre"]);
}




if (isset($_POST["id"])) {
	$id = $_POST["id"];
}

if (isset($_POST["user"])) {
	$user = utf8_decode($_POST["user"]);
}

if (isset($_POST["pass"])) {
	$pass = utf8_decode($_POST["pass"]);
}

if (isset($_POST["tipo2"])) {
	$tipo2 = utf8_decode($_POST["tipo2"]);
}

if (isset($_POST["creditos"])) {
	$creditos = $_POST["creditos"];
}


if (isset($_POST["curr1"])) {
	$curr1 = $_POST["curr1"];
}


if (isset($_POST["curr2"])) {
	$curr2 = $_POST["curr2"];
}




$sql2 = " UPDATE empresas SET nombre =:contacto, social =:social, correo =:correo,dir=:dir, fijo=:tel1, celular=:tel2,numeroC=:ncalle, piso=:piso,departamento=:dep,codigoPostal=:cp, localidad =:loc,provincia=:prov, MatriculaNacional=:nacional, MatriculaProvincial=:provincial, user=:user, pass=:pass, tipoem=:tipoem,tipo2=:tipo2, creditos=:creditos, curr1=:curr1,curr2=:curr2 WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':contacto', $contacto, PDO::PARAM_STR); 
$stmt2->bindParam(':social', $social, PDO::PARAM_STR);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':tel1', $tel1, PDO::PARAM_STR);
$stmt2->bindParam(':tel2', $tel2, PDO::PARAM_STR);
$stmt2->bindParam(':ncalle', $ncalle, PDO::PARAM_STR);
$stmt2->bindParam(':piso', $piso, PDO::PARAM_STR);
$stmt2->bindParam(':dep', $dep, PDO::PARAM_STR);
$stmt2->bindParam(':cp', $cp, PDO::PARAM_STR);
$stmt2->bindParam(':loc', $loc, PDO::PARAM_STR);
$stmt2->bindParam(':prov', $prov, PDO::PARAM_STR);
$stmt2->bindParam(':nacional', $nacional, PDO::PARAM_STR);
$stmt2->bindParam(':provincial', $provincial, PDO::PARAM_STR);
$stmt2->bindParam(':user', $user, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':tipoem', $tipoem, PDO::PARAM_STR);
$stmt2->bindParam(':tipo2', $tipo2, PDO::PARAM_STR);
$stmt2->bindParam(':creditos', $creditos, PDO::PARAM_STR);
$stmt2->bindParam(':curr1', $curr1, PDO::PARAM_STR);
$stmt2->bindParam(':curr2', $curr2, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);
$stmt2->execute();




?>
<script>
	alert('La empresa a sido actualizada exitosamaente');
window.location.href='consultarempresa.php';


</script>
</body>
</html>