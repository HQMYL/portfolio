<!DOCTYPE html>
<!-- saved from url=(0035)https://mediempleo.com/alta-usuario -->
<html lang="es" class="">
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
?>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide{display:none !important;}ng\:form{display:block;}.ng-animate-start{border-spacing:1px 1px;-ms-zoom:1.0001;}.ng-animate-active{border-spacing:0px 0px;-ms-zoom:1;}</style>
        
		<meta name="description" content="Regístrate en la bolsa de empleo de salud como enfermera, médico o auxiliar en enfermería para estar al tanto de las ofertas de trabajo">
		        <title>Edición de Perfil</title>
        <!--[if lt IE 9]>
        	<script src="/bundles/comun/js/html5shiv.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
                <link rel="stylesheet" type="text/css" href="css2/css.css">
        	<link rel="stylesheet" type="text/css" href="css2/reset.css">
    <link rel="stylesheet" type="text/css" href="css2/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css2/frontend.css">
	<link rel="stylesheet" type="text/css" href="css2/forms.css">
	<link rel="stylesheet" type="text/css" href="css2/jquery.fancybox.css">
	<link rel="stylesheet" type="text/css" href="css2/jquery-ui-1.10.3.custom.min.css">
        <link rel="icon" type="image/x-icon" href="https://mediempleo.com/mediempleo-16.ico">
        <link rel="icon" type="image/x-icon" href="https://mediempleo.com/mediempleo-32.ico">
        <link rel="icon" type="image/x-icon" href="https://mediempleo.com/mediempleo-64.ico">
        <link rel="apple-touch-icon" sizes="114x114" href="https://mediempleo.com/mediempleo-114.png">
        <link rel="apple-touch-icon" sizes="72x72" href="https://mediempleo.com/mediempleo-72.png">
        <link rel="apple-touch-icon" href="https://mediempleo.com/mediempleo-57.png">
    <style type="text/css">.fancybox-margin{margin-right:17px;}</style></head>
    <body itemscope="" itemtype="http://schema.org/WebPage">
		<div id="cargando" style="display:none"></div>
		    				        		<div id="pagina">
		<header id="header">
			<div id="banner">
				<img src="" alt="MedicalJob: Trabaja en el sector sanitario en cualquier parte del mundo">
			</div>
					</header>
		<div id="contenido">
			<div id="breadcrumb" itemprop="breadcrumb">
								<a href="admin.php">
					<span class="glyphicon glyphicon-home"></span> Inicio
				</a> &gt; 
			Regístrate
			</div>
					
			<aside id="sidebar">
			    				<div id="contadores">
	<div class="contador contador-profesionales">
		<div class="cifra-contador">
			<?php
			$sql = "SELECT * FROM usuarios"; 
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
$total = 0;
foreach ($rows as $row) {
$total = $total + 1;
}
?>
			<strong><?php echo $total; ?></strong>
		</div>
		<div class="texto-contador">profesionales<br>sanitarios</div>
	</div>
	<div class="contador contador-empresas">
		<div class="cifra-contador">
			<?php
			$sql = "SELECT * FROM empresas"; 
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
$total = 0;
foreach ($rows as $row) {
$total = $total + 1;
}
?>
			<strong><?php echo $total; ?></strong>
		</div>
		<div class="texto-contador">centros y<br>empresas</div>
	</div>
	</div>									
					<div class="sidebar-box">
					</div>
					<h2 class="titulo-sidebar-box"></h2>
					<div class="sidebar-box sidebar-box-bordered">
						 
	
					</div>
									
						<img width="200" height="200" src="img/italiano.png">
    			</aside>
		
			<div id="content-right">
				<div style="float:left;width:100%">
	</div>				    <div class="mediempleo-box">
        <div class="content">
            <div class="box-header">
                <div class="box-title">
                    <h1 class="azul"></h1>
                </div>
            </div>
            <div class="box-content">
                
                <?php 
                $sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { ?>
                <form id="form-registro" action="actualizar6.php" method="post">
                    <div class="form-errors"></div>
                    <div class="width-100 registro-usuario">
                        <label for="col" class="required">Colectivo</label>
                        <select id="col" name="col" class="text-input-border registro-user-colectivo"><option value="59">Auxiliar de enfermería</option><option value="56">Enfermería</option><option value="57">Farmacia</option><option value="55">Medicina</option><option value="60">Otras Ofertas</option><option value="58">Técnico auxiliar de farmacia</option></select>
                                            </div>
                    <div class="width-100">
	                    <div class="width-33 registro-usuario" style="margin-right: 16px">
	                        <label for="nombre" class="required">Nombre</label>
	                        <input type="text" id="nombre" name="nombre"  class="text-input-border" value="<?php echo $row->nombre;?>">
	                        	                    </div>
	                    <div class="width-66 registro-usuario">
	                        <label for="apellidos" class="required">Primer Apellido</label>
	                        <input type="text" id="apellido1" name="apellido1" class="text-input-border apellidos" value="<?php echo $row->apellido1;?>">

	                        <label for="apellidos" class="required">Segundo Apellido</label>
	                        <input type="text" id="apellido2" name="apellido2" class="text-input-border apellidos" value="<?php echo $row->apellido2;?>">
	                        	                    </div>
	                </div>
	                
	                <?php ?>
	                <div class="width-100">
	                	<div class="width-50 registro-usuario">
	                        <label for="mediempleo_usuariobundle_registrousuariotype_email_first" class="required">Correo</label>
	                        <input type="text" id="correo" name="correo" class="text-input-border registro-user-email" value="<?php echo $row->correo;?>">
	                        	                    </div>
	                  <div class="width-50 registro-usuario">
	                        <label for="mediempleo_usuariobundle_registrousuariotype_email_first" class="required">Dirección</label>
	                        <input type="text" id="correo" name="correo"  class="text-input-border registro-user-email" value="<?php echo utf8_encode($row->dir);?>">
	                        	                    </div>
	                    
	                </div>

	                <div class="width-100">
	                	<div class="width-50 registro-usuario">
	                        <label for="usuario" class="required">Usuario</label>
	                        <input type="text" id="user" name="user"  class="text-input-border registro-user-email" value="<?php echo $row->usuario;?>" >
	                        	                    </div>
	                    <div class="width-50 registro-usuario">
	                    	<label for="usuario" class="required">Contraseña</label>
	                        <input type="text" id="pass" name="pass"  class="text-input-border registro-user-email" value="<?php echo $row->pass;?>" >
	                        	                    </div>
	                </div>
	                
	                <div class="width-100">
	                    <div class="width-25 registro-usuario">
	                        <label for="nif" class="required">CUIT/CUIL</label>
	                        <input type="text" id="nif" name="nif"  class="text-input-border nie" value="<?php echo $row->nif;?>">
	                        	                    </div>
	                    <div class="width-33 registro-usuario">
	                        <label for="mediempleo_usuariobundle_registrousuariotype_nacionalidad" class="required">Nacionalidad</label>
	                        <select id="cmbpais" name="cmbpais">
            <option value="">Seleccione el Pais</option>

         <?php 
      
         $con = new PDO('mysql:host=localhost;dbname=medijob', 'root', '');
         $sql = "SELECT id, paisnombre FROM pais";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->paisnombre .'">'.utf8_encode ($row->paisnombre).'</option>';

        
    }

    ?>
</select>
	                        	                    </div>
	                </div>
	                
                    <div class="width-100 registro-usuario">
                        
                    </div>
                    
                    <div class="form-widget-container">
                        <input type="submit" value="Registrarme" class="button button-blue submit">
                    </div>
                </form>
                <?php } ?>
            </div>
        </div>
    </div>	
			</div>
		</div>
		<footer id="footer">	
	<div id="container-footer-especialidades">
			<div class="footer-box">
			
		</div>
			
			
			<div class="footer-box">
			<ul class="footer-box-list">
				
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				
							</ul>
		</div>
		
		
	</div>
	<div id="footer-aside">
		<div class="footer-box">
			<ul class="footer-box-list">
				
			</ul>
		</div>
		<div class="footer-box">
			<ul class="footer-box-list">
				
			</ul>
		</div>
		<figure id="logo-footer">
			
		</figure>
		<div id="info-footer">
			
		</div>	
	</div>
	
		
</footer>	</div>
                	
                <script async="" src="./Regístrate en la bolsa de trabajo de salud como enfermera, médico o auxiliar en enfermería_files/analytics.js"></script><script type="text/javascript">
	  		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
				(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
				m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
			ga('create', 'UA-40029850-1', 'mediempleo.com');
			ga('send', 'pageview');
		</script>
        	<script src="js2/router.js"></script>
	<script src="js2/routing"></script>
	<script src="js2/jquery-1.9.1.min.js"></script>
    <script src="js2/jquery-ui-1.10.3.custom.min.js"></script>
	<script src="js2/frontend.js"></script>
	<script src="js2/bootstrap.js"></script>
    <script src="js2/angular.min.js"></script>
    <script src="js2/ng-table.js"></script>
	<script type="text/javascript" src="js2/jquery.fancybox.pack.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$("a[rel='fancybox']").fancybox({
				'transitionIn'	:	'elastic',
				'transitionOut'	:	'elastic',
				'speedIn'		:	600, 
				'speedOut'		:	200, 
				'overlayShow'	:	true,
				'type'			:	'iframe',
				'showNavArrows': 	false
			});
		});
	</script>
        <script type="text/javascript">
			$(document).ready(function(){
				$("#acepta-cookies").on("click", function(){
					var dias = 365*60*60*24*1000;
					var hoy = new Date();
			        var fecha_expira = new Date( hoy.getTime() + (dias) );
			        var cookieString = "cookies_agreement=1" + ";expires=" + fecha_expira.toGMTString();
					window.document.cookie = cookieString
					$("#cookies-bar").css('position','relative')
					$("#cookies-bar").slideDown(1200, function(){
						$(this).remove();
					});
				});

				$("#select-usuario").on("change", function(){
					$("#admin-usuario").val($(this).val());
				});
			});
        </script>
    

</body></html>