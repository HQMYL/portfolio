<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
session_start();

$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}

include("conexion.php");
require("class.phpmailer.php");


if (isset($_POST["nombre"])) {
	$nombre = $_POST["nombre"];
}

if (isset($_POST["correo"])) {
	$correo = $_POST["correo"];
}

if (isset($_POST["asunto"])) {
	$asunto = $_POST["asunto"];
}


if (isset($_POST["mensaje"])) {
	$mensaje = $_POST["mensaje"];
}



$mail = new PHPMailer();

//Luego tenemos que iniciar la validación por SMTP:
$mail->IsSMTP();
$mail->SMTPAuth = true;
$mail->Host = "mail.argentina-hosting.com"; // A RELLENAR. Aquí pondremos el SMTP a utilizar. Por ej. mail.midominio.com
$mail->Username = "admin@expressmetropolitana.com"; // A RELLENAR. Email de la cuenta de correo. ej.info@midominio.com La cuenta de correo debe ser creada previamente. 
$mail->Password = "1Eqejf#i"; // A RELLENAR. Aqui pondremos la contraseña de la cuenta de correo
$mail->Port = 466; // Puerto de conexión al servidor de envio. 
$mail->From = "mail.argentina-hosting.com"; // A RELLENARDesde donde enviamos (Para mostrar). Puede ser el mismo que el email creado previamente.
$mail->SMTPSecure = 'tls';     
$mail->FromName = "MedicalJob"; //A RELLENAR Nombre a mostrar del remitente. 
$mail->AddAddress($correo); // Esta es la dirección a donde enviamos 
$mail->IsHTML(true); // El correo se envía como HTML 
$mail->Subject = "Registro en medicalJob"; // Este es el titulo del email. 
$body = "Hola, " . $nombre ." te ha enviado el siguiente mensaje: " .$mensaje; 

$mail->Body = $body; // Mensaje a enviar. 

$exito = $mail->Send(); // Envía el correo.
if($exito){ echo ‘El correo fue enviado correctamente.’; }else{ echo ‘Hubo un problema. Contacta a un administrador.’; } 

?>

<script>
window.location.href='contacto.php';
</script>

</body>
</html>