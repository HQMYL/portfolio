<?php
include("conexion.php");
session_start();
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}

if (isset($_POST["pass1"])) {
	$pass1 = $_POST["pass1"];
}


if (isset($_POST["pass2"])) {
	$pass2 = $_POST["pass2"];
}

if (isset($_POST["pass3"])) {
	$pass3 = $_POST["pass3"];
}


 $sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {

$sql2 = " UPDATE usuarios SET pass =:pass2 WHERE usuario =:usuario ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':pass2', $pass2, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();


}

 ?>