<!DOCTYPE html>
<html lang="es">
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
?>
    <head>
        <meta charset="UTF-8" />
		<meta name="description" content="	MedicalJob, bolsa de empleo con ofertas de trabajo, congresos y cursos de enfermera, médico y auxiliar en enfermería en el sector de salud
" />
		        <title>Listado de curriculums adquiridos
</title>
        <!--[if lt IE 9]>
        	<script src="/bundles/comun/js/html5shiv.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
                <link rel="stylesheet" type="text/css" href="css2/css.css" />
            	<link rel="stylesheet" type="text/css" href="css2/reset.css" />
    <link rel="stylesheet" type="text/css" href="css2/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css2/frontend.css" />
	<link rel="stylesheet" type="text/css" href="css2/forms.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery-ui-1.10.3.custom.min.css" />

    <link rel="stylesheet" type="text/css" href="css2/empresa.css" />
    <link rel="stylesheet" type="text/css" href="css2/form-facturacion.css" />
    <link rel="stylesheet" type="text/css" href="css2/extranet.css" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="apple-touch-icon" sizes="114x114" href="" />
        <link rel="apple-touch-icon" sizes="72x72" href="" />
        <link rel="apple-touch-icon" href="" />
        <style type="text/css">
        	.menu-titulo {
        
        background-image: url("img/flecha.png");
 }       
        </style>
    </head>
    <body itemscope itemtype="http://schema.org/WebPage">
		<div id="cargando" style="display:none"></div>
		    				        	<div id="pagina">
		<header id="header">
			<div id="banner">
				<img class="img-responsive" src="img/portada.jpg" 
					 alt="MedicalJob: Trabaja en el sector médico en cualquier parte del mundo"
					 title="MedicalJob: Trabaja en el sector médico en cualquier parte del mundo" />
			</div>
					</header>
		<div id="contenido">
			<div id="breadcrumb" itemprop="breadcrumb">
									<a href="seccion-empresas.php"><span class="glyphicon glyphicon-home"></span> Inicio</a> >
											<a href="seccion-empresas.php">Mi Cuenta</a> >
					 
				 Listado de currículums adquiridos			</div>
					
			<aside id="sidebar">
				<div id="cuadro-sesion">
	<p><em>BIENVENIDO</em> <span class="green">
				<?php echo $usuario; ?></span><br />
		</p>
	<p id="cuadro-sesion-saldo">
		<?php
        $sql = "SELECT * FROM empresas WHERE user ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { ?>
			<em>Saldo actual: <span class="green" id="cuadro-sesion-puntos"><?php echo $row->creditos;?> créditos</span></em>
			<?php } ?>
		</p>
			<a class="button button-green" href="nueva-oferta.php">PUBLICAR</a>
		<a class="button button-blue" href="listado-ofertas.php">OFERTAS</a>
			<a class="button button-grey" href="logout.php">SALIR</a>
</div>									<div id="menu-empresa" class="menu-lateral">
    <ul id="menu-box">
    	<li class="menu-titulo" data-target="submenu-ofertas">Ofertas</li>
        <li class="submenu" id="submenu-ofertas">
            <ul>
                <li><a href="listado-ofertas.php">Ver ofertas</a></li>
                <li><a href="nueva-oferta.php">Publicar oferta</a></li>
            </ul>
        </li>
        <li class="menu-titulo" data-target="submenu-curriculums">Currículums</li>
        <li class="submenu" id="submenu-curriculums">
            <ul>
                <li><a href="buscar-usuarios.php">Buscar candidatos</a></li>
                <li><a href="notificaciones-pendientes">Pendientes</a></li>
                <li>
                	<?php
        $sql = "SELECT * FROM empresas WHERE user ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {  

if(($row->curr1 == "0") AND ($row->curr2 == "0")) { ?> 
<a href="<?php echo 'curriculums-adquiridos.php';?>">Curriculums Adquiridos</a>
<?php  } ?> 


<?php
if($row->curr1 == "1") { ?>
<a href="<?php echo 'curriculums.php';?>">Curriculums sin Datos de Contacto</a>
<?php } ?>

<?php 
if($row->curr2 == "1"){ ?>
<a href="<?php echo 'curriculum-contacto.php';?>">Curriculums con Datos de Contacto</a>
<?php } ?>

</li>

<?php } ?>

                	
                </li>
            </ul>
        </li>
        <li class="menu-titulo" data-target="submenu-puntos">Créditos</li>
        <li class="submenu" id="submenu-puntos">
            <ul>
                <li><a href="comprar-creditos.php">Comprar</a></li>
                <li><a href="historico-compras.php">Histórico de compras</a></li>
                <li><a href="movimientos.php">Histórico de movimientos</a></li>
            </ul>
        </li>
        <li class="menu-titulo" data-target="submenu-centros">Centros</li>
        <li class="submenu" id="submenu-centros">
            <ul>
                <li><a href="listado-centros.php">Ver centros</a></li>
                <li><a href="nuevo-centro.php">Alta nuevo centro</a></li>
            </ul>
        </li>
        <li class="menu-titulo" data-target="submenu-datos">Mi perfil</li>
        <li class="submenu" id="submenu-datos">
            <ul>
                <li><a href="datos-acceso-empresa.php">Datos de acceso</a></li>
                <li><a href="datos-facturacion.php">Datos de facturación</a></li>
                <li><a href="/empresas/recomendar-mediempleo">Recomendar Mediempleo</a></li>
                <li><a href="/empresas/baja-del-servicio">Darse de baja</a></li>
            </ul>
        </li>
    </ul>
</div>
					<img class="img-responsive img-thumbnail"  src="img/italiano.png">
                        <p class="jk">Cursos de Posgrado en el<br>
                        Instituto Universitario</p>
                        <img class="img-responsive img-thumbnail"  src="img/cposgrado.jpg">
                        <h2>Principios de Inscripciones</h2>
                   <img class="img-responsive img-thumbnail"  src="img/cruz.png">

			</aside>
		
			<div id="content-right">
				<div style="float:left;width:100%">
	</div>									<div id="publi-empresa">
						<a href="/wiki-empresas" style="margin-left:50px">
							<img src="img/como-funcionan-creditos.jpg" 
							 	 alt="Como funcionan los créditos en MedicalJob"
							 	 title="Como funcionan los créditos en MedicalJob" />
						</a>
						<a href="/centros-empresas/publicar-ofertas">
							<img src="img/ayuda-para-publicar.jpg" 
								 alt="Ayuda para publicar ofertas en MedicalJob"
								 title="Ayuda para publicar ofertas en MedicalJob" />
						</a>
						<a href="nueva-oferta.php">
							<img src="img/publica-tu-oferta.jpg" 
								 alt="Publica tu oferta en MedicalJob"
								 title="Publica tu oferta en MedicalJob"
								 style="float:right;margin-right:5px" />
						</a>
					</div>
								  
        <div class="mediempleo-box">
            <div class="content">
                <div class="box-header">
                    <div class="box-title">
                        <h1>Listado de currículums adquiridos</h1>
                    </div>
                </div>
                <div class="box-content">
                    <table class="tabla-empresa">
                    	<thead>
                    		<tr>
                    			<th>Nombre</th>
                    			<th>Oferta</th>
                    			<th>Inscripción</th>
                    			<th></th>
                    			<th></th>
                    		</tr>
                    	</thead>
                        <tbody>
                        	<?php
         $sql = "SELECT * FROM Ccurriculum  WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as  $row) { ?>   
                                                            <tr>
                                    <td><?php echo utf8_encode($row->especialidad); ?></td>
<td><?php echo utf8_encode($row->puesto); ?></td>
<td><?php echo utf8_encode($row->descripcionPuesto); ?></td>
<td><?php echo utf8_encode($row->pais); ?></td>
<td><?php echo utf8_decode($row->estado); ?></td>
                                </tr>
                                                    </tbody>
                                                    <?php } ?>
                    </table>
                </div>
            </div>
        </div>
			</div>
		</div>
		<footer id="footer">	
	<div id="container-footer-especialidades">
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Medicina</li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li></li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li></li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li></li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li></li>
									<li></li>
									<li> </li>
									<li> <</li>
									<li></li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li></li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li> </li>
									<li></li>
									<li> </li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Enfermería</li>
									<li>> </li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-de-salud-mental/">Enfermería de Salud Mental</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-geriatrica/">Enfermería Geriátrica</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-del-trabajo/">Enfermería del Trabajo</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-de-cuidados-medico-quirurgicos/">Enfermería de Cuidados Médico – Quirúrgicos</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-familiar-y-comunitaria/">Enfermería Familiar y Comunitaria</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-pediatrica/">Enfermería Pediátrica</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria/">Enfermería</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Farmacia</li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-analisis-clinicos/">Análisis Clínicos</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-bioquimica-clinica/">Bioquímica Clínica</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-farmacia-hospitalaria/">Farmacia Hospitalaria</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-microbiologia-y-parasitologia-clinicas/">Microbiología y Parasitología Clínicas</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-radiofarmacia-hospitalaria/">Radiofarmacia Hospitalaria</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-farmacia-industrial-y-galenica/">Farmacia Industrial y Galénica</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-inmunologia/">Inmunología</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-farmacia/">Farmacia</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Técnico auxiliar de farmacia</li>
									<li>> <a href="/ofertas-trabajo/tecnico-auxiliar-de-farmacia/farmacia-auxiliar-de-farmacia/">Auxiliar de farmacia</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Auxiliar de enfermería</li>
									<li>> <a href="/ofertas-trabajo/auxiliar-de-enfermera/enfermeria-auxiliar-de-enfermeria/">Auxiliar de enfermería</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Otras Ofertas</li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-indeed/">Seleccion Indeed</a></li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-infojobs-medicina-general/">Selección Infojobs Medicina General</a></li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-infojobs-medicina-especializada/">Selección Infojobs Medicina Especialista</a></li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-infojobs-enfermeria/">Selección Infojobs Enfermería</a></li>
							</ul>
		</div>
		
		
	</div>
	<div id="footer-aside">
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Empleo Público</li>
				<li><a href="/publicaciones/1">Publicaciones</a></li>
				<li><a href="/oposiciones/1">Oposiciones</a></li>
			</ul>
		</div>
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Networking</li>
				<li>
					<a target="_blank" title="Perfil de Mediempleo en Linkedin" href="http://www.linkedin.com/company/mediempleo/">Linkedin</a>
				</li>
				<li>
					<a target="_blank" title="Twitter de Mediempleo" href="https://twitter.com/MediEmpleoTweet">Twitter</a>
				</li>
				<li>
					<a href="/links-interesantes">Links interesantes</a>
				</li>
			</ul>
		</div>
		<figure id="logo-footer">
			<img class="img-responsive img-thumbnail" src="img/log.jpg" alt="Logo de MedicalJob" title="MedicalJob, tu web de empleo médico" width="90%" />
		</figure>
		<div id="info-footer">
			<b>Copyright &copy; 2018 </b><br />
			<a href="/informacion-legal">Información legal</a><br />
			<a href="/politica-privacidad">Política de privacidad</a> |
			<a href="/normativa">Normativa</a> |
			<a href="/contacto">Contacto</a>
		</div>	
	</div>
	
		
</footer>	</div>
                
        	<script src="js2/router.js"></script>
	<script src="js2/routing?callback=fos.Router.setData"></script>
	<script src="js2/jquery-1.9.1.min.js"></script>
    <script src="js2/jquery-ui-1.10.3.custom.min.js"></script>
	<script src="js2/frontend.js"></script>
	<script src="js2/bootstrap.js"></script>
			<script src="js2/empresa.js"></script>
	 
        
    </body>
</html>