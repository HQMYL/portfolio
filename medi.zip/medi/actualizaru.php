<!DOCTYPE html>
<html>
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}

if(isset($_GET['id'])) {
$id = $_GET['id'];
}
?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DemiJob</title>

    <!-- Bootstrap Core CSS -->
    <link href="css3/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css3/sb-admin.css" rel="stylesheet">
    <link href="css3/new.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css3/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
        .navbar-brand {
color: blue;
}
    a {
            color: #fff;
        }

.select-centros {
    width: 90%;
}

    </style>
    

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" style="color: #fff;" href="admin.php">Inicio</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
               <li><a style="color: #fff;" class="btn-danger"><?php echo "Bienvenido: " .$usuario; ?></a></li>
              <li><a style="color: #fff;" class="btn-danger" href="logout.php">Cerrar Sesión</a></li> 
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="admin.php"><i class="fa fa-fw fa-dashboard"></i> Panel de Control</a>
                    </li>
                    
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo"><i></i> Usuarios <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="agregarusuario.php">Agregar Usuario</a>
                            </li>
                            <li>
                                <a href="consultarusuario.php">Consultar Usuario</a>
                            </li>
                            
                        </ul>
                    </li>

                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo1"> Empresas <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo1" class="collapse">
                            <li>
                                <a href="agregarempresa.php">Agregar Empresa</a>
                            </li>
                            <li>
                                <a href="consultarempresa.php">Consultar Empresa</a>
                            </li>
                            
                        </ul>
                    </li>
                   <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo3"><i></i> Empleos <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo3" class="collapse">
                            <li>
                                <a href="agregarempleo.php">Agregar Empleos</a>
                            </li>
                            <li>
                                <a href="consultarempleo.php">Consultar Empleos</a>
                            </li>
                            
                        </ul>
                    </li>   
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo4"><i></i> Oposiciones <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo4" class="collapse">
                            <li>
                                <a href="agregaroposicion.php">Agregar Oposición</a>
                            </li>
                            <li>
                                <a href="consultaroposicion.php">Consultar Oposición</a>
                            </li>
                            
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo5"><i></i> Reportes <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo5" class="collapse">
                            <li>
                                <a href="ventas.php">Ventas</a>
                            </li>
                            <li>
                                <a href="creditos-adquiridos.php">Usuarios Registrados</a>
                            </li>
                            
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header">
                            ACTUALIZACIÓN
                        </h3>
                        <ol class="breadcrumb">
                            
                        </ol>
                    </div>
                </div>
                <div>    
 
            <div id="consi">
      

<form class="form" method="POST" action="actualizar2.php">
<fieldset>
<div class="col-md-6">

<label>COLECTIVO <span class="tooltip">?</span></label>
<select  id="cmbcolectivo" name="cmbcolectivo" class="select-centros">
            <option value="">Seleccione el Colectivo</option>

         <?php 
      
         
         $sql = "SELECT * FROM colectivo";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->id .'">'.utf8_encode ($row->nombre).'</option>';

        
    }

    ?>
</select>
</div>
<div class="col-md-6">
 <label>ESPECIALIDAD <span class="tooltip">?</span></label>
<select id="cmbespec" name="cmbespec" class="select-centros">
 <option value="">Selecciona la Especialidad</option>
</select>

</div>

<?php

 $sql = "SELECT * FROM usuarios WHERE id ='".$id."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { ?>

<div class="col-md-6">
<label>NOMBRE <span class="tooltip">?</span></label>
<input type="text" class="select-centros" name="nombre" id="nombre"  value=" <?php echo utf8_encode($row->nombre);?> ">
</div>
<div class="col-md-6">
<label>PRIMER APELLIDO <span class="tooltip">?</span></label>
<input type="text" class="select-centros" name="apellido1" id="apellido1" readonly="true" value="<?php echo utf8_encode($row->apellido1); ?>">
</div>
<div class="col-md-6">
<label>SEGUNDO APELLIDO <span class="tooltip">?</span></label>
 <input type="text" class="select-centros" name="apellido2" id="apellido2" readonly="true" value="<?php echo utf8_encode($row->apellido2); ?>">
 </div>
 
<div class="col-md-6">
 <label>FECHA DE NACIMIENTO<span class="tooltip">?</span></label>
 <input type="text" class="select-centros" name="nac" id="nac" value=" <?php echo $row->Nacimiento; ?>">
</div>

<div class="col-md-6">
 <label>PAÍS<span class="tooltip">?</span></label>
 <select id="cmbpais" name="cmbpais">
            <option value="">Seleccione el Pais</option>

         <?php 
      
         
         $sql = "SELECT * FROM pais";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->paisnombre .'">'.utf8_encode ($row->paisnombre).'</option>';

        
    }

    ?>
</select>
<?php } ?>
</div>
<?php

 $sql = "SELECT * FROM usuarios WHERE id ='".$id."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { ?>
<div class="col-md-6">
 <label>CORREO<span class="tooltip">?</span></label>
 <input type="text" class="select-centros" name="correo" id="correo" value=" <?php echo utf8_encode($row->correo); ?>">
</div>

<div class="col-md-6">
 <label>DIRECCIÓN<span class="tooltip">?</span></label>
 <input type="text" class="select-centros" name="dir" id="dir" value="<?php echo utf8_encode($row->dir); ?>">   

</div>

<div class="col-md-6">
 <label>Nº CALLE<span class="tooltip">?</span></label>
 <input type="text" class="select-centros" name="ncalle" id="ncalle" value="<?php echo utf8_encode($row->Ncalle); ?>">   

</div>

<div class="col-md-6">
 <label>PISO<span class="tooltip">?</span></label>
 <input type="text" class="select-centros" name="piso" id="piso" value="<?php echo utf8_encode($row->piso); ?>">   

</div>

<div class="col-md-6">
 <label>DEPARTAMENTO<span class="tooltip">?</span></label>
 <input type="text" class="select-centros" name="dep" id="dep" value="<?php echo utf8_encode($row->departamento); ?>">   

</div>



<div class="col-md-6">
 <label>CÓDIGO POSTAL<span class="tooltip">?</span></label>
 <input type="text" class="select-centros" name="cp" id="cp" value="<?php echo utf8_encode($row->CodigoPostal); ?>">   

</div>


 <div class="col-md-6">
 <label>LOCALIDAD<span class="tooltip">?</span></label>
 <input type="text" class="select-centros" name="loc" id="loc" value=" <?php echo $row->localidad; ?>">
</div>


<div class="col-md-6">
 <label>PROVINCIA<span class="tooltip">?</span></label>
 <input type="text" class="select-centros" name="prov" id="prov" value=" <?php echo $row->provincia; ?>">
</div>

<div class="col-md-6">
 <label>TIPO<span class="tooltip">?</span></label>
 <input type="text" class="select-centros" name="tipo" id="tipo" value=" <?php echo $row->tipo; ?>">
<input type="hidden" class="select-centros" name="user" id="user" value="<?php echo $row->usuario;?>">
<input type="hidden" class="select-centros" name="pass" id="pass" value="<?php echo $row->pass;?>">
<input type="hidden" class="select-centros" name="creditos" id="creditos" value="<?php echo $row->creditos;?>">
<input type="hidden" class="select-centros" name="pagovisitas" id="pagovisitas" value="<?php echo $row->pagovisitas;?>">
<input type="hidden" class="select-centros" name="pagocurri" id="pagocurri" value="<?php echo $row->pagocurri;?>">
<input type="hidden" class="select-centros" name="curr1" id="curr1" value="<?php echo $row->curr1;?>">
<input type="hidden" class="select-centros" name="curr2" id="curr2" value="<?php echo $row->curr2;?>">
<input type="hidden" class="select-centros" name="id" id="id" value="<?php echo $row->id;?>">

</div>

 </fieldset><br>
<button class="btn btn-danger" type="submit">Actualizar</button>
 </form>

<?php } ?>
  </div>

                
            </div>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
     <script src="js3/jquery-3.js"></script>

    
    <!-- Bootstrap Core JavaScript -->
    <script src="js3/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js3/plugins/morris/raphael.min.js"></script>
    <script src="js3/plugins/morris/morris.min.js"></script>
    <script src="js3/plugins/morris/morris-data.js"></script>

<script type="text/javascript">

$(document).ready(function() {

  $("#cmbcolectivo").change(function(){
          
      var id=$("#cmbcolectivo").val();
      $('#cmbespec').load('escoger3.php?id='+id);
});
});  
</script> 





</body>

</html>
