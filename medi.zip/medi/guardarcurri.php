<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}



if (isset($_POST["pres"])) {
	$pres = $_POST["pres"];
}


if (isset($_POST["titulacion"])) {
	$titulacion = utf8_decode($_POST["titulacion"]);
}


if (isset($_POST["cmbespec"])) {
  $espec = utf8_decode($_POST["cmbespec"]);
}


if (isset($_POST["estado"])) {
  $estado = utf8_decode($_POST["estado"]);
}




if (isset($_POST["univer"])) {
	$univer = utf8_decode($_POST["univer"]);
}



if (isset($_POST["anyo"])) {
	$anyo = $_POST["anyo"];
}

if (empty($_POST["anyo"])) {
   $anyo = "0";
}


if (isset($_POST["colegiado"]) ) {
  $colegiado = $_POST["colegiado"];

  }

   if (empty($_POST["colegiado"])) {
      $colegiado = "N/A";
   }


if (isset($_POST["nacional"])) {
   $nacional = utf8_encode($_POST["nacional"]);
}


if (empty($_POST["nacional"])) {
   $nacional = "0";
}


if (isset($_POST["estatal"])) {
   $estatal = utf8_encode($_POST["estatal"]);
}


if (empty($_POST["estatal"])) {
   $estatal = "0";
}





if (isset($_POST["hobbies"])) {
	$hobbies = utf8_decode($_POST["hobbies"]);
}




$sql = "INSERT INTO curriculum (usuario,presentacion, titulacion,especialidad,estado,universidad,finalizacion, colegiado, MatriculaNacional,MatriculaEstatal,hobbies) VALUES (:usuario,:pres,:titulacion,:espec,:estado, :univer, :anyo,:colegiado,:nacional,:estatal,:hobbies)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':pres', $pres, PDO::PARAM_STR);
$stmt->bindParam(':titulacion', $titulacion, PDO::PARAM_STR);
$stmt->bindParam(':espec', $espec, PDO::PARAM_STR);
$stmt->bindParam(':estado', $estado, PDO::PARAM_STR);
$stmt->bindParam(':univer', $univer, PDO::PARAM_STR); 
$stmt->bindParam(':anyo', $anyo, PDO::PARAM_STR); 
$stmt->bindParam(':colegiado', $colegiado, PDO::PARAM_STR);
$stmt->bindParam(':nacional', $nacional, PDO::PARAM_STR);
$stmt->bindParam(':estatal', $estatal, PDO::PARAM_STR);
$stmt->bindParam(':hobbies', $hobbies, PDO::PARAM_STR);

 
$stmt->execute();

 
?>

<script>
alert('El Curriculum a sido agregado exitosamaente');
window.location.href='curriculum.php';
</script>

</body>
<html>