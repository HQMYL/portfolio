 <?php
require_once'conexion.php';
    
if($_POST) {
    $cedula = $_POST["id"];
    $sql="SELECT * FROM usuarios WHERE usuario = '$cedula";
if ($result=mysqli_query($con,$sql))
  {
  // Return the number of rows in result set
  $rowcount=mysqli_num_rows($result);
  //printf("Result set has %d rows.\n",$rowcount); mostrar resultado
 if($rowcount > 0)
        echo '<div id="Error">Cedula ya registrada</div>';
    else
        echo '<div id="Success">Disponible</div>';
}
  }



?>

