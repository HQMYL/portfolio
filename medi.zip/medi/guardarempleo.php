<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
include("conexion.php");

if (isset($_POST["fecha"])) {
	$fecha = $_POST["fecha"];
}


if (isset($_POST["desc"])) {
	$descrip = utf8_decode($_POST["desc"]);
	
}


if (isset($_POST["emp"])) {
	$emp = utf8_decode($_POST["emp"]);
}

if (isset($_POST["ubi"])) {
	$ubi = utf8_decode($_POST["ubi"]);
	
}

if (isset($_POST["tel"])) {
	$tel = $_POST["tel"];
}



if (isset($_POST["sal"])) {
	$sal = $_POST["sal"];
}







$sql = "INSERT INTO empleos (fecha,descripcion,empresa,salario,telefono,ubicacion) VALUES (:fecha,:descrip,:emp,:sal,:tel,:ubi)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':fecha', $fecha, PDO::PARAM_STR); 
$stmt->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt->bindParam(':emp', $emp, PDO::PARAM_STR);
$stmt->bindParam(':sal', $sal, PDO::PARAM_STR);
$stmt->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt->bindParam(':ubi', $ubi, PDO::PARAM_STR);

$stmt->execute();

?>

<script>
alert('El empleo a sido agregado exitosamaente');
window.location.href='agregarempleo.php';
</script>

</body>
<html>