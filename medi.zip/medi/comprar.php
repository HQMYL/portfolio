<form name='formTpv' method='post' action='https://www.sandbox.paypal.com/cgi-bin/webscr' style="border: 1px solid #CECECE;padding-left: 10px;">
                        <input name="cmd" type="hidden" value="_cart">
                        <input name="upload" type="hidden" value="1">
                        <input name="business" type="hidden" value="Clubjohnson@hotmail.com">
                        <input name="shopping_url" type="hidden" value="http://clubjohnson.mx/">
                        <input type="hidden" name="shipping" value="150.00">
                        <input name="currency_code" type="hidden" value="USD">
                        <input name="return" type="hidden" value="http://clubjohnson.mx/exito.php">
                        <input type='hidden' name='cancel_return' value='http://clubjohnson.mx/errorPaypal.php'>
                        <input name="notify_url" type="hidden" value="http://clubjohnson.mx/paypalipn.php">
                        <input name="rm" type="hidden" value="2">
                        <input type="hidden" name="amount" value="0.00">


                        <?php
                            $contador = 0;
                            foreach($_SESSION['carro'] as $key=>$valor){
                                    $contador ++;
                                    $fi=$obj->getProductosPorId($key);
                                    foreach($fi as $fila){
                                    $id=$fila['CodigoProd'];
                                    $producto=$fila['NombreProd'];
                                    $precio=$fila['precio'];
                                    
                            }
                       ?>

                      <input name="item_number_<?php echo $contador; ?>" type="hidden" value="<?php echo $id; ?>"><br>
                      <input name="item_name_<?php echo $contador; ?>" type="hidden" value="<?php echo $producto; ?>"><br>
                      <input name="amount_<?php echo $contador; ?>" type="hidden" value="<?php echo $precio; ?>"><br>
                      <input name="quantity_<?php echo $contador; ?>" type="hidden" value="<?php echo $valor; ?>"><br>

                      <?php
                          }
                      ?>
                      
                      <script>
                        document.formTpv.submit();
                      </script>

                    </form>