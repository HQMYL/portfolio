<!doctype html>
<html>

<body>
<?php 
include("conexion.php");
if (isset($_GET['id'])) {
	$id = $_GET['id'];
}

$sql = "DELETE FROM centros WHERE id=:id";
$stmt = $con->prepare($sql);
$stmt->bindParam(':id', $id, PDO::PARAM_STR); 
$stmt->execute();

?>
<script>
alert('El centro a sido Eliminado exitosamaente');
window.location.href='lista-centros.php';
</script>
</body>
</html>
