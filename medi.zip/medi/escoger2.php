<?php
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}

$pa = "";
if (isset($_GET["id"])) {
	$pa = $_GET["id"];
}


 $sql = "SELECT * FROM estado WHERE ubicacionpaisid ='".$pa."'";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
foreach ($rows as $row) {

echo '<option value="'. utf8_encode($row->estadonombre) .'">'.utf8_encode ($row->estadonombre).'</option>';
}


 ?>