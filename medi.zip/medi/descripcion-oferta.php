
	<!DOCTYPE html>
<html lang="es">
<?php
session_start();
include("conexion.php");
include("inc/funciones.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}

if(isset($_GET['id'])) {
$id = $_GET['id'];}


?>
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="182 Ofertas de trabajo para Selección Infojobs Enfermería" />
		        <title>MedicalJob, bolsa de empleo con ofertas de trabajo en sector de salud
</title>
        <!--[if lt IE 9]>
        	<script src="/bundles/comun/js/html5shiv.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
                <link rel="stylesheet" type="text/css" href="css2/css.css" />
        	<link rel="stylesheet" type="text/css" href="css2/reset.css" />
    <link rel="stylesheet" type="text/css" href="css2/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css2/frontend.css" />
	<link rel="stylesheet" type="text/css" href="css2/forms.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery.fancybox.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery-ui-1.10.3.custom.min.css" />

<link rel="stylesheet" type="text/css" href="css2/profesional-sanitario.css" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="apple-touch-icon" sizes="114x114" href="" />
        <link rel="apple-touch-icon" sizes="72x72" href="" />
        <link rel="apple-touch-icon" href="" />
        <style type="text/css">
        	.btn, .btn-danger {
        		float: right;
        	}

        	#pagina {
width: 95%;	
}
        </style>
    </head>
    <body itemscope itemtype="http://schema.org/WebPage">
		<div id="cargando" style="display:none"></div>
		    				        		<div id="pagina">
		<header id="header">
			<div id="banner">
				<img class="img-responsive" src="img/portada.jpg" alt="MedicalJob: Trabaja en el sector sanitario en cualquier parte del mundo" />
			</div>
					</header>
		<div id="contenido">
			<div id="breadcrumb" itemprop="breadcrumb">
							<a href="index.php">
					<span class="glyphicon glyphicon-home"></span> Inicio
				</a> > 
			<a href="lista-ofertas.php" >Ofertas de trabajo para profesionales sanitarios</a> </div>
					
			<aside id="sidebar">
							<div id="contadores">
	<div class="contador contador-profesionales">
		<div class="cifra-contador">
			
			<?php
			$sql = "SELECT * FROM usuarios"; 
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
$total = 0;
foreach ($rows as $row) {
$total = $total + 1;
}
?>
			<strong><?php echo $total; ?></strong>
		</div>
		<div class="texto-contador">profesionales<br />sanitarios</div>
	</div>
	<div class="contador contador-empresas">
		<div class="cifra-contador">
			<?php
			$sql = "SELECT * FROM empresas"; 
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
$total = 0;
foreach ($rows as $row) {
$total = $total + 1;
}
?>
			<strong><?php echo $total; ?></strong>
		</div>
		<div class="texto-contador">centros y<br />empresas</div>
	</div>
	</div>									<h2 class="titulo-sidebar-box">REGÍSTRATE, ES GRATIS</h2>
					<div class="sidebar-box">
						<a href="/alta-usuario" class="boton-registro boton-registro-profesionales">
	soy <br />profesional <br />sanitario
</a>
<a href="/alta-empresa" class="boton-registro boton-registro-empresas">
	soy <br />centro o <br />empresa
</a>
					</div>
					<h2 class="titulo-sidebar-box">ACCEDE A TU CUENTA</h2>
					<div class="sidebar-box sidebar-box-bordered">
						 
	<form id="login" action="/login_check" method="post" style="width:90%;margin:10px auto">
		<div class="form-widget-container">
			<label for="input-login">EMAIL</label>
			<input type="email" required="required" id="user" name="user" class="text-input-border" />
		</div>
		<div class="form-widget-container">
			<label for="input-password">CONTRASEÑA</label>
			<input type="password"  id="pass" name="pass" class="text-input-border" />
		</div><br>
		<div class="form-widget-container">
			<input type="checkbox" id="input-remember-me" name="_remember_me" checked />
			<label id="recuerdame" for="input-remember-me">No cerrar sesión</label>
			<button class="btn btn-danger" type="submit">Ingresar</button>
		</div>
		<div class="form-widget-container">			
			<p><strong style="font-size:9px"><a href="/olvide-mi-contrasena">¿Olvidaste tu contraseña?</a></strong></p>
		</div>
	</form>
					</div>
									<a  target="_blank" 
						href="" 
						style="margin-bottom:20px" >
						<img width="200" height="200" src="img/master250x250.jpg">
					</a>
        									</aside>
		
			<div id="content-right">
				<div style="float:left;width:100%">
	</div>								<div class="mediempleo-box">
			<h2></h2>
			<p style="text-align:center">
							<span style="font-size: 20px;line-height: 25px;">
								</span>
						</p>
		</div>
		
		<p></p>

    
		<div class="mediempleo-box" style="width:100%;">
			<h1></h1>
			<div class="content" style="padding-top: 3%">
				<?php
         $sql = "SELECT * FROM empleos WHERE id ='".$id."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row_id =>  $row) {

echo listaoferta($row_id, $row);

}
 ?>   
																					
</div>
		</div>
			</div>
		</div>
		<footer id="footer">	
	<div id="container-footer-especialidades">
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Medicina</li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-alergologia/">Alergología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-analisis-clinicos/">Analisis Clínicos</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-anatomia-patologica/">Anatomia Patológica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-anestesiologia-y-reanimacion/">Anestesiología y Reanimación</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-angiologia-y-cirugia-vascular/">Angiología y Cirugía Vascular</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-aparato-digestivo/">Aparato Digestivo</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-bioquimica-clinica/">Bioquímica Clínica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cardiologia/">Cardiología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-cardiovascular/">Cirugía Cardiovascular</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-general-y-del-aparato-digestivo/">Cirugía General y del Aparato Digestivo</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-maxilofacial/">Cirugía Maxilofacial</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-oral-y-maxilofacial/">Cirugía Oral y Maxilofacial</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-pediatrica/">Cirugía Pediátrica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-plastica-estetica-y-reparadora/">Cirugía Plástica Estética y Reparadora</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-plastica-y-reconstructiva/">Cirugía Plástica y Reconstructiva</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-toracica/">Cirugía Toracica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-dermatologia/">Dermatología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-endocrinologia-y-nutricion/">Endocrinología y Nutricion</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-farmacologia-clinica/">Farmacología Clínica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-geriatria/">Geriatria</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-hematologia-y-hemoterapia/">Hematología y Hemoterapia</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-hidrologia-y-balneoterapia/">Hidrología y Balneoterapia</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-inmunologia/">Inmunología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-de-la-educacion-fisica/">Medicina De La Educación Física</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-del-trabajo/">Medicina del Trabajo</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-educacion-fisica/">Medicina Educación Física</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-familiar-y-comunitaria/">Medicina Familiar y Comunitaria</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-fisica-y-rehabilitacion/">Medicina Física y Rehabilitación</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-intensiva/">Medicina Intensiva</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-interna/">Medicina Interna</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-legal-y-forense/">Medicina Legal y Forense</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-nuclear/">Medicina Nuclear</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-preventiva-y-salud-publica/">Medicina Preventiva y Salud Pública</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-microbiologia-y-parasitologia/">Microbiología y Parasitología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-nefrologia/">Nefrología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-neumologia/">Neumología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-neurocirugia/">NeuroCirugía</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-neurofisiologia-clinica/">Neurofisiología Clínica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-neurologia/">Neurología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-obstetricia-y-ginecologia/">Obstetricia y Ginecología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-oftalmologia/">Oftalmología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-oncologia-medica/">Oncología Médica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-oncologia-radioterapeutica/">Oncología Radioterapéutica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-oncologia-radioterapica/">Oncología Radioterápica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-otorrinolaringologia/">Otorrinolaringología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-pediatria-y-areas-especificas/">Pediatría y Áreas Específicas</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-psiquiatria/">Psiquiatría</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-radiodiagnostico/">Radiodiagnóstico</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-reumatologia/">Reumatología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-traumatologia-y-cirugia-ortopedica/">Traumatología y Cirugía Ortopédica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-urologia/">Urología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina/">Medicina</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Enfermería</li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-obstetrico-ginecologica-matrona/">Enfermería Obstétrico – Ginecológica (Matrona)</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-de-salud-mental/">Enfermería de Salud Mental</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-geriatrica/">Enfermería Geriátrica</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-del-trabajo/">Enfermería del Trabajo</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-de-cuidados-medico-quirurgicos/">Enfermería de Cuidados Médico – Quirúrgicos</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-familiar-y-comunitaria/">Enfermería Familiar y Comunitaria</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-pediatrica/">Enfermería Pediátrica</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria/">Enfermería</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Farmacia</li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-analisis-clinicos/">Análisis Clínicos</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-bioquimica-clinica/">Bioquímica Clínica</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-farmacia-hospitalaria/">Farmacia Hospitalaria</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-microbiologia-y-parasitologia-clinicas/">Microbiología y Parasitología Clínicas</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-radiofarmacia-hospitalaria/">Radiofarmacia Hospitalaria</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-farmacia-industrial-y-galenica/">Farmacia Industrial y Galénica</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-inmunologia/">Inmunología</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-farmacia/">Farmacia</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Técnico auxiliar de farmacia</li>
									<li>> <a href="/ofertas-trabajo/tecnico-auxiliar-de-farmacia/farmacia-auxiliar-de-farmacia/">Auxiliar de farmacia</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Auxiliar de enfermería</li>
									<li>> <a href="/ofertas-trabajo/auxiliar-de-enfermera/enfermeria-auxiliar-de-enfermeria/">Auxiliar de enfermería</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Otras Ofertas</li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-indeed/">Seleccion Indeed</a></li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-infojobs-medicina-general/">Selección Infojobs Medicina General</a></li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-infojobs-medicina-especializada/">Selección Infojobs Medicina Especialista</a></li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-infojobs-enfermeria/">Selección Infojobs Enfermería</a></li>
							</ul>
		</div>
		
		
	</div>
	<div id="footer-aside">
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Empleo Público</li>
				<li><a href="/publicaciones/1">Publicaciones</a></li>
				<li><a href="/oposiciones/1">Oposiciones</a></li>
			</ul>
		</div>
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Networking</li>
				<li>
					<a target="_blank" title="Perfil de Mediempleo en Linkedin" href="http://www.linkedin.com/company/mediempleo/">Linkedin</a>
				</li>
				<li>
					<a target="_blank" title="Twitter de Mediempleo" href="https://twitter.com/MediEmpleoTweet">Twitter</a>
				</li>
				<li>
					<a href="/links-interesantes">Links interesantes</a>
				</li>
			</ul>
		</div>
		<figure id="logo-footer">
			<img class="img-responsive img-thumbnail" src="img/log.jpg" alt="Logo de MedicalJob" title="MedicalJob, tu web de empleo médico" width="90%" />
		</figure>
		<div id="info-footer">
			<b>Copyright &copy; 2018 </b><br />
			<a href="/informacion-legal">Información legal</a><br />
			<a href="/politica-privacidad">Política de privacidad</a> |
			<a href="/normativa">Normativa</a> |
			<a href="/contacto">Contacto</a>
		</div>	
	</div>
	
		
</footer>	</div>
               
        	<script src="js2/router.js"></script>
	<script src="js2/routing?callback=fos.Router.setData"></script>
	<script src="js2/jquery-1.9.1.min.js"></script>
    <script src="js2/jquery-ui-1.10.3.custom.min.js"></script>
	<script src="js2/frontend.js"></script>
	<script src="js2/bootstrap.js"></script>
    <script src="js2/angular.min.js"></script>
    <script src="js2/ng-table.js"></script>
	<script type="text/javascript" src="js2/jquery.fancybox.pack.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$("a[rel='fancybox']").fancybox({
				'transitionIn'	:	'elastic',
				'transitionOut'	:	'elastic',
				'speedIn'		:	600, 
				'speedOut'		:	200, 
				'overlayShow'	:	true,
				'type'			:	'iframe',
				'showNavArrows': 	false
			});
		});
	</script>
        
    </body>
</html>
