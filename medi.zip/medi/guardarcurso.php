<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}



if (isset($_POST["curso"])) {
	$curso = utf8_decode($_POST["curso"]);
}

if (isset($_POST["lugar"])) {
	$lugar = utf8_decode($_POST["lugar"]);
}


if (isset($_POST["horas"])) {
	$horas = utf8_decode($_POST["horas"]);
}





if (isset($_POST["creditos"])) {
	$creditos = utf8_decode($_POST["creditos"]);
}

if (isset($_POST["fechaFin"])) {
	$fechaFin = utf8_decode($_POST["fechaFin"]);
}




$sql = "INSERT INTO cursos (usuario,curso,lugar,horas,creditos,fechafin) VALUES (:usuario,:curso,:lugar,:horas, :creditos,:fechaFin)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':curso', $curso, PDO::PARAM_STR);
$stmt->bindParam(':lugar', $lugar, PDO::PARAM_STR);
$stmt->bindParam(':horas', $horas, PDO::PARAM_STR); 
$stmt->bindParam(':creditos', $creditos, PDO::PARAM_STR);
$stmt->bindParam(':fechaFin', $fechaFin, PDO::PARAM_STR); 
$stmt->execute();
 
?>

<script>
alert('El Curso a sido agregado exitosamaente');
window.location.href='curriculum.php';
</script>

</body>
<html>