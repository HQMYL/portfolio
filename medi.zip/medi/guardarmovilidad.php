<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}



if (isset($_POST["cmbpais"])) {
	$pais = utf8_decode($_POST["cmbpais"]);
}

if (isset($_POST["cmbciudad"])) {
	$ciudad = utf8_decode($_POST["cmbciudad"]);
}


if (isset($_POST["horas"])) {
	$horas = utf8_decode($_POST["horas"]);
}




$sql = "INSERT INTO movilidad (usuario,pais,ciudad) VALUES (:usuario,:pais,:ciudad)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':pais', $pais, PDO::PARAM_STR);
$stmt->bindParam(':ciudad', $ciudad, PDO::PARAM_STR);
$stmt->execute();
 
?>

<script>
alert('Los datos han sido agregados  exitosamaente');
window.location.href='curriculum.php';
</script>

</body>
<html>