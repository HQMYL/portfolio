<!doctype html>
<html>

<body>
<?php 
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
}

$sql = "DELETE FROM usuarios WHERE usuario=:usuario";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR); 
$stmt->execute();
session_destroy();
?>
<script>
alert('La cuenta a sido Eliminada exitosamaente');
window.location.href='index.php';
</script>
</body>
</html>
