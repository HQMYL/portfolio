<!DOCTYPE html>
<html lang="es">
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
?>
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="Información legal de Medicaljob, bolsa de empleo online del sector sanitario con ofertas de trabajo para médicos, enfermeras y auxiliares" />
		        <title>Información legal de Medicaljob, bolsa de trabajo de empleos de salud</title>
        <!--[if lt IE 9]>
        	<script src="/bundles/comun/js/html5shiv.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
                <link rel="stylesheet" type="text/css" href="css2/css.css" />
        	<link rel="stylesheet" type="text/css" href="css2/reset.css" />
    <link rel="stylesheet" type="text/css" href="css2/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css2/frontend.css" />
	<link rel="stylesheet" type="text/css" href="css2/forms.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery.fancybox.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery-ui-1.10.3.custom.min.css" />
    <link rel="stylesheet" type="text/css" href="css3/new.css" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="apple-touch-icon" sizes="114x114" href="" />
        <link rel="apple-touch-icon" sizes="72x72" href="" />
        <link rel="apple-touch-icon" href="" />
        <style type="text/css">

              .azul {
                color: blue;
              }
            .btn, .btn-danger {
                float: right;
            }
            
        </style>
    </head>
    <body itemscope itemtype="http://schema.org/WebPage">
		<div id="cargando" style="display:none"></div>
		    				        		<div id="pagina">
		<header id="header">
			<div id="banner">
				<img class="img-responsive" src="img/portada.jpg" alt="Mediempleo: Trabaja en el sector sanitario en cualquier parte del mundo" />
			</div>
					</header>
		<div id="contenido">
			<div id="breadcrumb" itemprop="breadcrumb">
								<a href="index.php">
					<span class="glyphicon glyphicon-home"></span> Inicio
				</a> > 
			Información Legal
			</div>
					
			<aside id="sidebar">
							<div id="contadores">
	<div class="contador contador-profesionales">
        <?php
            $sql = "SELECT * FROM usuarios"; 
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
$total = 0;
foreach ($rows as $row) {
$total = $total + 1;
}
?>
		<div class="cifra-contador">
			<strong><?php echo $total; ?></strong>
		</div>
		<div class="texto-contador">profesionales<br />sanitarios</div>
	</div>
	<div class="contador contador-empresas">
		<div class="cifra-contador">
            <?php
            $sql = "SELECT * FROM empresas"; 
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
$total = 0;
foreach ($rows as $row) {
$total = $total + 1;
}
?>
			<strong><?php echo $total; ?></strong>
		</div>
		<div class="texto-contador">centros y<br />empresas</div>
	</div>
	</div>									<h2 class="titulo-sidebar-box">REGÍSTRATE, ES GRATIS</h2>
					<div class="sidebar-box">
						<a href="usuario.php" class="boton-registro boton-registro-profesionales">
	soy <br />profesional <br />sanitario
</a>
<a href="empresa.php" class="boton-registro boton-registro-empresas">
	soy <br />centro o <br />empresa
</a>
					</div>
					<h2 class="titulo-sidebar-box">ACCEDE A TU CUENTA</h2>
					<div class="sidebar-box sidebar-box-bordered">
						 
	<form id="login" action="validar.php" method="post" style="width:90%;margin:10px auto">
		<div class="form-widget-container">
			<label for="input-login">USUARIO</label>
			<input type="email" required="required" id="user" name="user" class="text-input-border" />
		</div>
		<div class="form-widget-container">
			<label for="input-password">CONTRASEÑA</label>
			<input type="password" required="required" id="pass" name="pass" class="text-input-border" />
		</div>
		<div class="form-widget-container">
			<input type="checkbox" id="input-remember-me" name="_remember_me" checked />
			<label id="recuerdame" for="input-remember-me">No cerrar sesión</label>
			<button type="submit" class="btn btn-danger">Acceder</button>
		</div>
		<div class="form-widget-container">			
			<p><strong style="font-size:9px"><a href="/olvide-mi-contrasena">¿Olvidaste tu contraseña?</a></strong></p>
		</div>
	</form>
					</div>
									<!-- CARRUSEL -->

 <section>
                  
                  <div id="slider-container">
                      <div id="slider-box">
                          <div class="slider-element">
                              <article class="element-red">
                              <img class="img-responsive img-thumbnail" src="img/italiano.png">  
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-green">
                               <img class="img-responsive img-thumbnail" src="img/cposgrado.jpg">     
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-blue">
                                <img class="img-responsive img-thumbnail" src="img/cruz.png">  
                              </article>                            
                          </div>
                      </div>
                  </div>
                  
              </section>        


       <!-- CARRUSEL -->

        									</aside>
		
			<div id="content-right">
				<div style="float:left;width:100%">
	</div>				    <h1 class="azul">Informaci&#243n legal</h1>
	A través del presente documento, Postal Marketing SRL informa a usuarios acerca de las Condiciones legales y de uso de la Sede Web www.medijob.com.ar 
    <br>
    <br>
    <h2 class="azul">1. Identificaci&#243n </h2>
    <p>
        Postal Marketing SRL. y su continuadora Express Metropolitana de Servicios SRL ,es una sociedad limitada de nacionalidad argentina con domicilio social sito en  Hipólito Yrihoyen 5047 ( 1650) San Martín , Pcia. De Buenos Aires , Rca. Argentina  presta servicios en Internet y ofrece información corporativa a través de la Sede Web principal localizada en www.Medijob.com, en adelante Medijob, y de la Sede Web secundaria accesible desde el nombre de dominio www.Medijob.net.
Medijob es una marca registrada de Postal marketing  S.RL. y su continuadora  . Amparada  por LEYES. PATENTES Ley de Patentes y Modelos de Utilidad (Ley 24.481). MARCAS Ley de Marcas(Ley 22.362) Ley de Marcas Colectivas (Ley 26.355).

    </p>
    <br>
    <br>
    <h2 class="azul">2. Objeto</h2>
    <p>
        La presente Sede Web ha sido diseñada con el fin de informar al público, sobre los servicios de bolsa de trabajo que www.medijob.com.ar desempeña, sobre la propia empresa y sobre cualquier otro servicio que en un futuro se incluya en la misma. Medijob pretende facilitar la comunicación y encuentro entre empresas que anuncian ofertas de trabajo dentro del mundo laboral medico ,  sanitario y candidatos que anuncian curricula vitae, e informar sobre ofertas, cursos, congresos, simposios y cualquier otra noticia o servicio orientado a mejorar en el mundo profesional. 
Asimismo, a través de la Sede Web, www.medijob.com.ar  podrá habilitar a terceras entidades para que publiciten o presten sus servicios. En estos casos, Medijob no será responsable de establecer las condiciones generales y particulares a tener en cuenta en la utilización, prestación o contratación de estos servicios por terceros y, por tanto, no podrá ser considerado responsable de los mismos. 
Antes de utilizar y/o contratar dichos servicios específicos prestados por Medijob o por terceros a través de Medijob el Usuario deberá leer atentamente las correspondientes condiciones particulares. La utilización y/o la contratación de dichos servicios específicos implica la aceptación de las condiciones particulares que los regulen en la versión publicada en el momento en que se produzca dicha utilización y/o contratación. Los registratntes sean estos oferentes de empleo , de contratación de personal sea o no en relacion de dependencia , de servicios auxiliares y de productos NO MEDICOS  , todos ellos a su entera responsabilidad .


    </p>
    <br>
    <br>
    <h2 class="azul">3. El aviso legal y su aceptaci&#243n</h2>
    <p>
        El presente aviso legal regula el uso general de la Sede Web en Internet "www.medicaljob.com.ar", que Postal Marketing SRL . pone a disposición de los usuarios de Internet. 
La utilización de la Sede Web atribuye la condición de usuario de la misma e implica la aceptación plena y sin reservas de todas y cada una de las disposiciones incluidas en este Aviso Legal en el momento mismo en que el usuario accede a la Sede Web. En consecuencia, el usuario debe leer atentamente el presente Aviso Legal en cada una de las ocasiones en que se proponga utilizar la Sede Web, ya que éste puede sufrir modificaciones. El acceso a esta Sede Web es responsabilidad exclusiva de los usuarios. 
La utilización de ciertos servicios ofrecidos a los usuarios a través de Medijob puede encontrarse sometida a condiciones particulares propias que, según los casos, sustituyan, completen y/o modifiquen el presente Aviso Legal. Por lo tanto, con anterioridad a la utilización de dichos servicios el usuario también ha de leer atentamente las correspondientes condiciones particulares. Asimismo, la utilización de la Sede Web se encuentra sometida igualmente a todos los avisos, reglamentos de uso e instrucciones puestos en conocimiento del usuario por Postal Marketing SRL., que completan lo previsto en este Aviso Legal en cuanto no se oponga a ellas. Medijob se reserva el derecho de modificar unilateralmente las condiciones y términos de uso de su Sede Web.

    </p>
    <br>
    <br>
    <h2 class="azul">4. Condiciones de acceso y uso</h2>
    <p>
        Esta Sede Web es única y exclusivamente para uso personal de los usuarios. El usuario se obliga, con carácter general, a utilizar la Sede Web, así como los servicios vinculados a ella, de conformidad con la ley, el presente aviso legal, las condiciones particulares de ciertos servicios y demás avisos, reglamentos de uso e instrucciones puestos en su conocimiento, así como con la moral y buenas costumbres generalmente aceptadas y el orden público. A tal efecto, el usuario se abstendrá de utilizar cualquiera de los servicios con fines o efectos ilícitos, prohibidos en el presente aviso legal, lesivos de los derechos e intereses de terceros, o que de cualquier forma puedan dañar, inutilizar, sobrecargar, deteriorar o impedir el normal funcionamiento y disfrute por parte del resto de usuarios o que pudiera lesionar o causar daños a los bienes y derechos de Medijob, usuarios o, en general, cualquier tercero. 
El usuario se obliga a no utilizar la Sede Web, ni los servicios o productos vinculados a la misma, para fines ilegales o prohibidos, y a no utilizar identidades falsas, ni suplantar la identidad de otros en la utilización de la Sede Web o de cualquiera de los servicios vinculados a la misma, incluyendo la utilización de contraseñas o claves de acceso de terceros. En particular, el usuario se compromete a aceptar que únicamente utilizará la Sede Web para sí mismo y que los servicios adquiridos a través del mismo serán para uso o consumo propio o de las personas en nombre de las cuales esté legalmente autorizado para actuar. El usuario no revenderá servicios adquiridos a través de esta Sede Web a otras personas o entidades. 
Asimismo, Medijob o empresas que ofrezcan servicios a través de Medijob podrá poner a disposición de los usuarios algunos servicios cuya utilización requiera la cumplimentación de registros adicionales. El citado registro, se efectuará en la forma y condiciones expresamente indicadas en el propio servicio o en las condiciones particulares que lo regulen.

    </p>
    <br>
    <br>
    <h2 class="azul">5. Sobre los contenidos</h2>
    <p>
        Medicaljob realiza los máximos esfuerzos para evitar cualquier error en los contenidos e informaciones que aparecen en su Sede Web. No obstante, no garantiza ni se responsabiliza de las consecuencias que pudieran derivarse de los posibles errores existentes en dichos contenidos o en los proporcionados por terceros.<br> 
Así mismo, Medijob no asume responsabilidad alguna por el contenido de cualquier foro o debate en el ciberespacio (chat), boletines o cualquier tipo de transmisiones, que estén vinculadas a esta Sede Web, y cooperará, si es requerida por orden judicial o por las autoridades pertinentes, en la identificación de las personas responsables de aquellos contenidos que violen la ley. <br>
Medicaljob se reserva la facultad de efectuar cuantos cambios y modificaciones estime convenientes, pudiendo cambiar, suprimir o añadir tanto los contenidos y servicios que presta como la forma en la que éstos aparezcan presentados o localizados, así como restringir el acceso a los mismos, pudiendo hacer uso de tal facultad en cualquier momento y sin previo aviso. 
El usuario se compromete a hacer un uso adecuado de los contenidos y servicios ofrecidos en esta Sede Web y a no emplearlos para incurrir en actividades ilícitas o contrarias a la buena fe y al ordenamiento legal, difundir contenidos o propaganda de carácter racista, xenófobo, pornográfico, ilegal, de apología del terrorismo o atentatorio contra los derechos humanos, provocar daños en los sistemas físicos o lógicos de Medijob, de sus proveedores o de terceras personas, introducir o difundir en la red virus informáticos o cualquiera otros sistemas físicos o lógicos que sean susceptibles de provocar los daños anteriormente mencionados. Medijob perseguirá el incumplimiento de las anteriores condiciones así como cualquier utilización indebida de los contenidos presentados en su Sede Web ejerciendo todas las acciones civiles o penales que les puedan corresponder en derecho.<br>


    </p>
    <br>
    <br>
    <h2 class="azul">6. Duraci&#243n y terminaci&#243n</h2>
    <p>
        La prestación del servicio de contenidos y de los demás servicios ofrecidos en la Sede Web de Medijob tiene, en principio, una duración indefinida. Medijob, no obstante, está autorizada para dar por terminada o suspender dichas prestaciones en cualquier momento, sin perjuicio de lo que se hubiere dispuesto al respecto en las correspondientes condiciones particulares.<br> Cuando ello sea razonablemente posible, Medijob advertirá previamente la terminación o suspensión de la prestación de los servicios. <br>

 
    </p>
    <br>
    <br>
    <h2 class="azul">7. Exclusi&#243n de garant&#237as y de responsabilidad</h2>
    <p>
          Medicaljob no garantiza la disponibilidad y continuidad del funcionamiento de su Sede Web y de los servicios en ella contenidos. Cuando ello sea razonablemente posible, se advertirá previamente de las interrupciones en el funcionamiento de esta Sede Web. Medijob  excluye, con toda la extensión permitida por el ordenamiento jurídico aplicable, cualquier responsabilidad por los daños y perjuicios de toda naturaleza que puedan deberse a la falta de disponibilidad o de continuidad del funcionamiento de la Sede Web o de sus servicios, a la defraudación de la utilidad que los usuarios le hubieren podido atribuir, a la fiabilidad de la Sede Web y los servicios ofrecidos, y en particular, aunque no de modo exclusivo, a los fallos en el acceso a las distintas páginas web de la Sede Web o a aquellas desde las que se prestan los servicios.<br> 
En ningún caso  Medijob será responsable, se haya avisado la posibilidad del mismo o no, por las pérdidas de datos o beneficios, daños especiales, incidentales, directos, indirectos o consecuentes de ningún tipo o perjuicios de cualquier tipo que surjan en relación con el acceso y el uso de la Sede Web o los textos, imágenes e informaciones en ella contenidos, incluyéndose pero no limitándose, a los ocasionados a los sistemas informáticos o los provocados por la introducción de virus tanto en la Sede Web como en las páginas a las que apunten los enlaces externos. En particular, no se hace responsable en modo alguno de las caídas, interrupciones, falta o defecto de las telecomunicaciones que pudieran ocurrir. Los servicios ofertados en esta Sede Web sólo pueden ser utilizados correctamente si se cumplen las especificaciones técnicas para las que han sido diseñados.<br>


    </p>
    <br>
    <br>
    <h2 class="azul">8. Pol&#237tica de privacidad</h2>
    <p>
        El hecho de visitar esta Sede Web supone, por parte del usuario, conocer y aceptar la política de privacidad por la que se rige Medijob y que se encuentra disponible en la sección "Política de privacidad" accesible desde el enlace situado en el pie de página. <br>

El tratamiento de los Datos Personales está ajustado a la normativa  datos personales en la Argentina están protegidos por la Ley 25.326.  . Se entenderá que el usuario acepta las condiciones establecidas si marca la casilla correspondiente a la cláusula anexada a los formularios de aportación de información en la sección “Date de alta” y pulsa el botón "Enviar" que se ubica al final de los mismos. <br>
Toda la información que facilite el usuario a través de los servicios ofrecidos en esta Sede Web deberá ser veraz. A estos efectos el usuario garantiza la autenticidad de todos aquellos datos que comunique como consecuencia de la cumplimentación de formularios necesarios para la suscripción, registro o alta en los servicios ofrecidos a través de la Sede Web. De igual forma, será responsabilidad del usuario mantener toda la información facilitada a Medijob permanentemente actualizada de forma que responda, en cada momento, a la situación real del usuario. 
En todo caso, el usuario será el único responsable de las manifestaciones falsas o inexactas que realice y de los perjuicios que cause a Medijob o a terceros por la información que facilite.<br>



    </p>
    <br>
    <br>
    <h2 class="azul">9. Pol&#237tica de seguridad</h2>
    <p>
    Medicaljob utiliza sistemas de seguridad SSL (Secure Socket Layer) que, a través de sistemas de certificado y cifrado, permiten al usuario comprobar la autenticidad de la Sede Web Medicaljob.com.ar desde donde se recaban sus Datos Personales, así como la integridad y confidencialidad de sus Datos Personales durante la transmisión de los mismos. <br>
    El usuario podrá comprobar la implementación del SSL al proporcionar cualquier Dato Personal dado que la página donde se recaben datos mostrará en la URL el empleo del protocolo "https" (seguro) en lugar del protocolo "http" (no seguro), y le aparecerá un pequeño icono representando un candado cerrado en la parte inferior de su navegador. Ello no obstante, el usuario debe ser consciente de que las medidas de seguridad en Internet no son inexpugnables. <br>
Esta Sede Web ha sido diseñada para soportar los navegadores Crome , Internet Explorer en sus últimas versiones , pero s aplicable a casi todas los navegadores actuales . <br> 
Medijob no se hace responsable de los perjuicios, de cualquier índole, que pudieran ocasionarse a los usuarios por la utilización de otros navegadores o versiones distintas de los navegadores para los que ha sido diseñada su Sede Web.<br>



    </p>
    <br>
    <br>
    <h2 class="azul">10. Enlaces desde y hacia la web</h2>
    <p>
        En la SedeWeb, el Usuario podrá encontrar enlaces a otras páginas web mediante diferentes botones, links, banners, etc., los cuales son gestionados por terceros. Medijob no asume ningún tipo de responsabilidad por cualquier aspecto relativo a la página web a la que se establece un enlace desde la Sede Web. Es responsabilidad del usuario revisar las condiciones generales notas legales y política de privacidad en cada caso cuando sele soliciten los datos personales. 
Medijob autoriza menciones a sus contenidos en otras sedes web, con el tratamiento que éstas consideren, siempre y cuando dichos contenidos no sean reproducidos. 
Los usuarios y, en general, aquellas personas que se propongan establecer un hiperenlace entre su página web y la Sede Web de Medijob deberán cumplir las siguientes condiciones:
•  El hiperenlace únicamente permitirá el acceso a la homepage o página de inicio de la Sede Web de Medijob (www.medijob.com.ar), pero no podrá reproducirlas de ninguna forma.
•  El usuario debe saber que está entrando en la Sede Web de Medijob y debe percibir en su navegador su dirección URL.
•  No se creará un frame ni un border environment sobre las páginas web de Medijob.
•  No se realizarán manifestaciones o indicaciones falsas, inexactas o incorrectas sobre Medijob, sus directivos, sus empleados, las páginas de la Sede Web y los servicios suministrados y, en particular, no se declarará ni dará a entender que Medijob ha autorizado el hiperenlace o que ha supervisado o asumido de cualquier forma los servicios ofrecidos o puestos a disposición de la página web en la que se establece el hiperenlace.
•  La página web en la que se establezca el hiperenlace no contendrá informaciones o contenidos ilícitos, contrarios a la moral y buenas costumbres generalmente aceptadas y al orden público, así como tampoco contendrá contenidos contrarios a cualesquiera derechos de terceros.
Los vínculos que aparecen en esta Sede Web y permiten al usuario acceder a redes de terceros son proporcionados únicamente a modo de conveniencia e información. Medijob no controla y no es responsable por el contenido que aparece en dichos sitios. Bajo ninguna circunstancia Medijob será responsable por cualquier daño sufrido por el usuario en cuanto a estos sitios o al material en ellos contenidos. El hecho de que Medijob ponga estos vínculos a disposición del usuario no significa una aprobación o recomendación de ninguno de estos sitios o del material encontrado allí. 
El usuario es el responsable de revisar y cumplir con los avisos, términos, condiciones y políticas que rigen las sedes web de terceros. Medijob se reserva el derecho de retirar de modo unilateral y en cualquier momento los enlaces que aparecen en su Sede Web. 
Servicios prestados por terceros a través del Sitio Web Medijob no garantiza la licitud, fiabilidad y utilidad de los servicios prestados por terceros a través de esta página o sobre los que Medijob únicamente actúe como medio cauce publicitario o prestador de servicio de intermediación. 
Medijob no será responsable de los daños y perjuicios de toda naturaleza causados por los servicios prestados por terceros a través de esta página, y en particular, a título meramente enunciativo, los causados por:
•  el incumplimiento de la ley, la moral o el orden público
•  la incorporación de virus o cualquier otro código informático, archivo o programa que pueda dañar, interrumpir o impedir el normal funcionamiento de cualquier software, hardware o equipo de telecomunicaciones.
•  la infracción de los derechos de propiedad intelectual e industrial, de los secretos empresariales, de compromisos contractuales de cualquier clase.
•  la realización de actos que constituyan publicidad ilícita, engañosa o desleal y, en general, que constituyan competencia desleal.
•  la falta de veracidad, exactitud, calidad, pertinencia y/o actualidad de los contenidos transmitidos, difundidos, almacenados, recibidos, obtenidos, puestos a disposición o accesibles.
•  la infracción de los derechos al honor, a la intimidad personal y familiar y a la imagen de las personas o, en general, cualquier tipo de derechos de terceros.
•  la inadecuación para cualquier clase de propósito y la defraudación de las expectativas generadas, o los vicios y defectos que pudieran generarse en la relación con terceros.
•  el incumplimiento, retraso en el cumplimiento, cumplimiento defectuoso o terminación por cualquier causa de las obligaciones contraídas por terceros y contratos realizados con terceros

    </p>

    <h2 class="azul">11. Empleo de cookies</h2>
    <p>
    El acceso a la Sede Web de Medicaljob puede implicar la utilización de archivos cookies. Los archivos cookies sirven para identificar una sesión de usuario (cookie de sesión) y/o un ordenador (cookie permanente).<br> Los archivos cookies son pequeñas cantidades de información que almacena el navegador utilizado por cada usuario para que el servidor recuerde cierta información que posteriormente únicamente el servidor que la implementó leerá. <br>
   Los archivos cookies tienen generalmente una duración limitada en el tiempo y no pueden extraer información del disco duro del usuario o robar información personal. La única manera de que la información privada de un usuario forme parte del archivo cookie es que el usuario dé personalmente esa información al servidor.<br> Tampoco pueden leer datos de su disco duro ni archivos cookies creados por otros proveedores. Las cookies de sesión permanecen únicamente mientras el usuario mantiene abierta su sesión, y no se almacenan en su equipo.<br> Gracias a este instrumento, Medijob puede reforzar su seguridad y facilitar una navegación más rápida a través de su Sede Web. Medijob puede utilizar cookies permanentes para mejorar la navegación o con fines estadísticos a fin de ofrecer un mejor servicio. <br>
En todo caso, aquellos usuarios que no deseen recibir cookies o quieran ser informados de su fijación pueden configurar su navegador a tal efecto ya que la Sede Web de Medijob ha sido diseñada para que en su utilización no sea imprescindible que el usuario habilite la recepción de cookies.<br>


    </p>
    <br>
    <br>
    <h2 class="azul">12. Copyright</h2>
    <p>
        Todos los derechos de propiedad industrial e intelectual de los servicios y contenidos albergados en esta Sede Web son propiedad de Postal marketing  S.RL. y sus continuadoras  o de terceros, y se encuentran protegidos por las leyes de Propiedad Intelectual. No podrán ser objeto de explotación, reproducción, distribución, modificación, comunicación pública, cesión o transformación salvo previa y expresa autorización de su legítimo propietario. 
Todos los derechos de propiedad intelectual sobre los códigos HTML, PHP, JavaScript y CSS que sustentan este Sitio Web son propiedad de  Postal marketing  S.RL. y su continuadora  . o de terceros, y se encuentran protegidos por las leyes de Propiedad Intelectual. No podrán ser objeto de explotación, reproducción, distribución, modificación, comunicación pública, cesión o transformación salvo previa y expresa autorización de su legítimo propietario. 
Todas las marcas, nombres comerciales o signos distintivos de cualquier clase que aparecen en la Sede Web son propiedad de  Postal marketing  S.RL. y su continuadora  o de terceros, sin que pueda entenderse que el uso o acceso a la misma a los servicios ofrecidos atribuya al usuario derecho alguno sobre las citadas marcas, nombres comerciales y/o signos distintivos. 
El usuario puede visualizar todos los elementos, imprimirlos, copiarlos y almacenarlos en el disco duro de su ordenador o en cualquier otro soporte físico siempre y cuando sea, única y exclusivamente, para su uso personal y privado, quedando, por tanto, terminantemente prohibida su utilización con fines comerciales, su distribución, así como su modificación, alteración o descompilación. El acceso a esta Sede Web o cualquiera de los servicios en ella ofrecidos, no otorga a los usuarios derecho, ni titularidad alguna sobre los derechos de propiedad intelectual de los contenidos que alberga. Postal marketing  S.RL. y su continuadora  . se reserva la posibilidad de ejercer las acciones civiles o penales, que les puedan corresponder en derecho, contra los usuarios que violen o infrinjan los derechos de propiedad intelectual e industrial. 
Los individuos o entidades que crean que sus derechos de propiedad intelectual hayan sido infringidos, por el uso no autorizado de sus trabajos protegidos que aparezcan en esta Sede Web, pueden ponerse en contacto con Medijob para que el contenido sea retirado o bloquear el acceso público al mismo.



    </p>
    <br>
    <br>
    <h2 class="azul">13. Legislaci&#243n aplicable y jurisdicci&#243n</h2>
    <p>
        Los términos y condiciones que rigen esta Sede Web y todas las relaciones que pudieran derivarse se encuentran salvaguardados por la legislación argentina .<br> En la medida que resulte admisible bajo la normativa en su caso aplicable, Medicaljob y el usuario se someten, con renuncia expresa por ambas partes a cualquier otro fuero, a la exclusiva jurisdicción de los tribunales de la Ciudad Autonoma de Buenos Aires . <br> 
    </p>
    <br>
    <br>
    <h2 class="azul">14. Modificaciones</h2>
    <p>
         Postal marketing  S.RL.  se reserva el derecho de modificar el presente Aviso Legal de acuerdo a su propio criterio, a causa de un cambio legislativo, jurisprudencial o en la práctica empresarial.<br> Si  . Postal marketing  S.RL. introdujera alguna modificación, el nuevo texto será publicado en esta misma Sede Web, donde el usuario podrá tener conocimiento del Aviso Legal vigente en cada momento. En cualquier caso, la relación con los usuarios se regirá por las normas previstas en el momento preciso en que se accede a la Sede Web.<br>
    </p>
    <br>
    <br>
    <h2 class="azul">15. &#218ltima actualizaci&#243n</h2>
    <p>
        El presente aviso legal está actualizado con fecha 30/04/2018.<br> 
. Postal marketing  S.RL.  . © 2018. Todos los derechos reservados.<br>
 

    </p>
			</div>
		</div>
		<footer id="footer">	
	<div id="container-footer-especialidades">
            <div class="footer-box">
            <ul class="footer-box-list">
                
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                
                            </ul>
        </div>
        
        
    </div>
    <div id="footer-aside">
        <div class="footer-box">
            <ul class="footer-box-list">
                
            </ul>
        </div>
        <div class="footer-box">
            <ul class="footer-box-list">
                
            </ul>
        </div>
        <figure id="logo-footer">
            <img class="img-responsive img-thumbnail" src="img/log.jpg" alt="Logo de MedicalJob" title="MedicalJob, tu web de empleo médico" width="90%" />
        </figure>
        <div id="info-footer">
            <b>Copyright &copy; 2018 </b><br />
            <a href="informacion-legal.php">Información legal</a><br />
            <a href="politica-privacidad.php">Política de privacidad</a> |
            <a href="normativa.php">Normativa</a> |
            <a href="contacto.php">Contacto</a>
        </div>  
    </div>
    
	
		
</footer>	</div>
                
        	<script src="js2/router.js"></script>
	<script src="js2/routing?callback=fos.Router.setData"></script>
	<script src="js2/jquery-1.9.1.min.js"></script>
    <script src="js2/jquery-ui-1.10.3.custom.min.js"></script>
	<script src="js2/frontend.js"></script>
	<script src="js2/bootstrap.js"></script>
    <script src="js2/angular.min.js"></script>
    <script src="js2/ng-table.js"></script>
	<script type="text/javascript" src="js2/jquery.fancybox.pack.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$("a[rel='fancybox']").fancybox({
				'transitionIn'	:	'elastic',
				'transitionOut'	:	'elastic',
				'speedIn'		:	600, 
				'speedOut'		:	200, 
				'overlayShow'	:	true,
				'type'			:	'iframe',
				'showNavArrows': 	false
			});
		});
	</script>
        <script type="text/javascript">
			$(document).ready(function(){
				$("#acepta-cookies").on("click", function(){
					var dias = 365*60*60*24*1000;
					var hoy = new Date();
			        var fecha_expira = new Date( hoy.getTime() + (dias) );
			        var cookieString = "cookies_agreement=1" + ";expires=" + fecha_expira.toGMTString();
					window.document.cookie = cookieString
					$("#cookies-bar").css('position','relative')
					$("#cookies-bar").slideDown(1200, function(){
						$(this).remove();
					});
				});

				$("#select-usuario").on("change", function(){
					$("#admin-usuario").val($(this).val());
				});
			});
        </script>
    </body>
</html>