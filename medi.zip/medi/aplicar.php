<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}


if (isset($_GET["puesto"])) {
	$puesto = utf8_decode($_GET["puesto"]);
}

if (isset($_GET["contacto"])) {
	$contacto = utf8_decode($_GET["contacto"]);
}

if (isset($_GET["centro"])) {
	$centro = utf8_decode($_GET["centro"]);
}

$fecha=date("Y/m/d");
$estado = "Aguardando Análisis";
$estado = utf8_decode($estado);

$sql = "INSERT INTO aplicaciones (fecha,contacto, nombre,puesto, centro,estado) VALUES (:fecha,:contacto,:usuario, :puesto,:centro,:estado)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':puesto', $puesto, PDO::PARAM_STR); 
$stmt->bindParam(':centro', $centro, PDO::PARAM_STR); 
$stmt->bindParam(':estado', $estado, PDO::PARAM_STR); 
$stmt->execute();

 
?>

<script>
alert('Tu aplicación a la oferta a sido enviada exitosamaente');

window.location.href='ofertas.php';
</script>

</body>
<html>