<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
session_start();
$nom = "";
$cp1 = "";
$loc1 = "";
$puesto = "";
$contacto = "";
$centro = "";
$leido = "";
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}


if (isset($_GET["puesto"])) {
	$puesto = utf8_decode($_GET["puesto"]);
}

if (isset($_GET["contacto"])) {
	$contacto = utf8_decode($_GET["contacto"]);
}

if (isset($_GET["centro"])) {
	$centro = utf8_decode($_GET["centro"]);
}


$name = array();
$cp = array();
$loc = array();
$sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { 

$name[0] = $row->nombre;
$cp[0] = $row->CodigoPostal;
$loc[0] = $row->localidad;
}

$nom = $name[0];
$cp1 = $cp[0];
$loc1 = $loc[0];



$fecha=date("Y/m/d");
$estado = "Aguardando Análisis";
$estado = utf8_decode($estado);
$leido = 0;

$sql = "INSERT INTO aplicaciones (contacto,fecha, nombre,us,codigop,localidad,puesto, centro,estado,leido) VALUES (:contacto,:fecha,:usuario,:nom,:cp1,:loc1,:puesto,:centro,:estado,:leido)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':nom', $nom, PDO::PARAM_STR);
$stmt->bindParam(':cp1', $cp1, PDO::PARAM_STR);
$stmt->bindParam(':loc1', $loc1, PDO::PARAM_STR);
$stmt->bindParam(':puesto', $puesto, PDO::PARAM_STR); 
$stmt->bindParam(':centro', $centro, PDO::PARAM_STR); 
$stmt->bindParam(':estado', $estado, PDO::PARAM_STR); 
$stmt->bindParam(':leido', $leido, PDO::PARAM_STR); 
$stmt->execute();

 
?>

<script>
alert('Tu aplicación a la oferta a sido enviada exitosamaente');

window.location.href='ofertas.php';
</script>

</body>
<html>