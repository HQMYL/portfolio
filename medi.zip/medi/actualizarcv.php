                                                                                                                                                                                                                                                                                                                                                                                                >
<html>
<head></head>                                                                                       
<body>
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}


$cvtexto = "";
if (isset($_POST["cvtexto"])) {
  $cvtexto = utf8_decode($_POST["cvtexto"]);
}



$sql = "SELECT * FROM cv WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {

$sql2 = " UPDATE cv SET curri =:cvtexto WHERE usuario =:usuario ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':cvtexto', $cvtexto, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();

} 
?>
<script>
alert('El Curriculum a sido actualizado exitosamaente');
window.location.href='curriculum.php';
</script>



</body>
<html>