<!DOCTYPE HTML>
<html>
<?php
include("conexion.php");
?>
<body>
<?php

if (isset($_POST["fecha"])) {
	$fecha = $_POST["fecha"];
}


if (isset($_POST["desc"])) {
	$descrip = $_POST["desc"];
}

if (isset($_POST["emp"])) {
	$dir = $_POST["emp"];
}

if (isset($_POST["ubi"])) {
	$ubi = $_POST["ubi"];
}




if (isset($_POST["tel"])) {
	$tel = $_POST["tel"];
}


if (isset($_POST["sal"])) {
	$sal = $_POST["sal"];
}





$sql = " SELECT * FROM empleos WHERE descripcion = '" .$descrip. "'";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
foreach ($rows as $row) {



if( ( $fecha == $row->fecha)  AND ($emp == $row->empresa) AND ($ubi == $row->ubicacion) AND ($tel == $row->telefono) ) {

$sql2 = " UPDATE empleos SET telefono=:tel salario=:sal WHERE descripcion =:descrip ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':sal', $sal, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);

$stmt2->execute();

}


if( ( $fecha == $row->fecha)  AND ($emp == $row->empresa) AND ($ubi == $row->ubicacion) ) {

$sql2 = " UPDATE empleos SET telefono=:tel, salario=:sal WHERE descripcion =:descrip ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);

$stmt2->bindParam(':sal', $sal, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);

$stmt2->execute();

}


if( ( $fecha == $row->fecha)  AND ($emp == $row->empresa) AND ($tel == $row->telefono) ) {

$sql2 = " UPDATE empleos SET ubicacion=:ubi, salario=:sal WHERE descripcion =:descrip ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':ubi', $ubi, PDO::PARAM_STR);
$stmt2->bindParam(':sal', $sal, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $fecha == $row->fecha)  AND ($emp == $row->empresa) AND ($sal == $row->salario) ) {

$sql2 = " UPDATE empleos SET ubicacion=:ubi, telefono=:tel WHERE descripcion =:descrip ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':ubi', $ubi, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $fecha == $row->fecha) ) {

$sql2 = " UPDATE empleos SET empresa=:emp, ubicacion=:ubi, telefono=:tel, salario=:sal WHERE descripcion =:descrip ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':emp', $emp, PDO::PARAM_STR);
$stmt2->bindParam(':ubi', $ubi, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':sal', $sal, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $emp == $row->empresa) ) {

$sql2 = " UPDATE empleos SET fecha=:fecha, ubicacion=:ubi, telefono=:tel, salario=:sal WHERE descripcion =:descrip ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt2->bindParam(':ubi', $ubi, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':sal', $sal, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $ubi == $row->ubicacion) ) {

$sql2 = " UPDATE empleos SET fecha=:fecha, empresa=:emp, telefono=:tel, salario=:sal WHERE descripcion =:descrip ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt2->bindParam(':emp', $emp, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':sal', $sal, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $tel == $row->telefono) ) {

$sql2 = " UPDATE empleos SET fecha=:fecha, empresa=:emp, ubicacion=:ubi, salario=:sal WHERE descripcion =:descrip ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt2->bindParam(':emp', $emp, PDO::PARAM_STR);
$stmt2->bindParam(':ubi', $ubi, PDO::PARAM_STR);
$stmt2->bindParam(':sal', $sal, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $sal == $row->salario) ) {

$sql2 = " UPDATE empleos SET fecha=:fecha, empresa=:emp, ubicacion=:ubi, telefono=:tel WHERE descripcion =:descrip ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt2->bindParam(':emp', $emp, PDO::PARAM_STR);
$stmt2->bindParam(':ubi', $ubi, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);

$stmt2->execute();

}




if( ( $fecha == $row->fecha)  AND ($emp == $row->empresa) ) {

$sql2 = " UPDATE empleos SET ubicacion =:ubi, telefeno =:tel, salario=:sal WHERE descripcion =:descrip ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':ubi', $ubi, PDO::PARAM_STR); 
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':sal', $sal, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->execute();

}



if( ( $fecha == $row->fecha)  AND ($ubi == $row->ubicacion) ) {

$sql2 = " UPDATE empleos SET empresa =:emp, telefeno =:tel, salario=:sal WHERE descripcion =:descrip ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':emp', $emp, PDO::PARAM_STR); 
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':sal', $sal, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $fecha == $row->fecha)  AND ($tel == $row->telefono) ) {

$sql2 = " UPDATE empleos SET empresa =:emp, ubicacion =:ubi, salario=:sal WHERE descripcion =:descrip ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':emp', $emp, PDO::PARAM_STR); 
$stmt2->bindParam(':ubi', $ubi, PDO::PARAM_STR);
$stmt2->bindParam(':sal', $sal, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $fecha == $row->fecha)  AND ($sal == $row->salario) ) {

$sql2 = " UPDATE empleos SET empresa =:emp, ubicacion =:ubi, telefono=:tel WHERE descripcion =:descrip";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':emp', $emp, PDO::PARAM_STR); 
$stmt2->bindParam(':ubi', $ubi, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $emp == $row->empresa)  AND ($ubi == $row->ubicacion) ) {

$sql2 = " UPDATE empleos SET fecha =:fecha, telefono =:tel, salario=:sal WHERE descripcion =:descrip";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR); 
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':sal', $sal, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $emp == $row->empresa)  AND ($tel == $row->telefono) ) {

$sql2 = " UPDATE empleos SET fecha =:fecha, ubicacion =:ubi, salario=:sal WHERE descripcion =:descrip";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR); 
$stmt2->bindParam(':ubi', $ubi, PDO::PARAM_STR);
$stmt2->bindParam(':sal', $sal, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->execute();

}


if( ( $emp == $row->empresa)  AND ($sal == $row->salario) ) {

$sql2 = " UPDATE empleos SET fecha =:fecha, ubicacion =:ubi, telefono=:tel WHERE descripcion =:descrip";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR); 
$stmt2->bindParam(':ubi', $ubi, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $sal, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $ubi == $row->ubicacion)  AND ($tel == $row->telefono) ) {

$sql2 = " UPDATE empleos SET empresa=:emp, fecha =:fecha, salario =:sal WHERE descripcion =:descrip";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR); 
$stmt2->bindParam(':emp', $emp, PDO::PARAM_STR);
$stmt2->bindParam(':sal', $sal, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $ubi == $row->ubicacion)  AND ($sal == $row->salario) ) {

$sql2 = " UPDATE empleos SET empresa=:emp, fecha =:fecha, telefono =:tel WHERE descripcion =:descrip";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':emp', $emp, PDO::PARAM_STR);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR); 
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $tel == $row->telefono)  AND ($sal == $row->salario) ) {

$sql2 = " UPDATE empleos SET empresa=:emp, fecha =:fecha, ubicacion =:ubi WHERE descripcion =:descrip";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':emp', $emp, PDO::PARAM_STR);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR); 
$stmt2->bindParam(':ubi', $ubi, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->execute();

}



}



?>
<script>
	alert('El empleo a sido actualizado exitosamaente');
window.location.href='users.php';


</script>
</body>
</html>