<!DOCTYPE HTML>
<html>
<?php
include("conexion.php");
?>
<body>
<?php


if (isset($_POST["cmbcolectivo"])) {
$arri = array();
$col = utf8_decode($_POST["cmbcolectivo"]);

$sth = $con->prepare("SELECT * FROM colectivo WHERE id = ?");
$sth->bindParam(1, $col);

$sth->execute();

if ($sth->rowCount() > 0) {

foreach ($sth as $row ) {
$arri[0] = $row["nombre"];

}

$colectiv = $arri[0];
}

}





if (isset($_POST["cmbespec"])) {
	$espec = $_POST["cmbespec"];
}


if (isset($_POST["puesto"])) {
	$puesto = $_POST["puesto"];
}


if (isset($_POST["descrip"])) {
	$descrip = $_POST["descrip"];
}


if (isset($_POST["req"])) {
	$req = $_POST["req"];
}


if (isset($_POST["sal"])) {
	$sal = $_POST["sal"];
}

if (isset($_POST["caduc"])) {
	$caduc = $_POST["caduc"];
}

if (isset($_POST["ncentro"])) {
	$ncentro = $_POST["ncentro"];
}



if (isset($_POST["tipoc"])) {
	$tipoc = $_POST["tipoc"];
}




if (isset($_POST["tel"])) {
	$tel = $_POST["tel"];
}

if (isset($_POST["cmbpais"])) {
	$pais = $_POST["cmbpais"];
}

if (isset($_POST["ciudad"])) {
	$ciudad = $_POST["ciudad"];
}




if (isset($_POST["dirc"])) {
	$dirc = $_POST["dirc"];
}


if (isset($_POST["descripc"])) {
	$descripc = $_POST["descripc"];
}


if (isset($_POST["id"])) {
	$id = $_POST["id"];
}


if (isset($_POST["user"])) {
	$user = $_POST["user"];
}






$sql2 = " UPDATE ofertas SET usuario =:user, colectivo =:colectiv, especialidad=:espec, puesto=:puesto,descripcionPuesto=:descrip, requerimientos=:req,salario=:sal,caducidad=:caduc,nombreCentro=:ncentro,tipoCentro=:tipoc,telefono=:tel,pais=:pais,ciudad=:ciudad,direccioncentro=:dirc, descripcionCentro=:descripc WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':user', $user, PDO::PARAM_STR); 
$stmt2->bindParam(':colectiv', $colectiv, PDO::PARAM_STR); 
$stmt2->bindParam(':espec', $espec, PDO::PARAM_STR);
$stmt2->bindParam(':puesto', $puesto, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->bindParam(':req', $req, PDO::PARAM_STR);
$stmt2->bindParam(':sal', $sal, PDO::PARAM_STR);
$stmt2->bindParam(':caduc', $caduc, PDO::PARAM_STR);
$stmt2->bindParam(':ncentro', $ncentro, PDO::PARAM_STR);
$stmt2->bindParam(':tipoc', $tipoc, PDO::PARAM_STR);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt2->bindParam(':pais', $pais, PDO::PARAM_STR);
$stmt2->bindParam(':ciudad', $ciudad, PDO::PARAM_STR);
$stmt2->bindParam(':dirc', $dirc, PDO::PARAM_STR);
$stmt2->bindParam(':descripc', $descripc, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);
$stmt2->execute();



?>
<script>
	alert('El empleo a sido actualizado exitosamaente');
window.location.href='consultarempleo.php';


</script>
</body>
</html>