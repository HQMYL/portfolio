<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}



if (isset($_POST["empresa"])) {
	$empresa = utf8_decode($_POST["empresa"]);
}


if (isset($_POST["fechaInicio"])) {
	$fechaInicio = utf8_decode($_POST["fechaInicio"]);
}


if (isset($_POST["fechaFin"])) {
	$fechaFin = utf8_decode($_POST["fechaFin"]);
}



if (isset($_POST["unidad"])) {
	$unidad = utf8_decode($_POST["unidad"]);
}

if (isset($_POST["cmbpais2"])) {
	$pais = utf8_decode($_POST["cmbpais2"]);
}

if (isset($_POST["funcion"])) {
	$funcion = utf8_decode($_POST["funcion"]);
}



$sql = "INSERT INTO experiencia (usuario,empresa,fechaInicio,fechaFinal,unidad, pais, funcion) VALUES (:usuario,:empresa,:fechaInicio,:fechaFin,:unidad, :pais,:funcion)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':empresa', $empresa, PDO::PARAM_STR);
$stmt->bindParam(':fechaInicio', $fechaInicio, PDO::PARAM_STR);
$stmt->bindParam(':fechaFin', $fechaFin, PDO::PARAM_STR);
$stmt->bindParam(':unidad', $unidad, PDO::PARAM_STR); 
$stmt->bindParam(':pais', $pais, PDO::PARAM_STR);
$stmt->bindParam(':funcion', $funcion, PDO::PARAM_STR); 
$stmt->execute();
 
?>

<script>
alert('La esperiencia a sido agregada exitosamaente');
window.location.href='curriculum.php';
</script>

</body>
<html>