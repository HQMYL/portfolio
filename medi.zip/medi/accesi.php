<?php
$host="localhost";
  $user="root";
  $pass="";
  $dbname="medijob";
  
  $dbcon = new PDO("mysql:host={$host};dbname={$dbname}",$user,$pass);
  
  if($_POST) 
  {
      $name     = strip_tags($_POST['name']);
      
   $stmt=$dbcon->prepare("SELECT usuario FROM usuarios WHERE usuario=:name");
   $stmt->execute(array(':name'=>$name));
   $count=$stmt->rowCount();
      
   if($count>0)
   {
    echo "<span style='color:brown;'>El usuario ya existe !!!</span>";
   }
   else
   {
    echo "<span style='color:green;'>Disponible</span>";
   }
  }


 ?>
 