<html lang="es">
<?php
session_start();
include("db.php"); 
include("conexion.php");
include("data.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}



//Get user data from database
$result = $db->query("SELECT * FROM perfil WHERE usuario = '$usuario'");
$row = $result->fetch_assoc();

//User profile picture
$userPicture = !empty($row['userPic'])?$row['userPic']:'no-image.png';
$userPictureURL = 'img/'.$userPicture;



?>

    <head>
      
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="	MedicalJob, bolsa de empleo con ofertas de trabajo, congresos y cursos de enfermera, médico y auxiliar en enfermería en el sector de salud
" />
		        <title>Mi Currículum</title>
        <!--[if lt IE 9]>
        	<script src="/bundles/comun/js/html5shiv.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
               <link rel="stylesheet" type="text/css" href="css2/bootstrap.css" />
                
                <link rel="stylesheet" type="text/css" href="css2/css.css" />
        		<link rel="stylesheet" type="text/css" href="css2/reset.css" />
    
	<link rel="stylesheet" type="text/css" href="css2/frontend.css" />
	<link rel="stylesheet" type="text/css" href="css2/forms.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery-ui-1.10.3.custom.min.css" />

	<link rel="stylesheet" type="text/css" href="css2/usuario.css" />
    <link rel="stylesheet" type="text/css" href="css2/jquery.fancybox.css" />
	<link rel="stylesheet" type="text/css" href="css2/extranet.css" />
  <link rel="stylesheet" type="text/css" href="css3/new.css" />
  
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="apple-touch-icon" sizes="114x114" href="" />
        <link rel="apple-touch-icon" sizes="72x72" href="" />
        <link rel="apple-touch-icon" href="" />
        <style type="text/css">

         body {
background-color: #FFA500;
}

            .btn, .btn-danger {
    float: right;
  }

.menu-titulo {
        
        background-image: url("img/flecha.png");
        }

input[name="slider-select-element"] {
      display: none;
  }
  
  #slider-arrows {
      margin: -10% auto 0 auto;
      width: 80%;
  }
  
  #slider-box {
      -moz-animation: autoSlider 15s infinite linear;
      -o-animation: autoSlider 15s infinite linear;
      -webkit-animation: autoSlider 15s infinite linear;
      animation: autoSlider 15s infinite linear;
  
      -webkit-transition: all 0.75s ease;
      -moz-transition: all 0.75s ease;
      -ms-transition: all 0.75s ease;
      -o-transition: all 0.75s ease;
      transition: all 0.75s ease;
  
      height: 100%;
      width: 300%;
  }
  
  #slider-container {
      height: 20%;
      margin: 0 auto;
      overflow: hidden;
      text-align: left;
      width: 100%;
  }
  
  .element-blue,
  .element-green,
  .element-red {
      width: 100%;
      height: 100%;
  }
  
  .element-blue {
      
  }
  
  .element-green {
      
  }
  
  .element-red {
      
  }
  
  .slider-element {
      float: left;
      width: 33.333%;
  }
  
  @-moz-keyframes autoSlider {
      0% {
          margin-left: 0;
      }
  
      30% {
          margin-left: 0;
      }
  
      35% {
          margin-left: -100%;
      }
  
      65% {
          margin-left: -100%;
      }
  
      70% {
          margin-left: -200%;
      }
  
      95% {
          margin-left: -200%;
      }
  
      100% {
          margin-left: 0;
      }
  }
  
  @-webkit-keyframes autoSlider {
      0% {
          margin-left: 0;
      }
  
      30% {
          margin-left: 0;
      }
  
      35% {
          margin-left: -100%;
      }
  
      65% {
          margin-left: -100%;
      }
  
      70% {
          margin-left: -200%;
      }
  
      95% {
          margin-left: -200%;
      }
  
      100% {
          margin-left: 0;
      }
  }
  
  @keyframes autoSlider {
      0% {
          margin-left: 0;
      }
  
      30% {
          margin-left: 0;
      }
  
      35% {
          margin-left: -100%;
      }
  
      65% {
          margin-left: -100%;
      }
  
      70% {
          margin-left: -200%;
      }
  
      95% {
          margin-left: -200%;
      }
  
      100% {
          margin-left: 0;
      }
  }
  

        </style>
        <script type="text/javascript" src="js2/main.js" charset="UTF-8"></script>
       
    </head>
    <body itemscope itemtype="http://schema.org/WebPage">
		<div id="cargando" style="display:none"></div>
		    				        	<div id="pagina">
		<header id="header">
			<div id="banner">
				<img class="img-responsive" src="img/portada.jpg" 
					 alt="MedicalJob: Trabaja en el sector médico en cualquier parte del mundo"
					 title="MedicalJob: Trabaja en el sector médico en cualquier parte del mundo" />
			</div>
					</header>
		<div id="contenido">
			<div id="breadcrumb" itemprop="breadcrumb">
									<a href="seccion-usuarios.php"><span class="glyphicon glyphicon-home"></span> Inicio</a> >
											<a href="seccion-usuarios.php">Mi Cuenta</a> >
					 
				 Mi Currículum			</div>
					
			<aside id="sidebar">
				<div id="cuadro-sesion">
                    <?php
            $total = 0;
            $estado = 0;
        $sth = $con->prepare("SELECT * FROM mensajes WHERE usuario = ? AND estado = ?");
$sth->bindParam(1, $usuario);
$sth->bindParam(2, $estado);
$sth->execute();

if ($sth->rowCount() > 0) {
  foreach ($sth as $row) {
    $total = $total + 1;
  }


}
 ?>
	<p><em>BIENVENIDO</em> <span class="green">
			<?php echo $usuario; ?></span><br />
		<em>Tiene <?php echo $total; ?> mensaje(s) en su <a class="blue" href="mis-mensajes.php">Inbox</a></em>
			</p>
	<p id="cuadro-sesion-saldo">
        <?php
        $sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { ?>
			<em>Saldo actual: <span class="green" id="cuadro-sesion-puntos"><?php echo $row->creditos;?>  créditos</span></em>
            <?php } ?>
		</p>
				<?php
 $stmt = $DB_con->prepare('SELECT * FROM perfil WHERE usuario =:uid');
  $stmt->execute(array(':uid'=>$usuario));
  $stmt->execute();
  
  if($stmt->rowCount() > 0)
  {
    while($row=$stmt->fetch(PDO::FETCH_ASSOC))
    {
      extract($row); 
      ?> 
        <img class="img-responsive img-thumbnail" src="img/<?php echo $row['userPic']; ?>"
       alt="Foto de Pserfil" 
       title="Foto de Perfil" 
       width="70" style="float: left; margin: 5px 20px" />
       <?php }
           }
           ?>
		<a class="button button-blue" href="ofertas.php">OFERTAS</a>
		<a class="button button-grey" href="logout.php">SALIR</a>
</div>				                    <div id="menu-usuario" class="menu-lateral">
	<ul id="menu-box">
		<li class="menu-titulo" data-target="submenu-datos">Mi cuenta</li>
		<li class="submenu" id="submenu-datos">
			<ul>
				<li><a href="mis-datos-acceso.php">Mis Datos de Acceso</a></li>
				<li><a href="datos-personales.php">Mis Datos Personales</a></li>
				<li><a href="curriculum.php">Mi Currículum</a></li>
				<li><a href="recomendar-usuario.php">Recomendar MedicalJob</a></li>
                <li>
                    <?php
        $sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { 
if(($row->pagovisitas == "0") AND ($row->pagocurri == "0")){ ?>
<a href="<?php echo 'acciones-avanzadas.php';?>">Acciones Avanzadas</a>
<?php } ?>

<?php 
if(($row->pagovisitas == "1") AND ($row->pagocurri == "0")){ ?>
<a href="<?php echo 'visitas-curriculum.php';?>">Acciones Avanzadas</a>
<?php } ?>

<?php 
if(($row->pagovisitas == "0") AND ($row->pagocurri == "1")){ ?>
<a href="<?php echo 'compras-curriculum.php';?>">Acciones Avanzadas</a>
<?php } ?>

<?php 
if(($row->pagovisitas == "1") AND ($row->pagocurri == "1")){ ?>
<a href="<?php echo 'acciones.php';?>">Acciones Avanzadas</a>
<?php } ?>

                </li>
                <?php } ?>

				<li><a href="eliminar-cuenta-usuario.php">Darme de baja</a></li>
			</ul>
		</li>
		<li class="menu-titulo" data-target="submenu-ofertas">Ofertas</li>
		<li class="submenu" id="submenu-ofertas">
			<ul>
				<li><a href="ofertas.php">Buscar ofertas</a></li>
				<li><a href="mis-ofertas.php">Ver mis candidaturas</a></li>
			</ul>
		</li>
		<li class="menu-titulo" data-target="submenu-inbox">Inbox</li>
		<li class="submenu" id="submenu-inbox">
			<ul>
				<li><a href="mis-mensajes.php">Ver mis mensajes</a></li>
				<li><a href="ajustes-inbox.php">Cambiar mis ajustes de Inbox</a></li>
			</ul>
		</li>
        <li class="menu-titulo" data-target="submenu-puntos">Créditos</li>
        <li class="submenu" id="submenu-puntos">
            <ul>
                <li><a href="creditos.php">Comprar</a></li>
                <li><a href="historial.php">Histórico de compras</a></li>
            </ul>
        </li>
	</ul>
</div>


<div id="curriculum-vista-previa" class="menu-lateral">
	<a class="btn btn-danger" href="vista-previa.php" class="button button-blue" target="_blank">Vista previa</a>
</div>
	
<div id="progressbar-curriculum">
	<p></p>	<h3></h3><br />
	<div class="progress">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
			<span class="sr-only"></span>
		</div>
	</div>
	<p>
				<a class="btn btn-danger" href="curriculum.php">
			Actualizar Curriculum<br />
			
		</a>
	</p>
</div>	
       <!-- CARRUSEL -->
         <section>
                  
                  <div id="slider-container">
                      <div id="slider-box">
                          <div class="slider-element">
                              <article class="element-red">
                              <img class="img-responsive img-thumbnail" src="img/cposgrado.jpg">  
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-green">
                               <img class="img-responsive img-thumbnail" src="img/italiano.png">     
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-blue">
                                <img class="img-responsive img-thumbnail" src="img/cruz.png">  
                              </article>                            
                          </div>
                      </div>
                  </div>
                  
              </section>        
      <!-- Carousel nav -->
      
		
			</aside>

		
			<div id="content-right">
				<div style="float:left;width:100%">
	</div>									<div id="publi-empresa">
						<a href="wiki-usuarios.php" style="margin-left:0px">
							<img src="img/como-funcionan-los-creditos.jpg" 
							 	 alt="Como funcionan los créditos de MedicalJob"
							 	 title="Como funcionan los créditos de MedicalJob" />
						</a>
												<a href="ofertas.php">
							<img src="img/busca-tu-trabajo.jpg" 
								 alt="Busca tu trabajo en MedicalJob"
								 title="Busca tu trabajo en MedicalJob"
								 style="float:right;margin-right:5px" />
						</a>
					</div>
									
    <div class="mediempleo-box">
        <div class="content">
            <div class="box-header">
                <div class="box-title">
                    <h1>CURRÍCULUM VITAE</h1>
                </div>
            </div>
            <div class="box-content">
              <!-- FOTO DE PERFIL -->
              
              <!-- FOTO DE PERFIL -->

                
                <!-- curriculum en texto -->
                
                <!-- ACTUALIZACION DE CURRICULUM -->
                   <div class="width-100">
                    <legend style="margin-top:27px;float: right; width: 92%;">Curriculum en Texto</legend>
                    <form class="curriculum" method="POST" action="actualizarcv.php">
                        <?php
         $sql = "SELECT * FROM cv  WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
?>
                            <label for="curriculum_hobbies"></label>
                           <?php  foreach ($rows as  $row) { ?>   
                            <textarea id="cvtexto" name="cvtexto">
                                <?php echo utf8_encode($row->curri); ?>
                            </textarea>
                            
                            <div>
                             <button class="btn btn-danger" type="submit">Actualizar</button> 
                            </div>
                            
                          </form><br>
                          <?php } ?>
                    <!-- curriculum en texto -->
                
                  <?php
 $stmt = $DB_con->prepare('SELECT * FROM pdf WHERE usuario =:uid');
  $stmt->execute(array(':uid'=>$usuario));
  $stmt->execute();
  
  if($stmt->rowCount() > 0)
  {
    while($row=$stmt->fetch(PDO::FETCH_ASSOC))
    {
      extract($row); 
      ?> 
 
                        <form class="curriculum" method="POST" action="guardarvc2.php" enctype="multipart/form-data">
                        <fieldset>
                        <div class="width-50">
                          <label for="curriculum_hobbies">Cambia Tu curriculum</label>
                          <input type="file" name="archivo" id="archivo">  
                           <button type="sumbit" class="btn btn-danger">Actualizar</button>
                           
                        </div><br>
                       
                  <?php }
                   }
                   ?>


            </div>
        </div>
    </div>	

			</div>
		</div>
		<footer id="footer">	
	<div id="container-footer-especialidades">
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
        
        
    </div>
    <div id="footer-aside">
        <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                <li><a href=""></a></li>
                <li><a href=""></a></li>
            </ul>
        </div>
        <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                <li>
                    
                </li>
                <li>
                    
                </li>
                <li>
                    
                </li>
                
							</ul>
		</div>
		
		
	</div>
	<div id="footer-aside">
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
				<li></li>
				<li></li>
			</ul>
		</div>
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
				<li>
					
				</li>
				<li>
					
				</li>
				<li>
					<a href="/links-interesantes"></a>
				</li>
			</ul>
		</div>
		<figure id="logo-footer">
			<img class="img-responsive img-thumbnail" src="img/log.jpg" alt="Logo de MedicalJob" title="MedicalJob, tu web de empleo médico" width="90%" />
		</figure>
		<div id="info-footer">
			<b>Copyright &copy; 2018 </b><br />
			<a href="informacion-legal.php">Información legal</a><br />
			<a href="politica-privacidad.php">Política de privacidad</a> |
			<a href="normativa.php">Normativa</a> |
			<a href="contacto.php">Contacto</a>
		</div>	
	</div>
	
		
</footer>	</div>

                
        		<script src="js2/router.js"></script>
	<script src="js2/routing?callback=fos.Router.setData"></script>
	<script src="js2/jquery-1.9.1.min.js"></script>
    <script src="js2/jquery-ui-1.10.3.custom.min.js"></script>
	<script src="js2/frontend.js"></script>
	<script src="js2/bootstrap.js"></script>
			<script src="js2/usuario.js"></script>
	 

    <script src="js2/jquery.fancybox.pack.js"></script>
	<script type="text/javascript" src="js2/usuario.js"></script>
	<script type="text/javascript" src="js2/curriculum.js"></script>


<script type="text/javascript">
$(document).ready(function () {
    //If image edit link is clicked
    $(".editLink").on('click', function(e){
        e.preventDefault();
        $("#fileInput:hidden").trigger('click');
    });
  
    //On select file to upload
    $("#fileInput").on('change', function(){
        var image = $('#fileInput').val();
        var img_ex = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
    
    //validate file type
        if(!img_ex.exec(image)){
            alert('Please upload only .jpg/.jpeg/.png/.gif file.');
            $('#fileInput').val('');
            return false;
        }else{
            $('.uploadProcess').show();
            $('#uploadForm').hide();
            $( "#picUploadForm" ).submit();
        }
    });
});

//After completion of image upload process
function completeUpload(success, fileName) {
  if(success == 1){
    $('#imagePreview').attr("src", "");
    $('#imagePreview').attr("src", fileName);
    $('#fileInput').attr("value", fileName);
    $('.uploadProcess').hide();
  }else{
    $('.uploadProcess').hide();
    alert('There was an error during file upload!');
  }
  return true;
}
</script>    

<script type="text/javascript">

$(document).ready(function() {

  $("#cmbpais2").change(function(){
          
      var id=$("#cmbpais2").val();
      $('#cmbciudad2').load('escoger2.php?id='+id);
});
});  
</script>  



    </body>
</html>
