<!DOCTYPE html>
<html lang="es">
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}


if(isset($_GET['id'])) {
$_SESSION['id']= $_GET['id'];}



if(isset($_GET['nombre'])) {
$_SESSION['nombre']= $_GET['nombre'];}

?>
    <head>
        <meta charset="UTF-8" />
		<meta name="description" content="	MedicalJob, bolsa de empleo con ofertas de trabajo, congresos y cursos de enfermera, médico y auxiliar en enfermería en el sector de salud
" />
		        <title>COMPRA DE CURRICULUM
</title>
        <!--[if lt IE 9]>
        	<script src="/bundles/comun/js/html5shiv.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
		<script src="js3/jquery-3.js"></script>
	 
                <link rel="stylesheet" type="text/css" href="css2/css.css" />
            	<link rel="stylesheet" type="text/css" href="/bundles/comun/css/reset.css" />
    <link rel="stylesheet" type="text/css" href="css2/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css2/frontend.css" />
	<link rel="stylesheet" type="text/css" href="css2/forms.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery-ui-1.10.3.custom.min.css" />

    <link rel="stylesheet" type="text/css" href="css2/empresa.css" />
    <link rel="stylesheet" type="text/css" href="css2/form-facturacion.css" />
    <link rel="stylesheet" type="text/css" href="css2/extranet.css" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="apple-touch-icon" sizes="114x114" href="" />
        <link rel="apple-touch-icon" sizes="72x72" href="" />
        <link rel="apple-touch-icon" href="" />
        <style type="text/css">
        	.btn, .btn-danger {
        		float: right;
        	}
        	.menu-titulo {
        
        background-image: url("img/flecha.png");

        }
 
#user1 {
	padding: 8px;
	font-size: 15px;
	border-radius: 5px;
}

.centro {
	text-align: center;
}

        </style>

 <script>
function paypal(){   
       /// Aqui podemos enviarle alguna variable a nuestro script PHP
    var US= document.getElementById("precio").value;
       /// Invocamos a nuestro script PHP
    $.post("formpaypal.php", { id: US }, function(data){
       /// Ponemos la respuesta de nuestro script en el DIV recargado
    $("#consi").html(data);
    });        
}
</script>

<script>
function recargar2(){   
       /// Aqui podemos enviarle alguna variable a nuestro script PHP
    var US= document.getElementById("precio").value;
       /// Invocamos a nuestro script PHP
    $.post("pagar-cv.php", { id: US }, function(data){
       /// Ponemos la respuesta de nuestro script en el DIV recargado
    $("#consi").html(data);
    });        
}
</script>
    </head>
    <body itemscope itemtype="http://schema.org/WebPage">
		<div id="cargando" style="display:none"></div>
		    				        	<div id="pagina">
		<header id="header">
			<div id="banner">
				<img src="img/log.jpg" 
					 alt="MediecalJob: Trabaja en el sector médico en cualquier parte del mundo"
					 title="MedicalJob: Trabaja en el sector médico en cualquier parte del mundo" />
			</div>
					</header>
		<div id="contenido">
			<div id="breadcrumb" itemprop="breadcrumb">
									<a href="seccion-empresas.php"><span class="glyphicon glyphicon-home"></span> Inicio</a> >
											<a href="seccion-empresas.php">Mi Cuenta</a> >
					 
				 Compra de curriculum		</div>
					
			<aside id="sidebar">
				<div id="cuadro-sesion">
	<p><em>BIENVENIDO</em> <span class="green">
				<?php echo $usuario;?></span><br />
		</p>
	<p id="cuadro-sesion-saldo">
		<?php
        $sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { ?>
			<em>Saldo actual: <span class="green" id="cuadro-sesion-puntos"><?php echo $row->creditos;?> créditos</span></em>
			<?php } ?>
		</p>
			<a class="button button-green" href="/empresas/ofertas/nueva">PUBLICAR</a>
		<a class="button button-blue" href="/empresas/ofertas">OFERTAS</a>
			<a class="button button-grey" href="/logout">SALIR</a>
</div>									<div id="menu-empresa" class="menu-lateral">
    <ul id="menu-box">
    	<li class="menu-titulo" data-target="submenu-ofertas">Ofertas</li>
        <li class="submenu" id="submenu-ofertas">
            <ul>
                <li><a href="listado-ofertas.php">Ver ofertas</a></li>
                <li><a href="nueva-oferta.php">Publicar oferta</a></li>
            </ul>
        </li>
        <li class="menu-titulo" data-target="submenu-curriculums">Currículums</li>
        <li class="submenu" id="submenu-curriculums">
            <ul>
                <li><a href="buscar-usuarios.php">Buscar candidatos</a></li>
                <li><a href="/empresas/notificaciones-pendientes">Pendientes</a></li>
                <li><a href="/empresas/curriculums-adquiridos">Adquiridos</a></li>
            </ul>
        </li>
        <li class="menu-titulo" data-target="submenu-puntos">Créditos</li>
        <li class="submenu" id="submenu-puntos">
            <ul>
                <li><a href="comprar-creditos.html">Comprar</a></li>
                <li><a href="historial.php">Histórico de compras</a></li>
                <li><a href="/empresas/movimientos">Histórico de movimientos</a></li>
            </ul>
        </li>
        <li class="menu-titulo" data-target="submenu-centros">Centros</li>
        <li class="submenu" id="submenu-centros">
            <ul>
                <li><a href="lista-centros.php">Ver centros</a></li>
                <li><a href="nuevo-centro.php">Alta nuevo centro</a></li>
            </ul>
        </li>
        <li class="menu-titulo" data-target="submenu-datos">Mi perfil</li>
        <li class="submenu" id="submenu-datos">
            <ul>
                <li><a href="/empresas/acceso">Datos de acceso</a></li>
                <li><a href="/empresas/editar-datos-facturacion">Datos de facturación</a></li>
                <li><a href="/empresas/recomendar-mediempleo">Recomendar Mediempleo</a></li>
                <li><a href="/empresas/baja-del-servicio">Darse de baja</a></li>
            </ul>
        </li>
    </ul>
</div>
<img class="img-responsive img-thumbnail"  src="img/italiano.png">
						<p class="jk">Cursos de Posgrado en el<br>
						Instituto Universitario</p>
						<img class="img-responsive img-thumbnail"  src="img/cposgrado.jpg">
						<h2>Principios de Inscripciones</h2>
						<img class="img-responsive img-thumbnail"  src="img/cruz.png">

																
			</aside>
		
			<div id="content-right">
				<div style="float:left;width:100%">
	</div>									<div id="publi-empresa">
						<a href="/wiki-empresas" style="margin-left:50px">
							<img src="img/como-funcionan-creditos.jpg" 
							 	 alt="Como funcionan los créditos en Mediempleo"
							 	 title="Como funcionan los créditos en Mediempleo" />
						</a>
						<a href="/centros-empresas/publicar-ofertas">
							<img src="img/ayuda-para-publicar.jpg" 
								 alt="Ayuda para publicar ofertas en Mediempleo"
								 title="Ayuda para publicar ofertas en Mediempleo" />
						</a>
						<a href="/empresas/ofertas/nueva">
							<img src="img/publica-tu-oferta.jpg" 
								 alt="Publica tu oferta en Mediempleo"
								 title="Publica tu oferta en Mediempleo"
								 style="float:right;margin-right:5px" />
						</a>
					</div>
										<div class="mediempleo-box">
			<div class="content">
				<div class="box-header">
					<div class="box-title">
						<h1>Comprar créditos</h1>
					</div>
					<div class="box-subtitle" style="width: 60%"></div>
				</div>
				<div class="box-content compra-puntos">
										<div>
						
					</div>
										
        			<form name="formpaypal" id="formpaypal" method="POST" action="pagar-cv.php">
						<table class="table" id="tabla-compra-puntos" style="margin-top: 15px; float: left;">
		                    <tbody>
		                         <tr>
		                                <th><label for="precio-con-descuento">Total a pagar:</label></th>
		                                <?php
		                                $sql = "SELECT * FROM precios WHERE categoria ='".$_SESSION['id']."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
foreach ($rows as $row) { ?>
<p class="centro">Sin Datos <?php echo $row->Sindatos; ?> Con Datos <?php echo $row->Condatos; ?> Contrato <?php echo $row->Contratar; ?></p>
<?php } ?>
		                                <td><input class="form-control" id="precio"  type="text" name="precio" value="" /></td>
		                            </tr>
	                                	                              	                            </tbody>
	                        </table>
	                        <div class="width-100">
	                        	
		                     </div><br>
						<div class="width-50">
							<div class="">
								<a id="pay" class="btn btn-danger" href="#" onclick="javascript:paypal();">Pagar con Paypal</a>
								
								
								  	
							</div>
						</div><br>
						<div class="width-50">
							<div class="">

							<button class="btn btn-danger" type="submit">Pagar con Tarjeta</button>	
							</div>
						</div>
						<div>
						</div>
						
	
					<div id="consi">
						
					</div>
				</div>
			</div>
		</div>
			</div>
		</div>
		<footer id="footer">	
	<div id="container-footer-especialidades">
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Medicina</li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-alergologia/">Alergología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-analisis-clinicos/">Analisis Clínicos</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-anatomia-patologica/">Anatomia Patológica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-anestesiologia-y-reanimacion/">Anestesiología y Reanimación</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-angiologia-y-cirugia-vascular/">Angiología y Cirugía Vascular</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-aparato-digestivo/">Aparato Digestivo</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-bioquimica-clinica/">Bioquímica Clínica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cardiologia/">Cardiología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-cardiovascular/">Cirugía Cardiovascular</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-general-y-del-aparato-digestivo/">Cirugía General y del Aparato Digestivo</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-maxilofacial/">Cirugía Maxilofacial</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-oral-y-maxilofacial/">Cirugía Oral y Maxilofacial</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-pediatrica/">Cirugía Pediátrica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-plastica-estetica-y-reparadora/">Cirugía Plástica Estética y Reparadora</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-plastica-y-reconstructiva/">Cirugía Plástica y Reconstructiva</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-toracica/">Cirugía Toracica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-dermatologia/">Dermatología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-endocrinologia-y-nutricion/">Endocrinología y Nutricion</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-farmacologia-clinica/">Farmacología Clínica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-geriatria/">Geriatria</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-hematologia-y-hemoterapia/">Hematología y Hemoterapia</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-hidrologia-y-balneoterapia/">Hidrología y Balneoterapia</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-inmunologia/">Inmunología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-de-la-educacion-fisica/">Medicina De La Educación Física</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-del-trabajo/">Medicina del Trabajo</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-educacion-fisica/">Medicina Educación Física</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-familiar-y-comunitaria/">Medicina Familiar y Comunitaria</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-fisica-y-rehabilitacion/">Medicina Física y Rehabilitación</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-intensiva/">Medicina Intensiva</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-interna/">Medicina Interna</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-legal-y-forense/">Medicina Legal y Forense</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-nuclear/">Medicina Nuclear</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-preventiva-y-salud-publica/">Medicina Preventiva y Salud Pública</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-microbiologia-y-parasitologia/">Microbiología y Parasitología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-nefrologia/">Nefrología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-neumologia/">Neumología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-neurocirugia/">NeuroCirugía</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-neurofisiologia-clinica/">Neurofisiología Clínica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-neurologia/">Neurología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-obstetricia-y-ginecologia/">Obstetricia y Ginecología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-oftalmologia/">Oftalmología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-oncologia-medica/">Oncología Médica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-oncologia-radioterapeutica/">Oncología Radioterapéutica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-oncologia-radioterapica/">Oncología Radioterápica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-otorrinolaringologia/">Otorrinolaringología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-pediatria-y-areas-especificas/">Pediatría y Áreas Específicas</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-psiquiatria/">Psiquiatría</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-radiodiagnostico/">Radiodiagnóstico</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-reumatologia/">Reumatología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-traumatologia-y-cirugia-ortopedica/">Traumatología y Cirugía Ortopédica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-urologia/">Urología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina/">Medicina</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Enfermería</li>
									<li></li>
									<li></li>
									<li></li>
									<li></li>
									<li></li>
									<li></li>
									<li></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria/">Enfermería</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Farmacia</li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-analisis-clinicos/">Análisis Clínicos</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-bioquimica-clinica/">Bioquímica Clínica</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-farmacia-hospitalaria/">Farmacia Hospitalaria</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-microbiologia-y-parasitologia-clinicas/">Microbiología y Parasitología Clínicas</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-radiofarmacia-hospitalaria/">Radiofarmacia Hospitalaria</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-farmacia-industrial-y-galenica/">Farmacia Industrial y Galénica</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-inmunologia/">Inmunología</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-farmacia/">Farmacia</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Técnico auxiliar de farmacia</li>
									<li>> <a href="/ofertas-trabajo/tecnico-auxiliar-de-farmacia/farmacia-auxiliar-de-farmacia/">Auxiliar de farmacia</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Auxiliar de enfermería</li>
									<li>> <a href="/ofertas-trabajo/auxiliar-de-enfermera/enfermeria-auxiliar-de-enfermeria/">Auxiliar de enfermería</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Otras Ofertas</li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-indeed/">Seleccion Indeed</a></li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-infojobs-medicina-general/">Selección Infojobs Medicina General</a></li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-infojobs-medicina-especializada/">Selección Infojobs Medicina Especialista</a></li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-infojobs-enfermeria/">Selección Infojobs Enfermería</a></li>
							</ul>
		</div>
		
		
	</div>
	<div id="footer-aside">
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Empleo Público</li>
				<li><a href="/publicaciones/1">Publicaciones</a></li>
				<li><a href="/oposiciones/1">Oposiciones</a></li>
			</ul>
		</div>
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Networking</li>
				<li>
					<a target="_blank" title="Perfil de Mediempleo en Linkedin" href="http://www.linkedin.com/company/mediempleo/">Linkedin</a>
				</li>
				<li>
					<a target="_blank" title="Twitter de Mediempleo" href="https://twitter.com/MediEmpleoTweet">Twitter</a>
				</li>
				<li>
					<a href="/links-interesantes">Links interesantes</a>
				</li>
			</ul>
		</div>
		<figure id="logo-footer">
			<img class="img-responsive img-thumbnail" src="img/log.jpg" alt="Logo de MedicalJob" title="MedicalJob, tu web de empleo médico" width="90%" />
		</figure>
		<div id="info-footer">
			<b>Copyright &copy; 2018 </b><br />
			<a href="/informacion-legal">Información legal</a><br />
			<a href="/politica-privacidad">Política de privacidad</a> |
			<a href="/normativa">Normativa</a> |
			<a href="/contacto">Contacto</a>
		</div>	
	</div>
	
		
</footer>	</div>
                <script type="text/javascript">
	  		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
				(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
				m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
			ga('create', 'UA-40029850-1', 'mediempleo.com');
			ga('send', 'pageview');
		</script>
            	<script src="js2/router.js"></script>
	<script src="js2/routing?callback=fos.Router.setData"></script>
	<script src="js2/jquery-1.9.1.min.js"></script>
    <script src="js2/jquery-ui-1.10.3.custom.min.js"></script>
	<script src="js2/frontend.js"></script>
	<script src="js2/bootstrap.js"></script>
			<script src="js2/empresa.js"></script>
	 

    <script src="js2/empresa.js" type="text/javascript"></script>
    



	<script type="text/javascript">

		function pagarTpvLaCaixa(){
			if($("#quantity-points").val() > 0){
				$("#Ds_Merchant_Amount").val($("#precio-con-descuento").val()*100);
				$("#tpv-puntos").val($("#quantity-points").val());
				
				var form = document.getElementById('form-tpv');
				form.submit();
			} else {
				alert("La cantidad de créditos debe ser mayor que 0");
			}
		}
	
    	var descuentos = [{"id":56,"valor":90,"porcentaje":"23.3333","texto":"90 cr\u00e9ditos","textoDescuento":"23.3333 %"},{"id":57,"valor":150,"porcentaje":"34.0000","texto":"150 cr\u00e9ditos","textoDescuento":"34 %"},{"id":58,"valor":300000,"porcentaje":"99.9000","texto":"Tarifa Plana","textoDescuento":"300\u20ac (Valor Total)"}];
		var idEmpresa = 1863;
		
		var onBlurQuantity = function(){
			var cantidad = parseInt($(this).val()) || 0;
			$(this).val(cantidad);
			
			var desc = 0;
			
			for(var i=0; i<descuentos.length; i++){
				if(descuentos[i].valor == cantidad){
					desc = descuentos[i].porcentaje;
				}
			}

			var total = cantidad * (1 - desc / 100);

			$("#descuento").val(desc);
			$("#precio-con-descuento").val(total);

			var puntosIniciales = parseInt($("#puntos-iniciales").html());
			$("#puntos-finales").html(cantidad + puntosIniciales);

			$("#concepto").val("COMPRA DE " + cantidad + " CREDITOS - " + total + " euros ## " + idEmpresa);
		}
	
		$(document).ready(function(){
		    $("#quantity-points").on("blur", onBlurQuantity);

            var c = this.checked;
            if(c){
                $('#creditos').hide();
                $('#quantity-points').val('300000');
                $('#quantity-points').blur();
            }else{
                $('#creditos').show();
                $('#quantity-points').val('0');
                $('#quantity-points').blur();
            }

            $('#checboxtarifa').change(function(){
                var c = this.checked;
                if(c){
					$('#creditos').hide();
					$('#quantity-points').val('300000');
                    $('#quantity-points').blur();
				}else{
                    $('#creditos').show();
                    $('#quantity-points').val('0');
                    $('#quantity-points').blur();
				}

            });
		});
	</script>

	<script>
function recargar1(){   
       /// Aqui podemos enviarle alguna variable a nuestro script PHP
    var US= document.getElementById("precio").value;
    
       /// Invocamos a nuestro script PHP
    $.post("pagar-cv.php", { usuario: US }); 
       /// Ponemos la respuesta de nuestro script en el DIV recargado
    
        
}
</script>
        
    </body>
</html>
