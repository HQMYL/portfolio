<?php
session_start();
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
include("conexion.php");

$pa = "";
if (isset($_POST["id"])) {
	$pa = $_POST["id"];
}



 $sql = "SELECT * FROM ofertas WHERE colectivo ='".$pa."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

echo '<table class="table table-bordered table-hover">';
echo '<thead>';
echo '<tr>';

echo '<th>Colectivo</th>';
echo '<th>Puesto</th>';
echo '<th>Descripcion</th>';
echo '<th>Salario</th>';
echo '<th>País</th>';
echo '</tr>';
echo '</thead>';
foreach ($rows as $row) {



echo '<tbody>';
echo '<tr>';
 echo '<td>' .  utf8_encode($row->colectivo) . '</td>';
 echo '<td>' .  utf8_encode($row->puesto) . '</td>';
 echo '<td>' .  utf8_encode($row->descripcionPuesto) . '</td>';
 echo '<td>' .  $row->salario . '</td>';
 echo '<td>' .  utf8_encode($row->pais) . '</td>';
 echo '<td><a class=" btn btn-danger" href="descripcion.php?id='. $row->id.'">Actualizar</a> </td>';
 echo '<td><a class=" btn btn-danger" href="eliminarempl.php?id='. $row->id.'">Eliminar</a></td>';
 
 echo '</tr>';
 echo '</tbody>';


}

 ?>