<!doctype html>
<html>

<body>
<?php 
include("conexion.php");
if (isset($_GET['id'])) {
	$user = $_GET['id'];
}

$sql = "DELETE FROM ofertas WHERE id=:user";
$stmt = $con->prepare($sql);
$stmt->bindParam(':user', $user, PDO::PARAM_STR); 
$stmt->execute();

?>
<script>
alert('El Empleo a sido Eliminado exitosamente');
window.location.href='eliminarempleo.php';
</script>
</body>
</html>
