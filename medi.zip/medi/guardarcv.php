                                                                                                                                                                                                                                                                                                                                                                                                >
<html>
<head></head>                                                                                       
<body>
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}


$cvtexto = "";
if (isset($_POST["cvtexto"])) {
	$cvtexto = utf8_decode($_POST["cvtexto"]);
}



$sql = "INSERT INTO cv (usuario,curri) VALUES (:usuario,:cvtexto)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':cvtexto', $cvtexto, PDO::PARAM_STR);
$stmt->execute();

 
?>
<script>
alert('El Curriculum a sido agregado exitosamaente');
window.location.href='curriculum.php';
</script>



</body>
<html>