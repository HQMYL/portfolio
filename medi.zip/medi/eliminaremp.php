<!doctype html>
<html>

<body>
<?php 
include("conexion.php");
if (isset($_GET['id'])) {
	$user = $_GET['id'];
}

$sql = "DELETE FROM empresas WHERE id=:user";
$stmt = $con->prepare($sql);
$stmt->bindParam(':user', $user, PDO::PARAM_STR); 
$stmt->execute();

?>
<script>
alert('La empresa a sido Eliminada exitosamaente');
window.location.href='eliminarempresa.php';
</script>
</body>
</html>
