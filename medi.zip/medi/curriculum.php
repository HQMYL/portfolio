<html lang="es">
<?php
session_start();
include("db.php"); 
include("conexion.php");
include("data.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}



//Get user data from database
$result = $db->query("SELECT * FROM perfil WHERE usuario = '$usuario'");
$row = $result->fetch_assoc();

//User profile picture
$userPicture = !empty($row['userPic'])?$row['userPic']:'no-image.png';
$userPictureURL = 'img/'.$userPicture;



?>

    <head>
      
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="	MedicalJob, bolsa de empleo con ofertas de trabajo, congresos y cursos de enfermera, médico y auxiliar en enfermería en el sector de salud
" />
		        <title>Mi Currículum</title>
        <!--[if lt IE 9]>
        	<script src="/bundles/comun/js/html5shiv.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
               <link rel="stylesheet" type="text/css" href="css2/bootstrap.css" />
                
                <link rel="stylesheet" type="text/css" href="css2/css.css" />
        		<link rel="stylesheet" type="text/css" href="css2/reset.css" />
    
	<link rel="stylesheet" type="text/css" href="css2/frontend.css" />
	<link rel="stylesheet" type="text/css" href="css2/forms.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery-ui-1.10.3.custom.min.css" />

	<link rel="stylesheet" type="text/css" href="css2/usuario.css" />
    <link rel="stylesheet" type="text/css" href="css2/jquery.fancybox.css" />
	<link rel="stylesheet" type="text/css" href="css2/extranet.css" />
  <link rel="stylesheet" type="text/css" href="css3/new.css" />
  
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="apple-touch-icon" sizes="114x114" href="" />
        <link rel="apple-touch-icon" sizes="72x72" href="" />
        <link rel="apple-touch-icon" href="" />
        <style type="text/css">

         body {
background-color: #FFA500;
}

            .btn, .btn-danger {
    float: right;
  }

.menu-titulo {
        
        background-image: url("img/flecha.png");
        }

input[name="slider-select-element"] {
      display: none;
  }
  
  #slider-arrows {
      margin: -10% auto 0 auto;
      width: 80%;
  }
  
  #slider-box {
      -moz-animation: autoSlider 15s infinite linear;
      -o-animation: autoSlider 15s infinite linear;
      -webkit-animation: autoSlider 15s infinite linear;
      animation: autoSlider 15s infinite linear;
  
      -webkit-transition: all 0.75s ease;
      -moz-transition: all 0.75s ease;
      -ms-transition: all 0.75s ease;
      -o-transition: all 0.75s ease;
      transition: all 0.75s ease;
  
      height: 100%;
      width: 300%;
  }
  
  #slider-container {
      height: 20%;
      margin: 0 auto;
      overflow: hidden;
      text-align: left;
      width: 100%;
  }
  
  .element-blue,
  .element-green,
  .element-red {
      width: 100%;
      height: 100%;
  }
  
  .element-blue {
      
  }
  
  .element-green {
      
  }
  
  .element-red {
      
  }
  
  .slider-element {
      float: left;
      width: 33.333%;
  }
  
  @-moz-keyframes autoSlider {
      0% {
          margin-left: 0;
      }
  
      30% {
          margin-left: 0;
      }
  
      35% {
          margin-left: -100%;
      }
  
      65% {
          margin-left: -100%;
      }
  
      70% {
          margin-left: -200%;
      }
  
      95% {
          margin-left: -200%;
      }
  
      100% {
          margin-left: 0;
      }
  }
  
  @-webkit-keyframes autoSlider {
      0% {
          margin-left: 0;
      }
  
      30% {
          margin-left: 0;
      }
  
      35% {
          margin-left: -100%;
      }
  
      65% {
          margin-left: -100%;
      }
  
      70% {
          margin-left: -200%;
      }
  
      95% {
          margin-left: -200%;
      }
  
      100% {
          margin-left: 0;
      }
  }
  
  @keyframes autoSlider {
      0% {
          margin-left: 0;
      }
  
      30% {
          margin-left: 0;
      }
  
      35% {
          margin-left: -100%;
      }
  
      65% {
          margin-left: -100%;
      }
  
      70% {
          margin-left: -200%;
      }
  
      95% {
          margin-left: -200%;
      }
  
      100% {
          margin-left: 0;
      }
  }
  

        </style>
        <script type="text/javascript" src="js2/main.js" charset="UTF-8"></script>
       
    </head>
    <body itemscope itemtype="http://schema.org/WebPage">
		<div id="cargando" style="display:none"></div>
		    				        	<div id="pagina">
		<header id="header">
			<div id="banner">
				<img class="img-responsive" src="img/portada.jpg" 
					 alt="MedicalJob: Trabaja en el sector médico en cualquier parte del mundo"
					 title="MedicalJob: Trabaja en el sector médico en cualquier parte del mundo" />
			</div>
					</header>
		<div id="contenido">
			<div id="breadcrumb" itemprop="breadcrumb">
									<a href="seccion-usuarios.php"><span class="glyphicon glyphicon-home"></span> Inicio</a> >
											<a href="seccion-usuarios.php">Mi Cuenta</a> >
					 
				 Mi Currículum			</div>
					
			<aside id="sidebar">
				<div id="cuadro-sesion">
                    <?php
            $total = 0;
            $estado = 0;
        $sth = $con->prepare("SELECT * FROM mensajes WHERE usuario = ? AND estado = ?");
$sth->bindParam(1, $usuario);
$sth->bindParam(2, $estado);
$sth->execute();

if ($sth->rowCount() > 0) {
$total = $total + 1;

}
 ?>
	<p><em>BIENVENIDO</em> <span class="green">
			<?php echo $usuario; ?></span><br />
		<em>Tiene <?php echo $total; ?> mensaje(s) en su <a class="blue" href="mis-mensajes.php">Inbox</a></em>
			</p>
	<p id="cuadro-sesion-saldo">
        <?php
        $sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { ?>
			<em>Saldo actual: <span class="green" id="cuadro-sesion-puntos"><?php echo $row->creditos;?>  créditos</span></em>
            <?php } ?>
		</p>
				<?php
 $stmt = $DB_con->prepare('SELECT * FROM perfil WHERE usuario =:uid');
  $stmt->execute(array(':uid'=>$usuario));
  $stmt->execute();
  
  if($stmt->rowCount() > 0)
  {
    while($row=$stmt->fetch(PDO::FETCH_ASSOC))
    {
      extract($row); 
      ?> 
        <img class="img-responsive img-thumbnail" src="img/<?php echo $row['userPic']; ?>"
       alt="Foto de Pserfil" 
       title="Foto de Perfil" 
       width="70" style="float: left; margin: 5px 20px" />
       <?php }
           }
           ?>
		<a class="button button-blue" href="ofertas.php">OFERTAS</a>
		<a class="button button-grey" href="logout.php">SALIR</a>
</div>				                    <div id="menu-usuario" class="menu-lateral">
	<ul id="menu-box">
		<li class="menu-titulo" data-target="submenu-datos">Mi cuenta</li>
		<li class="submenu" id="submenu-datos">
			<ul>
				<li><a href="mis-datos-acceso.php">Mis Datos de Acceso</a></li>
				<li><a href="datos-personales.php">Mis Datos Personales</a></li>
				<li><a href="curriculum.php">Mi Currículum</a></li>
				<li><a href="recomendar-usuario.php">Recomendar MedicalJob</a></li>
                <li>
                    <?php
        $sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { 
if(($row->pagovisitas == "0") AND ($row->pagocurri == "0")){ ?>
<a href="<?php echo 'acciones-avanzadas.php';?>">Acciones Avanzadas</a>
<?php } ?>

<?php 
if(($row->pagovisitas == "1") AND ($row->pagocurri == "0")){ ?>
<a href="<?php echo 'visitas-curriculum.php';?>">Acciones Avanzadas</a>
<?php } ?>

<?php 
if(($row->pagovisitas == "0") AND ($row->pagocurri == "1")){ ?>
<a href="<?php echo 'compras-curriculum.php';?>">Acciones Avanzadas</a>
<?php } ?>

<?php 
if(($row->pagovisitas == "1") AND ($row->pagocurri == "1")){ ?>
<a href="<?php echo 'acciones.php';?>">Acciones Avanzadas</a>
<?php } ?>

                </li>
                <?php } ?>

				<li><a href="eliminar-cuenta-usuario.php">Darme de baja</a></li>
			</ul>
		</li>
		<li class="menu-titulo" data-target="submenu-ofertas">Ofertas</li>
		<li class="submenu" id="submenu-ofertas">
			<ul>
				<li><a href="ofertas.php">Buscar ofertas</a></li>
				<li><a href="mis-ofertas.php">Ver mis candidaturas</a></li>
			</ul>
		</li>
		<li class="menu-titulo" data-target="submenu-inbox">Inbox</li>
		<li class="submenu" id="submenu-inbox">
			<ul>
				<li><a href="mis-mensajes.php">Ver mis mensajes</a></li>
				<li><a href="ajustes-inbox.php">Cambiar mis ajustes de Inbox</a></li>
			</ul>
		</li>
        <li class="menu-titulo" data-target="submenu-puntos">Créditos</li>
        <li class="submenu" id="submenu-puntos">
            <ul>
                <li><a href="creditos.php">Comprar</a></li>
                <li><a href="historial.php">Histórico de compras</a></li>
            </ul>
        </li>
	</ul>
</div>


<div id="curriculum-vista-previa" class="menu-lateral">
	<a class="btn btn-danger" href="vista-previa.php" class="button button-blue" target="_blank">Vista previa</a>
</div>
	
<div id="progressbar-curriculum">
	<p></p>	<h3></h3><br />
	<div class="progress">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
			<span class="sr-only"></span>
		</div>
	</div>
	<p>
		Quieres mejorar tu currículum?<br />
		<a href="mi-curriculum">
			Haz click aquí<br />
			<img 
				src="img/edit_curriculum.png" 
				alt="Modificar mi curriculum" 
				title="Modificar mi curriculum" 
				width="32" 
				height="32"
			/>
		</a>
	</p>
</div>	
       <!-- CARRUSEL -->
         <section>
                  
                  <div id="slider-container">
                      <div id="slider-box">
                          <div class="slider-element">
                              <article class="element-red">
                              <img class="img-responsive img-thumbnail" src="img/cposgrado.jpg">  
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-green">
                               <img class="img-responsive img-thumbnail" src="img/italiano.png">     
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-blue">
                                <img class="img-responsive img-thumbnail" src="img/cruz.png">  
                              </article>                            
                          </div>
                      </div>
                  </div>
                  
              </section>        
      <!-- Carousel nav -->
      
		
			</aside>

		
			<div id="content-right">
				<div style="float:left;width:100%">
	</div>									<div id="publi-empresa">
						<a href="wiki-usuarios.php" style="margin-left:0px">
							<img src="img/como-funcionan-los-creditos.jpg" 
							 	 alt="Como funcionan los créditos de MedicalJob"
							 	 title="Como funcionan los créditos de MedicalJob" />
						</a>
												<a href="ofertas.php">
							<img src="img/busca-tu-trabajo.jpg" 
								 alt="Busca tu trabajo en MedicalJob"
								 title="Busca tu trabajo en MedicalJob"
								 style="float:right;margin-right:5px" />
						</a>
					</div>
									
    <div class="mediempleo-box">
        <div class="content">
            <div class="box-header">
                <div class="box-title">
                    <h1>CURRÍCULUM VITAE</h1>
                </div>
            </div>
            <div class="box-content">
              <!-- FOTO DE PERFIL -->
              <fieldset style="margin-left:10px">
                    <legend style="margin-top:27px;float: right; width: 92%;">Foto de Perfil</legend>
                    <img src="" style="float:left;margin-top:35px"/>
                    
                         <div class="width-75">
                            <div id="imagen-curriculum">                  
<?php
 $stmt = $DB_con->prepare('SELECT * FROM perfil WHERE usuario =:uid');
  $stmt->execute(array(':uid'=>$usuario));
  $stmt->execute();
  
  if($stmt->rowCount() > 0)
  {
    while($row=$stmt->fetch(PDO::FETCH_ASSOC))
    {
      extract($row); 
      ?> 
 
   
<img class="img-responsive img-thumbnail" id="avatar" src="img/<?php echo $row['userPic']; ?>" width="80"  height="80" /><br />
     
             </div>
             <?php }
           }
           ?>
                            <div class="width-75" style="margin-left:20px">
                                <p style="width:100%">
                                    Puedes cambiar de foto las veces que quieras, recuerda que es importante tener tu currículum actualizado y con todos los campos
                                    posibles cumplimentados.
                                </p>
                                
                     <small style="float:left;margin-top:8px;margin-left:13px">(*) el tamaño máximo de la foto son 5MB</small>
                                
                            </div>
                        </div>
                        
             <!-- FORMULARIO -->
             <form method="post" enctype="multipart/form-data" class="form-horizontal" action="actualizarperfil.php">
     
 <table class="table table-bordered table-responsive">
 
    <tr>
     <td><label class="control-label">Imagen de Perfil</label></td>
        <input type="hidden" name="MAX_FILE_SIZE" value="2000000">     
        <td><input class="input-group" type="file" id="user_image" name="user_image"  /></td>
        
        <input type="hidden" name="usuario" id="usuario" value="<?php echo $usuario; ?>">
        <?php
 $sql = "SELECT * FROM perfil WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
  foreach ($rows as $row) { ?>
  <input type="hidden" name="id" id="id" value="<?php echo $row->id; ?>">
  <?php } ?>
        
    </tr>
    
    <tr>
        <td colspan="2"><button type="submit" id="btnsave" name="btnsave" class="btn btn-danger">
        <span class="glyphicon glyphicon-save"></span> &nbsp;Actualizar
        </button>
        </td>
    </tr>
    
    </table>
    
</form>
       
                     
            <!-- FORMULARIO -->        
                </fieldset><br>

              <!-- FOTO DE PERFIL -->

                <fieldset>
                    <legend>Datos personales</legend>
                    <div class="form-errors"></div>
                    
                    <form class="curriculum" action="guardarcurri.php" enctype="multipart/form-data" method="post"> 
                        
                        <div class="width-100">
							<div class="alert alert-warning" style="text-align:center;margin-bottom:0;margin-top:10px;width:93%;">
								<b>RECUERDA:</b> No está permitido por los términos y condiciones de MedicalJob publicar números de teléfono.<br />
								<b>Medicaljob</b> se reserva el derecho de <u>inhabilitar cualquier perfil que no respete esta condición.</u>
							</div>
						</div>
                        <div class="width-100">
                            <label for="presentacion">Presentación</label>
                            <textarea id="pres" name="pres"></textarea>
                        </div>
                        <div class="width-100">
                            <div class="width-50 titulacion">
                                <label for="curriculum_titulacion">Titulación</label>
                                <input type="text" id="titulacion" name="titulacion"    style="-webkit-logical-height: 24px" />
                            </div>
                            <div class="width-50 universidad">
                                <label for="curriculum_universidad">Especialidad</label><br>
                                <select  id="cmbespec" name="cmbespec" class="">
            <option value="">Seleccione la Especialidad</option>

         <?php 
      
         
         $sql = "SELECT * FROM especialidad";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. utf8_encode($row->especialidad) .'">'.utf8_encode ($row->especialidad).'</option>';

        
    }

    ?>
</select>
                            </div>
                        </div>
                        
                        <div class="width-100">
                            <div class="width-50 titulacion">
                                <label for="curriculum_titulacion">Estado</label>
                                <input type="text" id="estado" name="estado"    style="-webkit-logical-height: 24px" />
                            </div>
                            <div class="width-50 universidad">
                              <label for="curriculum_titulacion">Universidad</label>
                                <input type="text" id="univer" name="univer"    style="-webkit-logical-height: 24px" />  
                            </div>
                        </div>




                        <div class="width-75">
                            ¿Estudios finalizados?
                            <input type="checkbox" checked="checked" name="terminado" id="terminado" />
                        </div>
                        <div class="width-100">
                            
                            <div id="anyo-finalizacion" class="width-33">
                                <label for="curriculum_anyo">Año finalización</label>
                                <input type="text" id="anyo" name="anyo"    style="-webkit-logical-height: 24px" />
                            </div>
                            <div class="width-10 colegiado">
                                <label for="curriculum_colegiado" class="required">Colegiado?</label>
                                <select id="colegiado" name="colegiado"><option value="Sí">Sí</option><option value="No">No</option></select>
                            </div>
                            <div class="width-33 curriculum_numColegiado " >                            
                                
                            </div>
                        </div>

                        <div class="width-100">
                            
                            <div id="anyo-finalizacion" class="width-50 titulacion">
                                <label for="curriculum_anyo">Matrícula Nacional</label>
                                <input type="text" id="nacional" name="nacional"    style="-webkit-logical-height: 24px" />
                            </div>
                            <div class="width-50 titulacion">
                                <label for="curriculum_colegiado" class="required">Matrícula Estatal</label>
                                <input type="text" name="estatal" id="estatal">
                            </div>
                            
                        </div>

                        <div class="width-100">
                            <label for="curriculum_hobbies">Hobbies</label>
                            <textarea id="hobbies" name="hobbies"></textarea>
                        </div>

                        <div>
                            
                            <button type="submit" class="btn btn-danger">Actualizar Curriculum</button>
                        </div>
                    </form>
                    
                </fieldset>
                <!-- curriculum en texto -->
                <fieldset>
                 <legend style="margin-top:27px;float: right; width: 92%;">Curriculum en Texto</legend>
                   <form class="curriculum" method="POST" action="guardarcv.php" enctype="multipart/form-data">
                    <input type="hidden" name="MAX_FILE_SIZE" value="200000">
                                               
                           <div class="width-100">
                        
                            <label for="curriculum_hobbies">Curriculum</label>
                            
                            <textarea id="cvtexto" name="cvtexto">
                                
                            </textarea>
                          
                        </div>
                        
                        <div class="width-50">
                          <label for="curriculum_hobbies">También puedes adjuntar tu cv en formato pdf o doc</label>
                          <input type="file" name="archivo" id="archivo">  
                        </div><br>
                        <div>
                            <button type="sumbit" class="btn btn-danger">Añadir</button>

                        </div>
                        
                   </form> 
                   <div class="width-100">
                    <legend style="margin-top:27px;float: right; width: 92%;">Actualización de Curriculum</legend>
                    <form class="curriculum" method="POST" action="actualizarcv.php" enctype="multipart/form-data">
                        <?php
         $sql = "SELECT * FROM cv  WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
?>
                            <label for="curriculum_hobbies"></label>
                           <?php  foreach ($rows as  $row) { ?>   
                            <textarea id="cvtexto" name="cvtexto">
                                <?php echo $row->curri; ?>
                            </textarea>
                            
                            <div>
                              
                              <button class="btn btn-danger" type="submit" id="btnsave" name="btnsave">Actualizar</button>
                            </div>
                            
                          </form><br>
                          <label for="curriculum_hobbies">Curriculum en pdf o doc</label>
                          <form class="curriculum" method="POST" action="actualizarcv2.php" enctype="multipart/form-data">
                           <div class="width-50">
                                <label for="curriculum_hobbies">Cambia tu curriculum</label>
                                <input type="hidden" name="MAX_FILE_SIZE" value="80000000">
                            <input type="file" name="archivo" id="archivo">
                              </div>
                              <div>
                                <button class="btn btn-danger" type="submit">Cambiar</button>
                              </div>
                              <div>
                                <a class="btn btn-danger" href="<?php echo $row->archivo; ?>" download="Curriculum">Descargar CV</a>

                              </div>
                          </form>
                          <?php } ?>
                        </div>
                </fieldset>
                    <!-- curriculum en texto -->
                <fieldset style="margin-left:10px">
                    <legend style="margin-top:27px;float: right; width: 92%;">Formación especializada</legend>
                    <img src="img/graduation_cap-32.png" style="float:left;margin-top:35px"/>
                        <form id="form-especialidad" class="curriculum" action="guardaresp.php"  method="post" >
                            <div class="width-100 especialidad-curriculum">
                                <label for="especialidad_curriculum_especialidad" class="required">Especialidad</label>
                                <select id="cmbespec" name="cmbespec"><option value="Analisis Clinicos">Análisis Clínicos</option><option value="Bioquímica Clínica">Bioquímica Clínica</option><option value="Farmacia">Farmacia</option><option value="Farmacia Hospitalaria">Farmacia Hospitalaria</option><option value="Farmacia Industrial y Galénica">Farmacia Industrial y Galénica</option><option value="Inmunología">Inmunología</option><option value="Microbiología y Parasitología Clínicas">Microbiología y Parasitología Clínicas</option><option value="Radiofarmacia Hospitalaria">Radiofarmacia Hospitalaria</option></select>
                                
                            </div>
                            <div class="width-25 especialidad-curriculum">
                                <label for="especialidad_curriculum_anyoObtencion" class="required">Año Obtencion</label>
                                <input type="text" id="anyoob" name="anyoob"  maxlength="4" style="-webkit-logical-height: 24px" />
                                
                            </div>
                            <div class="width-25 especialidad-curriculum">
                                <label for="especialidad_curriculum_lugar" class="required">Lugar</label>
                                <input type="text" id="lugar" name="lugar" style="-webkit-logical-height: 24px" />
                                
                            </div>
                            <div class="width-25 especialidad-curriculum">
                                <label for="residencia" class="required">FIR</label>
                                <select id="residencia" name="residencia"><option value="No">No</option><option value="Sí">Sí</option></select>
                                
                            </div>
                            <div class="width-25 especialidad-curriculum">
                                <label for="especialidad_curriculum_pais" class="required">Pais</label>
                                <select  id="cmbpais" name="cmbpais">
            <option value="">Seleccione el Pais</option>

         <?php 
      

         $sql = "SELECT * FROM pais";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->paisnombre .'">'.utf8_encode ($row->paisnombre).'</option>';

        
    }

    ?>
</select>
                                
                            </div>
                            <div>
                                <button type="sumbit" class="btn btn-danger">Añadir</button>
                            </div>
                        </form><br>
                        <?php
         $sql = "SELECT * FROM formacion  WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as  $row) { ?>   

<table class="table table-bordered table-hover">
    <thead>
        <tr>
           <th>Especialidad</th>
           <th>Año</th>
           <th>Lugar</th>
           <th>FIR</th>
           <th>País</th>
            
        </tr>
    </thead>
<tbody>
<tr>
<td><?php echo utf8_encode($row->especialidad); ?></td>
<td><?php echo utf8_encode($row->Aobtencion); ?></td>
<td><?php echo utf8_encode($row->lugar); ?></td>
<td><?php echo utf8_encode($row->residencia); ?></td>
<td><?php echo utf8_decode($row->pais); ?></td>
</tr>
</tbody>

<?php } ?>
                        <table class="resultados-busqueda" id="tabla-especialidades">
                            <thead>
                              
                            </thead>
                            <tbody>
                                                            
                                                        </tbody>
                        </table>
                </fieldset>
                    
                <fieldset style="margin-left:10px">
                    <legend style="margin-top:27px;float: right; width: 92%;">Homologaciones</legend>
                    <img src="img/purchase_order-32.png" style="float:left;margin-top:35px"/>
                    <form id="form-homologacion" class="curriculum" action="guardarhom.php"  method="post" >
                        <div class="width-33">
                            <label for="homologacion_region" class="required">Homologado para</label>
                            <input type="text" id="homologregion" name="homologregion" required="required"    style="-webkit-logical-height: 24px" />
                            <br><i>Ejemplo: Colombia, 2012</i>
                        </div>
                        <div class="width-33">
                            <label for="homologacion_anyo" class="required">Año</label>
                            <input type="text" id="homologanyo" name="homologanyo" maxlength="4" class="anyo-homo" style="-webkit-logical-height: 24px" />
                        </div>
                        <div>
                              <button type="sumbit" class="btn btn-danger">Añadir</button>            
                        </div>
                    </form>
                    <?php
         $sql = "SELECT * FROM homologacion  WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
?>
<table class="resultados-busqueda" id="tabla-homologaciones">
                        <thead>
                            <tr><th>Homologado para</th><th>Año</th><th></th></tr>
                        </thead>
<?php foreach ($rows as  $row) { ?>   
                    
                        <tbody>
                                                    <tr><td style="" colspan=""><?php echo utf8_encode($row->homologado); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->homologanyo); ?></td>


                                                    </tr>
                                                </tbody>
                                                <?php } ?>
                    </table>
                </fieldset>
                    
                <fieldset style="margin-left:10px">
                    <legend style="margin-top:27px;float: right; width: 92%;">Idiomas</legend>
                    <img src="img/diploma2-32.png" style="float:left;margin-top:35px"/>
                    <form id="form-idioma" class="curriculum" action="guardaridioma.php"  method="post" >
                        <div class="width-100 idioma-curriculum">
                            <label for="idioma_curriculum_idioma" class="required">Idioma</label>
                            <select  id="cmbidioma" name="cmbidioma">
            <option value="">Seleccione el Idioma</option>

         <?php 
      
         
         $sql = "SELECT idx, descripcion FROM cod_lenguaje_pais";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->descripcion .'">'.utf8_encode($row->descripcion).'</option>';

        
    }

    ?>
</select>
                            
                        </div>
                        <div class="width-33">
                            <label for="idioma_curriculum_nivelHablado" class="required">Nivel Hablado</label>
                            <select id="nivel1" name="nivel1"><option value="Bajo">Bajo</option><option value="Medio">Medio</option><option value="Alto">Alto</option><option value="Nativo">Nativo</option></select>
                            
                        </div>
                        <div class="width-33">
                            <label for="idioma_curriculum_nivelEscrito" class="required">Nivel Escrito</label>
                            <select id="nivel2" name="nivel2"><option value="Bajo">Bajo</option><option value="Medio">Medio</option><option value="Alto">Alto</option><option value="Nativo">Nativo</option></select>
                            
                        </div>
                        <div class="width-33">
                            <label for="idioma_curriculum_nivelLeido" class="required">Nivel Leido</label>
                            <select id="nivel3" name="nivel3"><option value="Bajo">Bajo</option><option value="Medio">Medio</option><option value="Alto">Alto</option><option value="Nativo">Nativo</option></select>
                            
                        </div>
                        <div>
                            <button type="submit" class="btn btn-danger">Agregar</button>
                        </div>
                    </form>
                    <?php
         $sql = "SELECT * FROM idioma  WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
?>
                    <table class="resultados-busqueda" id="tabla-idiomas">
                        <thead>
                            <tr><th>Idioma</th><th>Nivel Hablado</th><th>Nivel Escrito</th><th>Nivel Leído</th><th></th></tr>
                        </thead>
                        <?php foreach ($rows as  $row) { ?>   
                        <tbody>
                                                    <tr><td style="" colspan=""><?php echo utf8_encode($row->idioma); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->nivelA); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->nivelE); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->nivelL); ?></td>


                                                    </tr>
                                                </tbody>
                                                <?php } ?>
                    </table>
                </fieldset>
                    
                <fieldset style="margin-left:10px">
                    <legend style="margin-top:27px;float: right; width: 92%;">Experiencia laboral</legend><br><br>
                    <img class="img-responsive img-thumbnail" src="img/doctor_suitecase-32.png" style="float:left;"/><br><br>
                    <form id="form-experiencia" class="curriculum" action="guardarexperiencia.php"  method="post" >
                        <div class="width-33">
                            <label for="experiencia_laboral_curriculum_empresa" class="required">Empresa</label>
                            <input type="text" id="empresa" name="empresa" required="required"    style="-webkit-logical-height: 24px" />
                        </div>
                        <div class="width-33">
                            <label for="experiencia_laboral_curriculum_fechaInicio" class="required">Fecha Inicio</label>
                            <input type="text" id="fechaInicio" name="fechaInicio" required="required"    class="datepicker" style="-webkit-logical-height: 24px" />
                        </div>
                        <div class="width-33">
                            <label for="experiencia_laboral_curriculum_fechaFin">Fecha Fin</label>
                            <input type="text" id="fechaFin" name="fechaFin"    class="datepicker" style="-webkit-logical-height: 24px" />
                        </div>
                        <div class="width-33">
                            <label for="experiencia_laboral_curriculum_unidad" class="required">Unidad</label>
                            <input type="text" id="unidad" name="unidad" required="required"    style="-webkit-logical-height: 24px" />
                        </div>
                        <div class="width-33">
                            <label for="experiencia_laboral_curriculum_pais" class="required">País</label>
                            <select  id="cmbpais" name="cmbpais">
            <option value="">Seleccione el Pais</option>

         <?php 
      
         $sql = "SELECT * FROM pais";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->paisnombre .'">'.utf8_encode ($row->paisnombre).'</option>';

        
    }

    ?>
</select>
                        </div>
                        <div class="width-100">
                            <label for="experiencia_laboral_curriculum_funcion" class="required">Función</label>
                            <textarea id="funcion" name="funcion" required="required"    style="-webkit-logical-height: 24px"></textarea>
                        </div>
                        <div>
                            <button type="submit" class="btn btn-danger">Agregar</button>
                        </div>
                    </form>
                    <?php
         $sql = "SELECT * FROM experiencia  WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
?>
                    <table class="resultados-busqueda" id="tabla-experiencias">
                        <thead>
                            <tr><th>Empresa</th><th>Fecha Inicio</th><th>Fecha Fin</th><th>Unidad</th><th>Funcion</th><th>País</th><th></th></tr>
                        </thead>
                        <?php foreach ($rows as  $row) { ?>
                        <tbody>
                                                    <tr><td style="" colspan=""><?php echo utf8_encode($row->empresa); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->fechaInicio); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->fechaFinal); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->unidad); ?></td>
                                                        <td style="text-align:center;" colspan=""><?php echo utf8_encode($row->funcion); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_decode($row->pais); ?></td>



                                                    </tr>
                                                </tbody>
                                                <?php } ?>
                    </table>
                </fieldset>
                    
                <fieldset style="margin-left:10px">
                    <legend style="margin-top:27px;float: right; width: 92%;">Cursos</legend>
                    <img src="img/diploma1-32.png" style="float:left;margin-top:35px"/>
                    <form id="form-curso" class="curriculum" action="guardarcurso.php"  method="post" >
                        <div class="width-100 curso-curriculum">
                            <label for="curso_curriculum_nombre" class="required">Curso</label>
                            <input type="text" id="curso" name="curso" required="required"    style="-webkit-logical-height: 24px" />
                            
                        </div>
                        <div class="width-25 info-curso">
                            <label for="curso_curriculum_lugar" class="required">Lugar</label>
                            <input type="text" id="lugar" name="lugar" required="required"    style="-webkit-logical-height: 24px" />
                            
                        </div>
                        <div class="width-25 info-curso">
                            <label for="curso_curriculum_horas" class="required">Horas</label>
                            <input type="text" id="horas" name="horas" required="required"    style="-webkit-logical-height: 24px" />
                            
                        </div>
                        <div class="width-25 info-curso">
                            <label for="curso_curriculum_creditos" class="required">Créditos</label>
                            <input type="text" id="creditos" name="creditos" required="required"    style="-webkit-logical-height: 24px" />
                            
                        </div>
                        <div class="width-25 info-curso">
                            <label for="curso_curriculum_fechaFin" class="required">Fecha Fin</label>
                            <input type="text" id="fechaFin" name="fechaFin" required="required"    class="datepicker" style="-webkit-logical-height: 24px" />
                            
                        </div>
                        <div>
                            <button type="submit" class="btn btn-danger">Agregar</button>
                        </div>
                    </form>
                    <?php
         $sql = "SELECT * FROM cursos  WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
?>
                    <table class="resultados-busqueda" id="tabla-cursos">
                        <thead>
                            <tr><th>Curso</th><th>Horas</th><th>Créditos</th><th>Fecha Fin</th><th>Lugar</th><th></th></tr>
                            
                        </thead>
                        <?php foreach ($rows as  $row) { ?> 
                        <tbody>
                                                    <tr><td style="" colspan=""><?php echo utf8_encode($row->curso); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->horas); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->creditos); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->fechafin); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->lugar); ?></td>



                                                    </tr>
                                                </tbody>
                                                <?php } ?>
                    </table>
                </fieldset>
                    
                <fieldset style="margin-left:10px">
                    <legend style="margin-top:27px;float: right; width: 92%;">¿Dónde quieres trabajar?</legend>
                    <img src="img/airport-32.png" style="float:left;margin-top:35px"/>
                    <form id="form-movilidad" class="curriculum" action="movilidad.php"  method="post" >
                        <div class="width-33">
                            <label for="movilidad_curriculum_pais" class="required">País</label>
                            <select  id="cmbpais2" name="cmbpais2">
            <option value="">Seleccione el Pais</option>

         <?php 
      
         $sql = "SELECT * FROM pais";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->id .'">'.utf8_encode ($row->paisnombre).'</option>';

        
    }

    ?>
</select>
                        </div>
                        <div class="width-33" id="prov-mov">
                            <label>Provincia</label>
                           <select id="cmbciudad2" name="cmbciudad2" class="select-centros">
                                    <option value="">Selecciona la Ciudad</option>
                                </select>            </div>
                        <div class="width-33" id="ciudad-mov" style="visibility:hidden">
                            <label>Ciudad</label>
                            <select id="select-ciudades" name="select-ciudad">
                                <option value="todas">Todas</option>
                            </select>
                        </div>
                        <div>
                            
                            <button type="submit" class="btn btn-danger">Agregar</button>
                        </div>
                    </form>
                    <?php
         $sql = "SELECT * FROM movilidad  WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
?>
                    <table class="resultados-busqueda" id="tabla-movilidad">
                        <thead>
                            <tr><th>País</th><th>Ciudad</th><th></th></tr>
                        </thead>
                        <?php foreach ($rows as  $row) { ?> 
                        <tbody>
                                                            <tr>
                                                                <td style="" colspan=""><?php echo utf8_encode($row->pais); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->ciudad); ?></td>
                                                        
                                                            </tr>
                                                    </tbody>
                                                    <?php } ?>
                    </table>
                </fieldset>
            </div>
        </div>
    </div>	

			</div>
		</div>
		<footer id="footer">	
	<div id="container-footer-especialidades">
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
        
        
    </div>
    <div id="footer-aside">
        <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                <li><a href=""></a></li>
                <li><a href=""></a></li>
            </ul>
        </div>
        <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                <li>
                    
                </li>
                <li>
                    
                </li>
                <li>
                    
                </li>
                
							</ul>
		</div>
		
		
	</div>
	<div id="footer-aside">
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
				<li></li>
				<li></li>
			</ul>
		</div>
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
				<li>
					
				</li>
				<li>
					
				</li>
				<li>
					<a href="/links-interesantes"></a>
				</li>
			</ul>
		</div>
		<figure id="logo-footer">
			<img class="img-responsive img-thumbnail" src="img/log.jpg" alt="Logo de MedicalJob" title="MedicalJob, tu web de empleo médico" width="90%" />
		</figure>
		<div id="info-footer">
			<b>Copyright &copy; 2018 </b><br />
			<a href="informacion-legal.php">Información legal</a><br />
			<a href="politica-privacidad.php">Política de privacidad</a> |
			<a href="normativa.php">Normativa</a> |
			<a href="contacto.php">Contacto</a>
		</div>	
	</div>
	
		
</footer>	</div>

                
        		<script src="js2/router.js"></script>
	<script src="js2/routing?callback=fos.Router.setData"></script>
	<script src="js2/jquery-1.9.1.min.js"></script>
    <script src="js2/jquery-ui-1.10.3.custom.min.js"></script>
	<script src="js2/frontend.js"></script>
	<script src="js2/bootstrap.js"></script>
			<script src="js2/usuario.js"></script>
	 

    <script src="js2/jquery.fancybox.pack.js"></script>
	<script type="text/javascript" src="js2/usuario.js"></script>
	<script type="text/javascript" src="js2/curriculum.js"></script>


<script type="text/javascript">
$(document).ready(function () {
    //If image edit link is clicked
    $(".editLink").on('click', function(e){
        e.preventDefault();
        $("#fileInput:hidden").trigger('click');
    });
  
    //On select file to upload
    $("#fileInput").on('change', function(){
        var image = $('#fileInput').val();
        var img_ex = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
    
    //validate file type
        if(!img_ex.exec(image)){
            alert('Please upload only .jpg/.jpeg/.png/.gif file.');
            $('#fileInput').val('');
            return false;
        }else{
            $('.uploadProcess').show();
            $('#uploadForm').hide();
            $( "#picUploadForm" ).submit();
        }
    });
});

//After completion of image upload process
function completeUpload(success, fileName) {
  if(success == 1){
    $('#imagePreview').attr("src", "");
    $('#imagePreview').attr("src", fileName);
    $('#fileInput').attr("value", fileName);
    $('.uploadProcess').hide();
  }else{
    $('.uploadProcess').hide();
    alert('There was an error during file upload!');
  }
  return true;
}
</script>    

<script type="text/javascript">

$(document).ready(function() {

  $("#cmbpais2").change(function(){
          
      var id=$("#cmbpais2").val();
      $('#cmbciudad2').load('escoger2.php?id='+id);
});
});  
</script>  



    </body>
</html>
