<?php
session_start();
$tipo = "";
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
include("conexion.php");

$pa = "";
if (isset($_POST["id"])) {
	$pa = $_POST["id"];
}

$tipo = "Profesional";
$sth = $con->prepare("SELECT * FROM usuarios WHERE colectivo = ? AND tipo = ?");
$sth->bindParam(1, $pa);
$sth->bindParam(2, $tipo);
$sth->execute();

if ($sth->rowCount() > 0) {


echo '<table class="table table-bordered table-hover">';
echo '<thead>';
echo '<tr>';

echo '<th>NOMBRE</th>';
echo '<th>COLECTIVO</th>';
echo '<th>ESPECIALIDAD</th>';
echo '<th>DIRECCIÓN</th>';
echo '<th>CÓDIGO POSTAL</th>';
echo '<th>LOCALIDAD</th>';
echo '<th>COMPRAR</th>';

echo '</tr>';
echo '</thead>';

foreach ($sth as $row ) {

echo '<tbody>';
echo '<tr>';
 echo '<td><a class="" href="cv-previo.php?id='. $row["id"] .'&col='. utf8_encode($row["colectivo"]) .'">'.utf8_encode($row["nombre"]).'</strong></a></td>';
 echo '<td>' .  utf8_encode($row["colectivo"]) . '</td>';
 echo '<td>' .  utf8_encode($row["especialidad"]) . '</td>';
 echo '<td>' .  utf8_encode($row["dir"]) . '</td>';
 echo '<td>' .  utf8_encode($row["CodigoPostal"]) . '</td>';
 echo '<td>' .  utf8_encode($row["localidad"]) . '</td>';
 echo '<td><a class="btn btn-danger" href="exitoso.php?id='. $row["id"] .'&op='. utf8_encode($row["especialidad"]) .'&col='. utf8_encode($row["colectivo"]) .'">Comprar sin Datos</strong></a> <br><br> <a class="btn btn-danger" href="exitoso1.php?id='. $row["id"] .'&op='. utf8_encode($row["especialidad"]) .'&col='. utf8_encode($row["colectivo"]) .'">Comprar con Datos</strong></a> </td>';
  
 echo '</tr>';
 echo '</tbody>';
 

}

}

?>