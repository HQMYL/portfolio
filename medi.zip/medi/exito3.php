<!DOCTYPE HTML>
<html>
<?php

session_start();
$credi = "";
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}

$nombre = "";
if(isset($_SESSION['nombre'])) {
$nombre = $_SESSION['nombre'];}

$colectivo = "";
if(isset($_SESSION['id'])) {
$colectivo= $_SESSION['id'];}

$monto = "";
if(isset($_SESSION['monto'])) {
$monto= $_SESSION['monto'];}
?>
<head></head>

<body>
  <?php 
// STEP 1: read POST data
// Reading POSTed data directly from $_POST causes serialization issues with array data in the POST.
// Instead, read raw POST data from the input stream.
$raw_post_data = file_get_contents('php://input');
$raw_post_array = explode('&', $raw_post_data);
$myPost = array();
foreach ($raw_post_array as $keyval) {
  $keyval = explode ('=', $keyval);
  if (count($keyval) == 2)
    $myPost[$keyval[0]] = urldecode($keyval[1]);
}
// read the IPN message sent from PayPal and prepend 'cmd=_notify-validate'
$req = 'cmd=_notify-validate';
if (function_exists('get_magic_quotes_gpc')) {
  $get_magic_quotes_exists = true;
}
foreach ($myPost as $key => $value) {
  if ($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
    $value = urlencode(stripslashes($value));
  } else {
    $value = urlencode($value);
  }
  $req .= "&$key=$value";
}

// Step 2: POST IPN data back to PayPal to validate
$ch = curl_init('https://ipnpb.paypal.com/cgi-bin/webscr');
curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));
// In wamp-like environments that do not come bundled with root authority certificates,
// please download 'cacert.pem' from "http://curl.haxx.se/docs/caextract.html" and set
// the directory path of the certificate as shown below:
// curl_setopt($ch, CURLOPT_CAINFO, dirname(__FILE__) . '/cacert.pem');
if ( !($res = curl_exec($ch)) ) {
  // error_log("Got " . curl_error($ch) . " when processing IPN data");
  curl_close($ch);
  exit;
}
curl_close($ch);


// inspect IPN validation result and act accordingly
if (strcmp ($res, "VERIFIED") == 0) {
  // The IPN is verified, process it:
  // check whether the payment_status is Completed
  // check that txn_id has not been previously processed
  // check that receiver_email is your Primary PayPal email
  // check that payment_amount/payment_currency are correct
  // process the notification
  // assign posted variables to local variables
  $item_name = $_POST['item_name'];
  $item_number = $_POST['item_number'];
  $payment_status = $_POST['payment_status'];
  $payment_amount = $_POST['mc_gross'];
  $payment_currency = $_POST['mc_currency'];
  $txn_id = $_POST['txn_id'];
  $receiver_email = $_POST['receiver_email'];
  $payer_email = $_POST['payer_email'];
  $fecha=date("Y/m/d");
  
  $sql = "INSERT INTO creditos( usuario,fecha,txn_id,nombreArticulo,numeroArticulo, status,monto,moneda,cuentaR, Ccliente) VALUES (:usuario,:fecha,:txn_id,:item_name,:item_number,:payment_status, :payment_amount, :payment_currency,:receiver_email,:payer_email)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt->bindParam(':txn_id', $txn_id, PDO::PARAM_STR);
$stmt->bindParam(':item_name', $item_name, PDO::PARAM_STR);
$stmt->bindParam(':item_number', $item_number, PDO::PARAM_STR);
$stmt->bindParam(':payment_status', $payment_status, PDO::PARAM_STR); 
$stmt->bindParam(':payment_amount', $payment_amount, PDO::PARAM_STR); 
$stmt->bindParam(':payment_currency', $payment_currency, PDO::PARAM_STR);
$stmt->bindParam(':receiver_email', $receiver_email, PDO::PARAM_STR);
$stmt->bindParam(':payer_email', $payer_email, PDO::PARAM_STR);
 
$stmt->execute();


$credi = array();
$sql = "SELECT * FROM empresas WHERE user ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { 

$credi[0] = $row->creditos;

}

$cantidad = $credi[0];

$cantidad = $cantidad + $monto;

$sql2 = " UPDATE empresas SET creditos =:cantidad WHERE user =:usuario ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':cantidad', $cantidad, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();



$fecha=date("Y/m/d");

$descripcion = "Compra de Créditos";
$descripcion = utf8_decode($descripcion);
$sql = "INSERT INTO historialc (usuario,fecha,descripcion) VALUES (:usuario,:fecha,:descripcion)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);

$stmt->execute();



  // IPN message values depend upon the type of notification sent.
  // To loop through the &_POST array and print the NV pairs to the screen:
  

?>

<script>
alert('La Compra se ha procesado exitosamente');
window.location.href='seccion-empresas.php';
</script>


</body>
</html>