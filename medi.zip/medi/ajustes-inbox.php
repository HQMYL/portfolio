<!DOCTYPE html>
<html lang="es">
<?php
session_start();
include("conexion.php");
include("db.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
?>
    <head>
        <meta charset="UTF-8" />
		<meta name="description" content="	MedicalJob, bolsa de empleo con ofertas de trabajo, congresos y cursos de enfermera, médico y auxiliar en enfermería en el sector de salud
" />
		        <title>Ajustes Inbox 
</title>
        <!--[if lt IE 9]>
        	<script src="/bundles/comun/js/html5shiv.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
                <link rel="stylesheet" type="text/css" href="css2/css.css" />
        		<link rel="stylesheet" type="text/css" href="css2/reset.css" />
    <link rel="stylesheet" type="text/css" href="css2/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css2/frontend.css" />
	<link rel="stylesheet" type="text/css" href="css2/forms.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery-ui-1.10.3.custom.min.css" />

	<link rel="stylesheet" type="text/css" href="css2/usuario.css" />
	<link rel="stylesheet" type="text/css" href="css2/extranet.css" />
    <link rel="stylesheet" type="text/css" href="css3/new.css" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="apple-touch-icon" sizes="114x114" href="" />
        <link rel="apple-touch-icon" sizes="72x72" href="" />
        <link rel="apple-touch-icon" href="" />
        <style type="text/css">
            .menu-titulo {
        
        background-image: url("img/flecha.png");
        
    }

     .btn, .btn-danger {
        float: right;
     }


        </style>
    </head>
    <body itemscope itemtype="http://schema.org/WebPage">
		<div id="cargando" style="display:none"></div>
		    				        	<div id="pagina">
		<header id="header">
			<div id="banner">
				<img class="img-responsive" src="img/portada.jpg" 
					 alt="MedicalJob: Trabaja en el sector médico en cualquier parte del mundo"
					 title="MedicalJob: Trabaja en el sector médico en cualquier parte del mundo" />
			</div>
					</header>
		<div id="contenido">
			<div id="breadcrumb" itemprop="breadcrumb">
									<a href="/"><span class="glyphicon glyphicon-home"></span> Inicio</a> >
											<a href="seccion-usuarios.php">Mi Cuenta</a> >
					 
				 <a href="ajustes-inbox.php">Inbox</a> > Ajustes			</div>
					
			<aside id="sidebar">
				<div id="cuadro-sesion">
                    <?php
            $total = 0;
            $estado = 0;
        $sth = $con->prepare("SELECT * FROM mensajes WHERE usuario = ? AND estado = ?");
$sth->bindParam(1, $usuario);
$sth->bindParam(2, $estado);
$sth->execute();

if ($sth->rowCount() > 0) {
    foreach ($sth as $row) {
        $total = $total + 1;
    }


}
 ?>
	<p><em>BIENVENIDO</em> <span class="green">
			<?php echo $usuario; ?></span><br />
		<em>Tienes <?php echo $total; ?> mensaje(s) en su <a class="blue" href="mis-mensjaes.php">Inbox</a></em>
			</p>
	<p id="cuadro-sesion-saldo">
        <?php
        $sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { ?>
			<em>Saldo actual: <span class="green" id="cuadro-sesion-puntos"><?php echo $row->creditos;?> créditos</span></em>
		</p> <?php } ?>
				
                <?php
 $stmt = $DB_con->prepare('SELECT * FROM perfil WHERE usuario =:uid');
  $stmt->execute(array(':uid'=>$usuario));
  $stmt->execute();
  
  if($stmt->rowCount() > 0)
  {
    while($row=$stmt->fetch(PDO::FETCH_ASSOC))
    {
      extract($row); 
      ?> 
                <img src="img/<?php echo $row['userPic']; ?>"
             alt="Foto de Perfil" 
             title="Foto de Perfil" 
             width="70" style="float: left; margin: 5px 20px" />
             <?php }
         } ?>
		<a class="button button-blue" href="ofertas.php">OFERTAS</a>
		<a class="button button-grey" href="logout.php">SALIR</a>
</div>				                    <div id="menu-usuario" class="menu-lateral">
	<ul id="menu-box">
		<li class="menu-titulo" data-target="submenu-datos">Mi cuenta</li>
		<li class="submenu" id="submenu-datos">
			<ul>
				<li><a href="mis-datos-acceso.php">Mis Datos de Acceso</a></li>
				<li><a href="datos-personales.php">Mis Datos Personales</a></li>
				<li><a href="curriculum.php">Mi Currículum</a></li>
				<li><a href="recomendar-usuario.php">Recomendar MedicalJob</a></li>
                <li><?php
        $sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { 
if(($row->pagovisitas == "0") AND ($row->pagocurri == "0")){ ?>
<a href="<?php echo 'acciones-avanzadas.php';?>">Acciones Avanzadas</a>
<?php } ?>

<?php 
if(($row->pagovisitas == "1") AND ($row->pagocurri == "0")){ ?>
<a href="<?php echo 'visitas-curriculum.php';?>">Acciones Avanzadas</a>
<?php } ?>

<?php 
if(($row->pagovisitas == "0") AND ($row->pagocurri == "1")){ ?>
<a href="<?php echo 'compras-curriculum.php';?>">Acciones Avanzadas</a>
<?php } ?>

<?php 
if(($row->pagovisitas == "1") AND ($row->pagocurri == "1")){ ?>
<a href="<?php echo 'acciones.php';?>">Acciones Avanzadas</a>
<?php } ?>

</li>

<?php } ?>

				<li><a href="eliminar-cuenta-usuario.php">Darme de baja</a></li>
			</ul>
		</li>
		<li class="menu-titulo" data-target="submenu-ofertas">Ofertas</li>
		<li class="submenu" id="submenu-ofertas">
			<ul>
				<li><a href="ofertas.php">Buscar ofertas</a></li>
				<li><a href="mis-ofertas.php">Ver mis candidaturas</a></li>
			</ul>
		</li>
		<li class="menu-titulo" data-target="submenu-inbox">Inbox</li>
		<li class="submenu" id="submenu-inbox">
			<ul>
				<li><a href="mis-mensajes.php">Ver mis mensajes</a></li>
				<li><a href="ajustes-inbox.php">Cambiar mis ajustes de Inbox</a></li>
			</ul>
		</li>
        <li class="menu-titulo" data-target="submenu-puntos">Créditos</li>
        <li class="submenu" id="submenu-puntos">
            <ul>
                <li><a href="creditos.php">Comprar</a></li>
                <li><a href="historial.php">Histórico de compras</a></li>
            </ul>
        </li>
	</ul>
</div>
 

<div id="progressbar-curriculum">
	
	
	<p>
		Quieres mejorar tu currículum?<br />
		<a href="curriculum.php">
			Haz click aquí<br />
			<img 
				src="img/edit_curriculum.png" 
				alt="Modificar mi curriculum" 
				title="Modificar mi curriculum" 
				width="32" 
				height="32"
			/>
		</a>
	</p>
</div>		 <!-- CARRUSEL -->

 <section>
                  
                  <div id="slider-container">
                      <div id="slider-box">
                          <div class="slider-element">
                              <article class="element-red">
                              <img class="img-responsive img-thumbnail" src="img/italiano.png">  
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-green">
                               <img class="img-responsive img-thumbnail" src="img/cposgrado.jpg">     
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-blue">
                                <img class="img-responsive img-thumbnail" src="img/cruz.png">  
                              </article>                            
                          </div>
                      </div>
                  </div>
                  
              </section>        


       <!-- CARRUSEL -->
			</aside>
		
			<div id="content-right">
				<div style="float:left;width:100%">
	</div>									<div id="publi-empresa">
						<a href="wiki-usuarios.php" style="margin-left:0px">
							<img class="img-responsive img-thumbnail" src="img/como-funcionan-los-creditos.jpg" 
							 	 alt="Como funcionan los créditos de MedicalJob"
							 	 title="Como funcionan los créditos de MedicalJob" />
						</a>
												<a href="ofertas.php">
							<img class="img-responsive img-thumbnail" src="img/busca-tu-trabajo.jpg" 
								 alt="Busca tu trabajo en MedicalJob"
								 title="Busca tu trabajo en MedicalJob"
								 style="float:right;margin-right:5px" />
						</a>
					</div>
										<div class="mediempleo-box">
            <div class="content">
                <div class="box-header">
                    <div class="box-title">
                        <h1>AJUSTES DEL INBOX</h1>
                    </div>
                </div>
                <div class="box-content">
                    <div class="form-errors"></div>
                    <form action="guardarajustes.php" method="post" >
                        <div class="width-100">						
                            <p style="width:100%;">
                                El <strong>inbox</strong> es el sistema interno de MedicalJob para la notificación de sucesos relacionados 
                                con tu cuenta, si deseas recibir notificaciones en tu email acerca de los inbox recibidos, activa la siguiente 
                                casilla.
                            </p>
                            <div class="width-100" style="margin-left:50px">
                                <div class="left"><input type="checkbox" id="recibirMail" name="recibirMail"    style="-webkit-logical-width: 30px!important" value="1" /></div>
                                <div class="width-75 left"><label class="label-checkbox" for="ajustes_inbox_recibirMail">Recibir notificaciones del inbox en tu Email</label></div>
                            </div>
                            <div class="width-100">
                                <div style="width:50px;float:left;">&nbsp;</div>
                                <div style="text-align:left;">
                                    <label class="label-select required" for="ajustes_inbox_periodicidad">Periodicidad del envío</label>
                                    <select id="periodicidad" name="periodicidad"  style="width:17% !important"><option value="">Periodicidad</option><option value="Diario">Diario</option><option value="Semanal" selected="selected">Semanal</option><option value="Quincenal">Quincenal</option><option value="Mensual">Mensual</option></select>
                                    <div class="form-errors"></div>
                                </div>
                            </div>						

                            <p style="width:100%">
                                <br />
                                Las empresas pueden emitir ofertas de caracter urgente, estas ofertas requieren ser cubiertas lo antes posible.
                                Si deseas ser notificado cada vez que se publique una oferta urgente, activa la siguiente casilla.
                            </p>
                            <div class="width-100" style="margin-left:50px">
                                <div  class="left"><input type="checkbox" id="recibirUrgente" name="recibirUrgente"    class="label-checkbox" style="-webkit-logical-width: 30px!important" value="1" /></div>
                                <div class="width-75 left"><label class="label-checkbox" for="ajustes_inbox_recibirUrgente">Recibir notificaciones de ofertas urgentes vía Email</label></div>
                            </div>
                            
                             <p style="width:100%">
                                <br />
                                Las ofertas se corresponden con una especialidad. Si deseas ser notificado cuando se publique una oferta de tu especialidad, activa la siguiente casilla.
                            </p>
                            <div class="width-100" style="margin-left:50px">
                                <div  class="left"><input type="checkbox" id="recibirEspecialidad" name="recibirEspecialidad"    class="label-checkbox" style="-webkit-logical-width: 30px!important" value="1" /></div>
                                <div class="width-75 left"><label class="label-checkbox" for="ajustes_inbox_recibirEspecialidad">Recibir notificaciones de ofertas de mi especialidad vía Email</label></div>
                            </div>
                        </div>
                            
                        <button type="submit" class="btn btn-danger">Guardar</button>
                    </form>
                </div>
            </div>
		</div>
			</div>
		</div>
		<footer id="footer">	
	<div id="container-footer-especialidades">
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
        
        
    </div>
    <div id="footer-aside">
        <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                <li><a href=""></a></li>
                <li><a href=""></a></li>
            </ul>
        </div>
        <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                <li>
                    
                </li>
                <li>
                    
                </li>
                <li>
                    
                </li>
							</ul>
		</div>
		
		
	</div>
	<div id="footer-aside">
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
				<li></li>
				<li></li>
			</ul>
		</div>
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
				<li>
					
				</li>
				<li>
					
				</li>
				<li>
					
				</li>
							</ul>
		</div>
		
		
	</div>
	<div id="footer-aside">
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
				<li><a href=""></a></li>
				<li><a href=""></a></li>
			</ul>
		</div>
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
				<li>
					
				</li>
				<li>
					
				</li>
				<li>
					
				</li>
			</ul>
		</div>
		<figure id="logo-footer">
			<img class="img-responsive img-thumbnail" src="img/log.jpg" alt="Logo de MedicalJob" title="MedicalJob, tu web de empleo médico" width="90%" />
		</figure>
		<div id="info-footer">
			<b>Copyright &copy; 2018 </b><br />
			<a href="informacion-legal.php">Información legal</a><br />
			<a href="politica-privacidad.php">Política de privacidad</a> |
			<a href="normativa.php">Normativa</a> |
			<a href="contacto.php">Contacto</a>
		</div>	
	</div>
	
		
</footer>	</div>
                
        		<script src="js2/router.js"></script>
	<script src="js2/routing?callback=fos.Router.setData"></script>
	<script src="js2/jquery-1.9.1.min.js"></script>
    <script src="js2/jquery-ui-1.10.3.custom.min.js"></script>
	<script src="js2/frontend.js"></script>
	<script src="js2/bootstrap.js"></script>
			<script src="js2/usuario.js"></script>
	 

		<script type="text/javascript">
		$(document).ready(function(){
			$("#ajustes_inbox_recibirEspecialidad").prop("checked",true);
		});
	</script>
		<script type="text/javascript" src="js2/usuario.js"></script>
	<script type="text/javascript" src="js2/inbox.js"></script>
	
        
    </body>
</html>
