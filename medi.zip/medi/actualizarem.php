<!DOCTYPE html>
<html>
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}

if(isset($_GET['id'])) {
$id = $_GET['id'];
}
?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DemiJob</title>

    <!-- Bootstrap Core CSS -->
    <link href="css3/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css3/sb-admin.css" rel="stylesheet">
    <link href="css3/new.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css3/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
        .navbar-brand {
color: blue;
}
    a {
            color: #fff;
        }
   

    .select-centros {
    width: 90%;
}

.width-100 {
    float: left;
    width: 99%;
    margin-right: 0.5%;
    margin-top: 5px;
}


.btn, .btn-danger {
    float: right;
} 

 .gris {
    background-color: grey;

 }






    </style>
    

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" style="color: #fff;" href="admin.php">Inicio</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
               <li><a style="color: #fff;" class="btn-danger"><?php echo "Bienvenido: " .$usuario; ?></a></li>
              <li><a style="color: #fff;" class="btn-danger" href="logout.php">Cerrar Sesión</a></li> 
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="admin.php"><i class="fa fa-fw fa-dashboard"></i> Panel de Control</a>
                    </li>
                    
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo"><i></i> Usuarios <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="agregarusuario.php">Agregar Usuario</a>
                            </li>
                            <li>
                                <a href="consultarusuario.php">Consultar Usuario</a>
                            </li>
                            
                        </ul>
                    </li>

                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo1"> Empresas <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo1" class="collapse">
                            <li>
                                <a href="agregarempresa.php">Agregar Empresa</a>
                            </li>
                            <li>
                                <a href="consultarempresa.php">Consultar Empresa</a>
                            </li>
                            
                        </ul>
                    </li>
                   <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo3"><i></i> Empleos <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo3" class="collapse">
                            <li>
                                <a href="agregarempleo.php">Consultar Empleos</a>
                            </li>
                            <li>
                                <a href="consultarempleo.php">Consultar Usuario</a>
                            </li>
                            
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo4"><i></i> Oposiciones <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo4" class="collapse">
                            <li>
                                <a href="agregaroposicion.php">Agregar Oposición</a>
                            </li>
                            <li>
                                <a href="consultaroposicion.php">Consultar Oposición</a>
                            </li>
                            
                        </ul>
                    </li> 
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo5"><i></i> Reportes <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo5" class="collapse">
                            <li>
                                <a href="ventas.php">Ventas</a>
                            </li>
                            <li>
                                <a href="creditos-adquiridos.php">Usuarios Registrados</a>
                            </li>
                            
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header">
                            ACTUALIZACIÓN
                        </h3>
                        <ol class="breadcrumb">
                            
                        </ol>

                    </div>
                </div>
            

 
 <!-- INICIO COL-LG-6 -->
    <?php 
    $sql = "SELECT * FROM empresas WHERE id ='".$id."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { ?>

            <form class="form" name="formi" method="POST" action="actualizar3.php">
                <fieldset>
                    <div class="col-lg-12">
                        <label style="color: #fff;" class="gris">ACTUALIZACIÓN DE EMPRESAS</label>
                    </div>
                    <div class="col-md-6">
                        
                      <label>RAZÓN SOCIAL</label>
                      <input class="select-centros" type="text" name="social" id="social" value="<?php echo utf8_encode($row->social); ?>">

                    </div>
                    <div class="col-md-6">
                        
                      <label>CORREO</label>
                      <input class="select-centros" type="text" name="correo" id="correo" value="<?php echo utf8_encode($row->correo); ?>">

                    </div><br>

                    <div class="col-md-6">
                        
                      <label>DIRECCIÓN</label>
                      <input class="select-centros" type="text" name="dir" id="dir" value="<?php echo utf8_encode($row->dir); ?>">

                    </div><br>
                    <div class="col-md-6">
                        
                      <label>TELÉFONO FIJO</label>
                      <input class="select-centros" type="text" name="tel1" id="tel1" value="<?php echo $row->fijo; ?>">

                    </div><br>

                     <div class="col-md-6">
                        
                      <label>TELÉFONO CELULAR</label>
                      <input class="select-centros" type="text" name="tel2" id="tel2" value="<?php echo $row->celular; ?>">

                    </div><br>
                    <div class="col-md-6">
                        
                      <label>Nº CALLE</label>
                      <input class="select-centros" type="text" name="ncalle" id="ncalle" value="<?php echo $row->numeroC; ?>">

                    </div><br>
                    
                   <div class="col-md-6">
                        
                      <label>PISO</label>
                      <input class="select-centros" type="text" name="piso" id="piso" value="<?php echo $row->piso; ?>">

                    </div><br>

                    <div class="col-md-6">
                        
                      <label>DEPARTAMENTO</label>
                      <input class="select-centros" type="text" name="dep" id="dep" value="<?php echo $row->departamento; ?>">

                    </div><br>
                    

                    
                     <div class="col-md-6">
                        
                      <label>CÓDIGO POSTAL</label>
                      <input class="select-centros" type="text" name="cp" id="cp" value="<?php echo $row->codigoPostal; ?>">

                    </div><br>

                     <div class="col-md-6">
                        
                      <label>LOCALIDAD</label>
                      <input class="select-centros" type="text" name="loc" id="loc" value="<?php echo $row->localidad; ?>">
                      
                    </div><br>

                    <div class="col-md-6">
                        
                      <label>PROVINCIA</label>
                      <input class="select-centros" type="text" name="prov" id="prov" value="<?php echo $row->provincia; ?>">
                      <input type="hidden" name="id" id="id" value="<?php echo $row->id; ?>">

                    </div><br>
                   
                   <div class="col-md-6">
                        
                      <label>MATRICULA NACIONAL</label>
                      <input class="select-centros" type="text" name="nacional" id="nacional" value="<?php echo $row->MatriculaNacional; ?>">
                      <input type="hidden" name="id" id="id" value="<?php echo $row->id; ?>">

                    </div><br>

                   <div class="col-md-6">
                        
                      <label>MATRÍCULA PROVINCIAL</label>
                      <input class="select-centros" type="text" name="provincial" id="provincial" value="<?php echo $row->MatriculaProvincial; ?>">
                      <input type="hidden" name="id" id="id" value="<?php echo $row->id; ?>">

                    </div><br>

<div class="col-md-6">
                        
                      <label>TIPO</label>
                      <input class="select-centros" type="text" name="tipoem" id="tipoem" value="<?php echo $row->tipoem; ?>">
                      <input type="hidden" name="id" id="id" value="<?php echo $row->id; ?>">

                    </div><br>

<div class="col-md-6">
                        
                      <label>CONTACTO</label>
                      <input class="select-centros" type="text" name="nombre" id="nombre" value="<?php echo $row->nombre; ?>">
                      <input type="hidden" name="id" id="id" value="<?php echo $row->id; ?>">
                      <input type="hidden" name="user" id="user" value="<?php echo $row->user; ?>">
                      <input type="hidden" name="pass" id="pass" value="<?php echo $row->pass; ?>">
                      <input type="hidden" name="tipo2" id="tipo2" value="<?php echo $row->tipo2; ?>">
                      <input type="hidden" name="creditos" id="creditos" value="<?php echo $row->creditos; ?>">
                      <input type="hidden" name="curr1" id="curr1" value="<?php echo $row->curr1; ?>">
                      <input type="hidden" name="curr2" id="curr2" value="<?php echo $row->curr2; ?>">

                    </div><br>

<div class="col-md-6">
                        
                    </div><br>

                    
        
                </fieldset><br>

                <button class="btn btn-danger" type="submit">Actualizar</button>

            </form>

            <?php } ?>
                 <!-- FINAL COL-LG-6-->
       </div>

        </div>

            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js3/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js3/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js3/plugins/morris/raphael.min.js"></script>
    <script src="js3/plugins/morris/morris.min.js"></script>
    <script src="js3/plugins/morris/morris-data.js"></script>

</body>

</html>
