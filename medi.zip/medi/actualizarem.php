<!DOCTYPE HTML>
<html>
<body>
<?php
include("conexion.php");

if (isset($_POST["id"])) {
	$pa = $_POST["id"];
}



 $sql = "SELECT * FROM empresas WHERE nombre ='".$pa."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {

echo '<form class="form" method="POST" action="actaualizar3.php">';
echo '<fieldset>';
echo '<div class="col">';

echo '<label>RAZÓN SOCIAL <span class="tooltip">?</span></label>';

echo '<input type="text" name="social" id="social" value=" '. $row->social .'">';

echo '<label>CORREO <span class="tooltip">?</span></label>';
 echo '<input type="text" name="correo" id="correo" value=" '. $row->correo .'">';

echo '<label>CONTACTO <span class="tooltip">?</span></label>';
echo '<input type="text" name="nombre" readonly="true" id="nombre" value=" '. $row->nombre .'">';

 echo '</div>';
 echo '<div class="col">';
 echo '<label>DIRECCIÓN<span class="tooltip">?</span></label>';
 echo '<input type="text" name="dir" id="dir" value=" '. $row->dir .'" >';

 echo '<label>TELÉFONO: <span class="tooltip">?</span></label>';
 echo '<input type="text" name="tel" id="tel" value=" '. $row->telef .'">';

  echo '</div>';

 echo '<div class="col">';
 echo '<label>USUARIO<span class="tooltip">?</span></label>';
 echo '<input type="text" name="user" id="user" value=" '. $row->user .'">';
 echo '<label>CONTRASEÑA<span class="tooltip">?</span></label>';
 echo '<input type="text" name="pass" id="pass" value=" '. $row->pass .'">';
 echo '</div>';
 echo '<div class="col all">';
 echo '</div>';
 echo '</fieldset>';
 echo '<input type="submit" value="ACTUALIZAR">';
 echo '</form>';

}


 ?>
 </body>
 </html>