<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}



if (isset($_POST["cmbespec"])) {
	$cmbespec = utf8_decode($_POST["cmbespec"]);
}


if (isset($_POST["anyoob"])) {
	$anyoob = utf8_decode($_POST["anyoob"]);
}


if (isset($_POST["lugar"])) {
	$lugar = utf8_decode($_POST["lugar"]);
}



if (isset($_POST["residencia"])) {
	$residencia = utf8_decode($_POST["residencia"]);
}



if (isset($_POST["cmbpais"]) ) {
  $pais = utf8_decode($_POST["cmbpais"]);

  }

 

$sql = "INSERT INTO formacion (usuario,especialidad,Aobtencion, lugar,residencia, pais) VALUES (:usuario,:cmbespec,:anyoob, :lugar,:residencia,:pais)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':cmbespec', $cmbespec, PDO::PARAM_STR);
$stmt->bindParam(':anyoob', $anyoob, PDO::PARAM_STR);
$stmt->bindParam(':lugar', $lugar, PDO::PARAM_STR); 
$stmt->bindParam(':residencia', $residencia, PDO::PARAM_STR); 
$stmt->bindParam(':pais', $pais, PDO::PARAM_STR); 
$stmt->execute();
 
?>

<script>
alert('La especialidad a sido agregada exitosamaente');
window.location.href='curriculum.php';
</script>

</body>
<html>