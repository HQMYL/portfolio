<!DOCTYPE HTML>
<html>
<?php
include("conexion.php");
?>
<body>
<?php

if (isset($_POST["fecha"])) {
	$fecha = $_POST["fecha"];
}


if (isset($_POST["desc"])) {
	$descrip = $_POST["desc"];
}

if (isset($_POST["emp"])) {
	$convocante = $_POST["emp"];
}

if (isset($_POST["tuti"])) {
	$titulacion = $_POST["tuti"];
}

if (isset($_POST["plazas"])) {
	$plazas = $_POST["plazas"];
}

if (isset($_POST["id"])) {
	$id = $_POST["id"];
}






$sql = " SELECT * FROM oposiciones WHERE id = '" .$id. "'";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
foreach ($rows as $row) {



if( ( $fecha == $row->fecha) AND ($descrip == $row->descripcion)  AND ($convocante == $row->convocante)  AND ($titulacion == $row->titulacion) ) {

$sql2 = " UPDATE oposiciones SET plazas=:plazas WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':plazas', $plazas, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $fecha == $row->fecha) AND ($descrip == $row->descripcion)  AND ($convocante == $row->convocante)  AND ($plazas == $row->plazas) ) {

$sql2 = " UPDATE oposiciones SET titulacion=:titulacion WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':titulacion', $titulacion, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $fecha == $row->fecha) AND ($descrip == $row->descripcion)  AND ($convocante == $row->convocante) ) {

$sql2 = " UPDATE oposiciones SET titulacion=:titulacion WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':titulacion', $titulacion, PDO::PARAM_STR);
$stmt2->bindParam(':plazas', $plazas, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $fecha == $row->fecha) AND ($descrip == $row->descripcion)  AND ($titulacion == $row->titulacion) ) {

$sql2 = " UPDATE oposiciones SET convocante=:convocante, plazas=:plazas WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':convocante', $convocante, PDO::PARAM_STR);
$stmt2->bindParam(':plazas', $plazas, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $fecha == $row->fecha) AND ($descrip == $row->descripcion)  AND ($plazas == $row->plazas) ) {

$sql2 = " UPDATE oposiciones SET titulacion=:titulacion WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':convocante', $convocante, PDO::PARAM_STR);
$stmt2->bindParam(':titulacion', $plazas, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $fecha == $row->fecha) AND ($descrip == $row->descripcion ) ) {

$sql2 = " UPDATE oposiciones SET titulacion=:titulacion WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':convocante', $convocante, PDO::PARAM_STR);
$stmt2->bindParam(':titulacion', $titulacion, PDO::PARAM_STR);
$stmt2->bindParam(':plazas', $plazas, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $fecha == $row->fecha) AND ($convocante == $row->convocante ) ) {

$sql2 = " UPDATE oposiciones SET descripcion=:descrip, titulacion=:titulacion, plazas=:plazas WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->bindParam(':titulacion', $titulacion, PDO::PARAM_STR);
$stmt2->bindParam(':plazas', $plazas, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $fecha == $row->fecha) AND ($titulacion == $row->titulacion ) ) {

$sql2 = " UPDATE oposiciones SET descripcion=:descrip, convocante=:convocante, plazas=:plazas WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->bindParam(':titulacion', $titulacion, PDO::PARAM_STR);
$stmt2->bindParam(':plazas', $plazas, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $fecha == $row->fecha) AND ($plazas == $row->plazas ) ) {

$sql2 = " UPDATE oposiciones SET descripcion=:descrip, convocante=:convocante, titulacion=:titulacion  WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->bindParam(':convocante', $convocante, PDO::PARAM_STR);
$stmt2->bindParam(':titulacion', $titulacion, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $descrip == $row->descripcion) AND ($convocante == $row->convocante ) ) {

$sql2 = " UPDATE oposiciones SET fecha=:fecha, titulacion=:titulacion, plazas=:plazas  WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt2->bindParam(':titulacion', $titulacion, PDO::PARAM_STR);
$stmt2->bindParam(':plazas', $plazas, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $descrip == $row->descripcion) AND ($titulacion == $row->titulacion ) ) {

$sql2 = " UPDATE oposiciones SET fecha=:fecha, convocante=:convocante, plazas=:plazas  WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt2->bindParam(':convocante', $convocante, PDO::PARAM_STR);
$stmt2->bindParam(':plazas', $plazas, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $descrip == $row->descripcion) AND ($plazas == $row->plazas ) ) {

$sql2 = " UPDATE oposiciones SET fecha=:fecha, convocante=:convocante, titulacion=:titulacion  WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt2->bindParam(':convocante', $convocante, PDO::PARAM_STR);
$stmt2->bindParam(':titulacion', $titulacion, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}


if( ( $convocante == $row->convocante) AND ($titulacion == $row->titulacion ) ) {

$sql2 = " UPDATE oposiciones SET fecha=:fecha, descripcion=:descrip, plazas=:plazas  WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->bindParam(':plazas', $plazas, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}


if( ( $convocante == $row->convocante) AND ($plazas == $row->plazas ) ) {

$sql2 = " UPDATE oposiciones SET fecha=:fecha, descripcion=:descrip, titulacion=:titulacion  WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->bindParam(':titulacion', $titulacion, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( ( $titulacion == $row->titulacion) AND ($plazas == $row->plazas ) ) {

$sql2 = " UPDATE oposiciones SET fecha=:fecha, descripcion=:descrip, convocante=:convocante  WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->bindParam(':convocante', $convocante, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( $fecha == $row->fecha ) {

$sql2 = " UPDATE oposiciones SET  descripcion=:descrip, convocante=:convocante, titulacion=:titulacion, plazas=:plazas  WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->bindParam(':convocante', $convocante, PDO::PARAM_STR);
$stmt2->bindParam(':titulacion', $titulacion, PDO::PARAM_STR);
$stmt2->bindParam(':plazas', $plazas, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( $descrip == $row->descripcion ) {

$sql2 = " UPDATE oposiciones SET  fecha=:fecha, convocante=:convocante, titulacion=:titulacion, plazas=:plazas  WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt2->bindParam(':convocante', $convocante, PDO::PARAM_STR);
$stmt2->bindParam(':titulacion', $titulacion, PDO::PARAM_STR);
$stmt2->bindParam(':plazas', $plazas, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( $convocante == $row->convocante ) {

$sql2 = " UPDATE oposiciones SET  fecha=:fecha, descripcion=:descrip, titulacion=:titulacion, plazas=:plazas  WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->bindParam(':titulacion', $titulacion, PDO::PARAM_STR);
$stmt2->bindParam(':plazas', $plazas, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( $titulacion == $row->titulacion ) {

$sql2 = " UPDATE oposiciones SET  fecha=:fecha, descripcion=:descrip, convocante=:convocante, plazas=:plazas  WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->bindParam(':convocante', $convocante, PDO::PARAM_STR);
$stmt2->bindParam(':plazas', $plazas, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}

if( $plazas == $row->plazas ) {

$sql2 = " UPDATE oposiciones SET  fecha=:fecha, descripcion=:descrip, convocante=:convocante, titulacion=:titulacion  WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->bindParam(':convocante', $convocante, PDO::PARAM_STR);
$stmt2->bindParam(':titulacion', $titulacion, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);

$stmt2->execute();

}


}

?>
<script>
	alert('La Oposición a sido actualizada exitosamaente');
window.location.href='actualizaroposicion.php';


</script>
</body>
</html>