<!DOCTYPE HTML>
<html>
<?php
include("conexion.php");
?>
<body>
<?php

if (isset($_POST["fecha"])) {
	$fecha = $_POST["fecha"];
}


if (isset($_POST["desc"])) {
	$descrip = $_POST["desc"];
}

if (isset($_POST["emp"])) {
	$convocante = $_POST["emp"];
}

if (isset($_POST["tuti"])) {
	$titulacion = $_POST["tuti"];
}

if (isset($_POST["plazas"])) {
	$plazas = $_POST["plazas"];
}

if (isset($_POST["id"])) {
	$id = $_POST["id"];
}


$sql2 = " UPDATE oposiciones SET fecha =:fecha, descripcion=:descrip, convocante=:convocante, titulacion=:titulacion,plazas=:plazas WHERE id=:id ";

$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR); 
$stmt2->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt2->bindParam(':convocante', $convocante, PDO::PARAM_STR);
$stmt2->bindParam(':titulacion', $titulacion, PDO::PARAM_STR);
$stmt2->bindParam(':plazas', $plazas, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);


?>
<script>
	alert('La Oposición a sido actualizada exitosamaente');
window.location.href='actualizaroposicion.php';


</script>
</body>
</html>