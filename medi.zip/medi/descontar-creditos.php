<?php
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}

$creditos = "47";

$sql2 = " UPDATE usuarios SET creditos =:creditos  WHERE usuario =:usuario ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':creditos', $creditos, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();


$sql = "SELECT * FROM visitas WHERE usuario ='".$usuario."'";


$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

echo '<table class="table table-bordered table-hover">';
echo '<thead>';
echo '<tr>';

echo '<th>Empresa</th>';

echo '</tr>';
echo '</thead>';
foreach ($rows as $row) {
echo '<tbody>';
echo '<tr>';
 echo '<td>' .  $row->usuario1 . '</td>';
 echo '<td>' .  $row->usuario2 . '</td>';
 echo '</tr>';
 echo '</tbody>';
 echo '</table>';
}

 ?>