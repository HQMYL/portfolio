<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
include("conexion.php");
include("db.php");

$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];
}




if(isset($_POST['btnsave']))
   {




$id = $_POST['id'];
      $stmt_edit = $DB_con->prepare('SELECT * FROM perfil WHERE id =:uid');
      $stmt_edit->execute(array(':uid'=>$id));
      $edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
      extract($edit_row);



      $username = $_POST['usuario'];// user name
      // user email
         
      $imgFile = $_FILES['user_image']['name'];
      $tmp_dir = $_FILES['user_image']['tmp_name'];
      $imgSize = $_FILES['user_image']['size'];
               
      if($imgFile)
      {
         
         $upload_dir ='img/'; // upload directory  
         $imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
         $valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
         $userpic = rand(1000,1000000).".".$imgExt;
         if(in_array($imgExt, $valid_extensions))
         {        
            if($imgSize < 80000000)
            {

                unlink($upload_dir.$edit_row['userPic']);
                
               @move_uploaded_file($tmp_dir,$upload_dir.$userpic);
            }
            else
            {
               $errMSG = "El tamaño de la imagen debe ser inferior a  5MB";
            }
         }
         else
         {
            $errMSG = "El tipo de archivo no es permitido, inténtalo nuevamente.";     
         }  
      }
       
       else
      {
         // if no image selected the old image remain as it is.
         $userpic = $edit_row['userPic']; // old image from database
      }  
                
      
      // if no error occured, continue ....
      if(!isset($errMSG))
      {


// CODIGO QUE GUARDA EN LA TABLA
       
// CODIGO QUE GUARDA EN LA TABLA



         $stmt = $DB_con->prepare('UPDATE perfil 
                                SET  userPic=:upic 
                               WHERE id=:uid');
         $stmt->bindParam(':upic',$userpic);
         $stmt->bindParam(':uid',$id);
            
         if($stmt->execute()){
            ?>
                <script>
            alert('Foto Actualizada exitosamente');
            window.location.href='curriculum.php';
            </script>
                <?php
         }
         else{
            $errMSG = "No se pudo actualizar la imagen !";
         }
      
      }
      
                  
   }
   
?>

</body>
<html>