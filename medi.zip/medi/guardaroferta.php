<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
session_start();
$col = "";
$colectivo = "";
$x = "";
$a = "";
include("conexion.php");
$estado = "";
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}







if (isset($_POST["cmbcolectivo"])) {
	$col = utf8_decode($_POST["cmbcolectivo"]);

$x = array();
$sql = "SELECT * FROM colectivo WHERE id ='".$col."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { 

$x[0] = $row->nombre;
}

$colectivo = $x[0];
$colectivo = utf8_decode($colectivo);

}



if (isset($_POST["cmbespec"])) {
	$espec = utf8_decode($_POST["cmbespec"]);
}


if (isset($_POST["puesto"])) {
	$puesto = utf8_decode($_POST["puesto"]);
}



if (isset($_POST["descripcion1"])) {
	$descripcion1 = $_POST["descripcion1"];
}



if (isset($_POST["req"]) ) {
  $req = utf8_decode($_POST["req"]);

  }

   

if (isset($_POST["salario"])) {
   $salario = utf8_decode($_POST["salario"]);
}



if (isset($_POST["fin"])) {
	$fin = utf8_decode($_POST["fin"]);
}

if (isset($_POST["nombre"])) {
  $nombre = utf8_decode($_POST["nombre"]);
}

if (isset($_POST["tipo"])) {
  $tipo = utf8_decode($_POST["tipo"]);
}


if (isset($_POST["telefono"])) {
  $tel = $_POST["telefono"];
}


if (isset($_POST["cmbpais2"])) {
  $pais2 = utf8_decode($_POST["cmbpais2"]);
   
   $a = array();

$sql = "SELECT * FROM pais WHERE id ='".$pais2."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { 

$a[0] = $row->paisnombre;
}

$pais = $a[0];
$pais = utf8_decode($pais);


}

if (isset($_POST["cmbciudad2"])) {
  $ciudad = utf8_decode($_POST["cmbciudad2"]);
}

if (isset($_POST["direccion"])) {
  $direccion = utf8_decode($_POST["direccion"]);
}


if (isset($_POST["descripcion2"])) {
  $descripcion2 = utf8_decode($_POST["descripcion2"]);
}


if (isset($_POST["NombreContacto"])) {
  $contacto = utf8_decode($_POST["NombreContacto"]);
}


if (isset($_POST["TelefonoContacto"])) {
  $telcontacto = $_POST["TelefonoContacto"];
}


if (isset($_POST["CorreoContacto"])) {
  $correocontacto = utf8_decode($_POST["CorreoContacto"]);
}

$estado = "Activa";

$nombre_img = $_FILES['archivo']['name'];
$tipo = $_FILES['archivo']['type'];
$tamano = $_FILES['archivo']['size'];
 
//Si existe imagen y tiene un tamaño correcto
if (($nombre_img == !NULL) && ($_FILES['archivo']['size'] <= 800000)) 
{
   //indicamos los formatos que permitimos subir a nuestro servidor
   if (($_FILES["archivo"]["type"] == "image/gif")
   || ($_FILES["archivo"]["type"] == "image/jpeg")
   || ($_FILES["archivo"]["type"] == "image/jpg")
   || ($_FILES["archivo"]["type"] == "image/png"))
   
      // Ruta donde se guardarán las imágenes que subamos
      $directorio = "./img/";
      // Muevo la imagen desde el directorio temporal a nuestra ruta indicada anteriormente
      move_uploaded_file($_FILES['archivo']['tmp_name'],$directorio.$nombre_img);
      $nombre_img = $directorio.$nombre_img;
   }

$sql = "INSERT INTO ofertas (usuario,colectivo,especialidad,puesto,descripcionPuesto,requerimientos,salario,caducidad,nombreCentro,tipoCentro, telefono,pais, ciudad, direccionCentro,descripcionCentro,nombreContacto,telefonocontacto,correoContacto,img,estado) VALUES (:usuario,:colectivo,:espec,:puesto,:descripcion1,:req,:salario, :fin,:nombre,:tipo,:tel,:pais,:ciudad,:direccion,:descripcion2, :contacto, :telcontacto,:correocontacto,:nombre_img,:estado)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':colectivo', $colectivo, PDO::PARAM_STR);
$stmt->bindParam(':espec', $espec, PDO::PARAM_STR);
$stmt->bindParam(':puesto', $puesto, PDO::PARAM_STR);
$stmt->bindParam(':descripcion1', $descripcion1, PDO::PARAM_STR);
$stmt->bindParam(':req', $req, PDO::PARAM_STR);
$stmt->bindParam(':salario', $salario, PDO::PARAM_STR);
$stmt->bindParam(':fin', $fin, PDO::PARAM_STR);
$stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt->bindParam(':tel', $tel, PDO::PARAM_STR); 
$stmt->bindParam(':pais', $pais, PDO::PARAM_STR); 
$stmt->bindParam(':ciudad', $ciudad, PDO::PARAM_STR);
$stmt->bindParam(':direccion', $direccion, PDO::PARAM_STR);
$stmt->bindParam(':descripcion2', $descripcion2, PDO::PARAM_STR);
$stmt->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt->bindParam(':telcontacto', $telcontacto, PDO::PARAM_STR);
$stmt->bindParam(':correocontacto', $correocontacto, PDO::PARAM_STR);
$stmt->bindParam(':nombre_img', $nombre_img, PDO::PARAM_STR);
$stmt->bindParam(':estado', $estado, PDO::PARAM_STR);
 $stmt->execute();

 
 

?>

<script>
alert('La Oferta a sido agregada exitosamaente');
window.location.href='nueva-oferta.php';
</script>

</body>
<html>