<html lang="es">
<?php
session_start();
include("conexion.php");
include("inc/funciones.php");
include('dbcon.php');
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
?>
    <head>
      
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="Publica tus ofertas de trabajo de médico, enfermera y auxiliar en enfermería gratis en la mayor bolsa de empleo online del sector sanitario" />
		        <title>Registra tu centro o empresa para insertar ofertas de trabajo de salud</title>
        <!--[if lt IE 9]>
        	<script src="/bundles/comun/js/html5shiv.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
           
                 
                 <script src="js3/jquery-3.js"></script>
                <link rel="stylesheet" type="text/css" href="css2/css.css" />
        	<link rel="stylesheet" type="text/css" href="css2/reset.css" />
    <link rel="stylesheet" type="text/css" href="css2/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css2/frontend.css" />
	<link rel="stylesheet" type="text/css" href="css2/forms.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery.fancybox.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery-ui-1.10.3.custom.min.css" />
  <link rel="stylesheet" type="text/css" href="css3/new.css" />
   
  
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="apple-touch-icon" sizes="114x114" href="" />
        <link rel="apple-touch-icon" sizes="72x72" href="" />
        <link rel="apple-touch-icon" href="" />

        <style type="text/css">
        	body {
            background-color: #FFFF00;
          }


          .btn, .btn-danger {
        		float: right;
        	}
        	
#pagina {
width: 95%;	
}

 input[name="slider-select-element"] {
      display: none;
  }
  
  
  .aviso {

{
  font-family:Verdana, Geneva, sans-serif;
  font-weight:bold;
  font-size:15px;
}
  }
     

#Error{
  background-image:url(no.jpg);
  background-repeat:no-repeat;
  background-position:left; 
  color:#FF0000; 
  padding-left:33px; 
  height:19px; 
  padding-top:6px;
  padding-right:10px;
  }
#Success{
  background-image:url(yes.jpg);
  background-repeat:no-repeat;
  background-position:left; 
  color:#669933; 
  padding-left:33px; 
  height:19px; 
  padding-top:6px;
  padding-right:10px;
  }



/* CSS Document */

        </style>


<script>
function consultar(){   
       /// Aqui podemos enviarle alguna variable a nuestro script PHP
    var US= document.getElementById("user2").value;
       /// Invocamos a nuestro script PHP
    $.post("username-check2.php", { id: US }, function(data){
       /// Ponemos la respuesta de nuestro script en el DIV recargado
    $("#consi").html(data);
    });        
}
</script>

    
</head>


    <body itemscope itemtype="http://schema.org/WebPage">
     

		<div id="cargando" style="display:none"></div>
		    				        		<div id="pagina">
		<header id="header">
			<div id="banner">
				<img class="img-responsive" src="img/portada.jpg" alt="MedicalJob" />
			</div>
					</header>
		<div id="contenido">
			<div id="breadcrumb" itemprop="breadcrumb">
							<a href="index.php">
					<span class="glyphicon glyphicon-home"></span> Inicio
				</a> > 
			Registra tu empresa			</div>
					
			<aside id="sidebar">
			    				<div id="contadores">
	<div class="contador contador-profesionales">
		<div class="cifra-contador">
			<?php
			$total = 0;
			$tipo = "Profesional";
			$sth = $con->prepare("SELECT * FROM usuarios WHERE tipo = ?");
$sth->bindParam(1, $tipo);

$sth->execute();

if ($sth->rowCount() > 0) {

foreach ($sth as $row ) {
	$total = $total +1;

}
}
?>
			<strong><?php echo $total; ?></strong>
		</div>
		<div class="texto-contador">profesionales<br />sanitarios</div>
	</div>
	<div class="contador contador-empresas">
		<div class="cifra-contador">
			<?php
			$sql = "SELECT * FROM empresas"; 
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
$total = 0;
foreach ($rows as $row) {
$total = $total + 1;
}
?>
			<strong><?php echo $total; ?></strong>
		</div>
		<div class="texto-contador">centros y<br />empresas</div>
	</div>
	</div>									<h2 class="titulo-sidebar-box">REGÍSTRATE, ES GRATIS</h2>
					<div class="sidebar-box">
						<a href="usuario.php" class="boton-registro boton-registro-profesionales">
	soy <br />profesional <br />sanitario
</a>
<a href="empresa.php" class="boton-registro boton-registro-empresas">
	soy <br />centro o <br />empresa
</a>
					</div>
					<h2 class="titulo-sidebar-box">ACCEDE A TU CUENTA</h2>
					<div class="sidebar-box sidebar-box-bordered">
						 
	<form id="login" action="validar.php" method="post" style="width:90%;margin:10px auto">
		<div class="form-widget-container">
			<label for="input-login">USUARIO</label>
			<input type="text"  id="user" name="user" class="text-input-border" />
		</div>
		<div class="form-widget-container">
			<label for="input-password">CONTRASEÑA</label>
			<input type="password"  id="pass" name="pass" class="text-input-border" />
		</div><br>
		<div class="form-widget-container">
			<input type="checkbox" id="input-remember-me" name="_remember_me" checked />
			<label id="recuerdame" for="input-remember-me">No cerrar sesión</label>
			<button type="submit" class="btn btn-danger">Ingresar</button>
		</div>
		<div class="form-widget-container">			
			<p><strong style="font-size:9px"><a href="recuperar-contrasena.html">¿Olvidaste tu contraseña?</a></strong></p>
		</div>
	</form>
					</div>
									
						<!-- CARRUSEL -->
			<section>
                  
                  <div id="slider-container">
                      <div id="slider-box">
                          <div class="slider-element">
                              <article class="element-red">
                              <img class="img-responsive img-thumbnail" src="img/cposgrado.jpg">  
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-green">
                               <img class="img-responsive img-thumbnail" src="img/italiano.png">     
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-blue">
                                <img class="img-responsive img-thumbnail" src="img/cruz.png">  
                              </article>                            
                          </div>
                      </div>
                  </div>
                  
              </section>      

		<!-- CARRUSEL -->
					
        						
    <div class="sidebar-box">
        
	</div>
			</aside>
		
			<div id="content-right">
				<div style="float:left;width:100%">
	</div>	
	<!-- MENSAJE -->
		<div>
                	
                	<h1><?php echo $msj; ?></h1>
                	 
                </div>
                <!-- MENSAJE -->			    <div class="mediempleo-box">
        <div class="content">
            <div class="box-header">
                <div class="box-title">
                    <h1>Formulario de alta empresa</h1>
                </div>
            </div>
            <div class="box-content">
                <p style="font-size:14px">
                    Publica tus ofertas de empleo gratis sólo por registrarte Encuentra profesionales sanitarios para tus procesos de selección.<br /><br />
                    Tu primer candidato gratis.<br /><br />
                </p>
                <form name="customform" id="customform" action="guardaremp2.php" method="post" >
                    <div class="form-errors"></div>
                    <div class="width-100">
	                    <div class="width-50 registro-usuario registro-empresa">
	                        <label for="razon" class="required">Razón Social</label>
	                        <input type="text" id="social" name="social"   class="text-input-border">
	                        	                    </div>
	                </div>
	                <div class="width-100">
	                	<div class="width-50 registro-usuario registro-empresa">
	                        <label for="mediempleo_empresabundle_registroempresatype_email_first" class="required">Correo</label>
	                        <input type="text" id="correo" name="correo" class="text-input-border" />
	                        	                    </div>
	                    <div class="width-50 registro-usuario registro-empresa">
	                        <label for="direccion" class="required">Dirección</label>
	                        <input type="text" id="dir" name="dir" class="text-input-border" />
	                        	                    </div>
	                </div>

                    <div class="width-100">
	                	<div class="width-50 registro-usuario registro-empresa">
	                        <label for="calle" class="required">Nº Calle</label>
	                        <input type="text" id="num" name="num" class="text-input-border" />
	                        	                    </div>
	                    <div class="width-50 registro-usuario registro-empresa">
	                        <label for="direccion" class="required">Piso</label>
	                        <input type="text" id="piso" name="piso" class="text-input-border" />
	                        	                    </div>
	                </div>


<div class="width-100">
	                	<div class="width-50 registro-usuario registro-empresa">
	                        <label for="mediempleo_empresabundle_registroempresatype_email_first" class="required">Departamento</label>
	                        <input type="text" id="dep" name="dep" class="text-input-border" />
	                        	                    </div>
	                    <div class="width-50 registro-usuario registro-empresa">
	                        <label for="direccion" class="required">Código Postal</label>
	                        <input type="text" id="cp" name="cp" class="text-input-border" />
	                        	                    </div>
	                </div>



<div class="width-100">
	                	<div class="width-50 registro-usuario registro-empresa">
	                        <label for="localidad" class="required">Localidad</label>
	                        <input type="text" id="loc" name="loc" class="text-input-border" />
	                        	                    </div>
	                    <div class="width-50 registro-usuario registro-empresa">
	                        <label for="provincia">Provincia</label>
	                        <input type="text" id="provincia" name="provincia" class="text-input-border" />
	                        	                    </div>
	                </div>

<div class="width-100">
	                	<div class="width-50 registro-usuario registro-empresa">
	                        <label for="localidad" class="required">Matrícula Nacional</label>
	                        <input type="text" id="nacional" name="nacional" class="text-input-border" />
	                        	                    </div>
	                    <div class="width-50 registro-usuario registro-empresa">
	                        <label for="provincia">Matrícula Provincial</label>
	                        <input type="text" id="provincial" name="provincial" class="text-input-border" />
	                        	                    </div>
	                </div>



	                <div class="width-100">
	                	<div class="width-50 registro-usuario registro-empresa">
	                        <label for="contacto" class="required">Contacto</label>
	                        <input type="text" id="contacto" name="contacto"   class="text-input-border" />
	                        	                    </div>
	                    <div class="width-50 registro-usuario registro-empresa">
	                        <label for="tel" class="required">Teléfono Fijo</label>
	                        <input type="text" id="tel1" name="tel1"     class="text-input-border" />
	                        	                    </div>
	                </div>

	                <div class="width-100">
	                	<div class="width-50 registro-usuario registro-empresa">
	                        <label for="correo" class="required">Teléfono Celular</label>
	                        <input type="text" id="tel2" name="tel2" class="text-input-border" />
	                        	                    </div>
	                    <div class="width-50 registro-usuario registro-empresa">
	                                            </div>
	                </div>



	                <div class="width-100">
	                	<div class="width-50 registro-usuario registro-empresa">
	                        <label for="mediempleo_empresabundle_registroempresatype_contacto">Usuario</label>
                          
	                        <input type="text"  name="user2" id="user2"  class="text-input-border" onblur="consultar()">
	                        <div id="consi"></div>
                          </div>
                          
	                    <div class="width-50 registro-usuario registro-empresa">
	                    	<label for="pass" class="required">contraseña</label>
	                        <input type="password" id="pass2" name="pass2"  class="text-input-border" />
	                        	                    </div>
	                </div>
	                
	                <div class="width-100">
	                    <div class="width-50 registro-usuario registro-empresa">
	                        <label for="mediempleo_empresabundle_registroempresatype_opcionesTipo">Tipo de empresa</label>
	                        <select id="tipoem" name="tipoem"    class="select-centros"><option value="Centro de salud" selected="selected">Centro de salud</option><option value="Hospital">Hospital</option><option value="Clínica">Clínica</option><option value="Farmacia">Farmacia</option><option value="Geriátrico">Geriátrico</option><option value="Empresa">Empresa</option><option value="Selección de personal">Selección de personal</option><option value="Otros">Otros</option></select>
	                        	                    </div>
	                    <div class="width-50 registro-usuario registro-empresa" id="tipo-empresa" style="display:none">
	                        <label for="mediempleo_empresabundle_registroempresatype_tipo" class="required">Tipo</label>
	                        <input type="text" id="tipo" name="tipo"  value="Centro de salud" />
	                        	                    </div>
	                </div>
	                
                    <div class="width-100 registro-usuario registro-empresa">
                        <label for="mediempleo_empresabundle_registroempresatype_condiciones" class="condiciones">
                            Acepto las <a href="informacion-legal.php" target="_blank">condiciones de uso</a> y la <a href="politica-privacidad.php" target="_blank">política de privacidad</a> de MedicalJob
                        </label>
                        <input type="checkbox" id="mediempleo_empresabundle_registroempresatype_condiciones" name="mediempleo_empresabundle_registroempresatype[condiciones]"  value="1" />
                    </div>
                    <div class="form-widget-container">
                        <button type="submit" class="btn btn-danger">Registrarse</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div>
	<a href="publicar-ofertas.php" target="_blank">
		<div class="boton" style="background: #2BB100; width: 49%; overflow: hidden; float: left; margin-right: 14px; color: #fff; font-weight: bold; text-align: center; height: 60px; line-height: 60px;">Cómo Funciona?</div>
	</a>
	<a href="precios.html" target="_blank">
		<div class="boton" style="background: #2BB100; width: 49%; overflow: hidden; float: right; color: #fff; font-weight: bold; text-align: center; height: 60px; line-height: 60px; margin-top: -1px;">Cuanto Cuesta?</div>
	</a>
			</div>
		</div>
		</div>
		<footer id="footer">	
	<div id="container-footer-especialidades">
			<div class="footer-box">
			
		</div>
			<div class="footer-box">
			
		</div>
			<div class="footer-box">
			
		</div>
			<div class="footer-box">
			
		</div>
			<div class="footer-box">
			
		</div>
			<div class="footer-box">
			
		</div>
		
		
	</div>
	<div id="footer-aside">
		<div class="footer-box">
			
		</div>
		<div class="footer-box">
			
		</div>
		<figure id="logo-footer">
			<img class="img-responsive img-thumbnail" src="img/log.jpg" alt="Logo de MedicalJob" title="MedicalJob, tu web de empleo médico" width="90%" />
		</figure>
		<div id="info-footer">
			<b>Copyright &copy; 2018 </b><br />
			<a href="informacion-legal.php">Información legal</a><br />
			<a href="politica-privacidad.php">Política de privacidad</a> |
			<a href="normativa.php">Normativa</a> |
			<a href="contacto.php">Contacto</a>
			
		</div>	
	</div>
	
		
</footer>	</div>
  
    <!-- FUNCION QUE COMPRUEBA EL NOMBRE DE USUARIO -->    
<script src="js2/router.js"></script>
  <script src="js2/routing?callback=fos.Router.setData"></script>
  <script src="js2/jquery-1.9.1.min.js"></script>
    <script src="js2/jquery-ui-1.10.3.custom.min.js"></script>
  <script src="js2/frontend.js"></script>
  <script src="js2/bootstrap.js"></script>
    <script src="js2/angular.min.js"></script>
    <script src="js2/ng-table.js"></script>
  <script type="text/javascript" src="js2/jquery.fancybox.pack.js"></script>

 <!-- FUNCION QUE COMPRUEBA EL NOMBRE DE USUARIO -->
             
        
    </body>
</html>
