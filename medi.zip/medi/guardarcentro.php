<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
session_start();
$x = "";
$pais = "";
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}



if (isset($_POST["nombre"])) {
	$nombre = utf8_decode($_POST["nombre"]);
}


if (isset($_POST["direccion"])) {
	$direccion = utf8_decode($_POST["direccion"]);
}


if (isset($_POST["tipo"])) {
	$tipo2 = utf8_decode($_POST["tipo"]);
}



if (isset($_POST["telefono"])) {
	$telefono = $_POST["telefono"];
}



if (isset($_POST["cmbpais2"]) ) {
  $pais2 = utf8_decode($_POST["cmbpais2"]);

 $x = array();
$sql = "SELECT * FROM pais WHERE id ='".$pais2."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { 

$x[0] = $row->paisnombre;
}

$pais = $x[0];
$pais = utf8_decode($pais);


  }

   

if (isset($_POST["cmbciudad2"])) {
   $ciudad = utf8_decode($_POST["cmbciudad2"]);
}



if (isset($_POST["descripcion"])) {
	$descripcion = utf8_decode($_POST["descripcion"]);
}

if (isset($_POST["NombreContacto"])) {
  $contacto = utf8_encode($_POST["NombreContacto"]);
}


if (isset($_POST["Correocontacto"])) {
  $correo = utf8_decode($_POST["Correocontacto"]);
}


if (isset($_POST["telefonoContacto"])) {
  $tel = $_POST["telefonoContacto"];
}





$nombre_img = $_FILES['archivo']['name'];
$tipo = $_FILES['archivo']['type'];
$tamano = $_FILES['archivo']['size'];
 
//Si existe imagen y tiene un tamaño correcto
if (($nombre_img == !NULL) && ($_FILES['archivo']['size'] <= 800000)) 
{
   //indicamos los formatos que permitimos subir a nuestro servidor
   if (($_FILES["archivo"]["type"] == "image/gif")
   || ($_FILES["archivo"]["type"] == "image/jpeg")
   || ($_FILES["archivo"]["type"] == "image/jpg")
   || ($_FILES["archivo"]["type"] == "image/png"))
   
      // Ruta donde se guardarán las imágenes que subamos
      $directorio = "./img/";
      // Muevo la imagen desde el directorio temporal a nuestra ruta indicada anteriormente
      move_uploaded_file($_FILES['archivo']['tmp_name'],$directorio.$nombre_img);
      $nombre_img = $directorio.$nombre_img;
   

$sql = "INSERT INTO centros (nombre,direccion, tipo,telefono,pais, ciudad,descripcion,NombreContacto,CorreoContacto,TelefContacto) VALUES (:nombre,:direccion,:tipo2, :telefono, :pais,:ciudad,:descripcion,:contacto,:correo, :tel)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt->bindParam(':direccion', $direccion, PDO::PARAM_STR);
$stmt->bindParam(':tipo2', $tipo2, PDO::PARAM_STR);
$stmt->bindParam(':telefono', $telefono, PDO::PARAM_STR); 
$stmt->bindParam(':pais', $pais, PDO::PARAM_STR); 
$stmt->bindParam(':ciudad', $ciudad, PDO::PARAM_STR);
$stmt->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
$stmt->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt->bindParam(':tel', $tel, PDO::PARAM_STR);
 
$stmt->execute();

 
$sql = "INSERT INTO perfil2 (usuario,img) VALUES (:usuario,:nombre_img)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':nombre_img', $nombre_img, PDO::PARAM_STR);

$stmt->execute();

 
}



?>

<script>
alert('El Centro a sido agregado exitosamaente');
window.location.href='nuevo-centro.php';
</script>

</body>
<html>