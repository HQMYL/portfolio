<?php


if (isset($_POST["usuario"])) 
$usuario = $_POST["usuario"];
if (isset($_POST["contraseña"])) 
    $pass = $_POST["contraseña"];


$con = new PDO("mysql:host=localhost;dbname=marketpro", "root", "");
$sth = $con->prepare("SELECT * FROM usuarios WHERE usuario = ? AND contrasena = ?");
$sth->bindParam(1, $usuario);
$sth->bindParam(2, $pass);
$sth->execute();

if ($sth->rowCount() > 0) {

foreach ($sth as $row ) {

	if ($row['tipo'] == 1) {
		session_start();
        $_SESSION['usuario'] = $usuario;
    header("Location: principal1.php");
} else if ($row['tipo'] == 2) {
	session_start();
	$_SESSION['usuario'] = $usuario;
    header("Location: principal2.php");
} else if ($row['tipo'] == 3) {
	session_start();
	$_SESSION['usuario'] = $usuario;
    header("Location: principal3.php");
}else if ($row['tipo'] == 4) {
	session_start();
	$_SESSION['usuario'] = $usuario;
    header("Location: principal4.php");
}




}
 

} else{
	header("Location: inmobiliaria.html");
	exit();
}

?>