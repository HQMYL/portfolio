<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
include("conexion.php");
$nombre = $_POST["nombre"];
$apellidos = $_POST["apellidos"];
$correo = $_POST["correo"];
$apellido = $_POST["apellido"];;
$direccion = $_POST["direccion"];
$identifi = $_POST["identifi"];
$user = $_POST["user"];
$contraseña = $_POST["contrasena"];
$tipo = $_POST["tipo"];
$suc = $_POST["suc"];



$sql = "INSERT INTO usuarios (GestorAlta, FechaAlta,nombre,apellido,direccion, DNI, usuario, contrasena, tipo, nombreSuc) VALUES (:personal, :fecha,:nombre, :apellido, :direccion, :identifi, :usuario, :contrasena, :tipo, :suc)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':personal', $personal, PDO::PARAM_STR);
$stmt->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR); 
$stmt->bindParam(':apellido', $apellido, PDO::PARAM_STR); 
$stmt->bindParam(':direccion', $direccion, PDO::PARAM_STR);
$stmt->bindParam(':identifi', $identifi, PDO::PARAM_STR);
$stmt->bindParam(':user', $user, PDO::PARAM_STR);
$stmt->bindParam(':contrasena', $contraseña, PDO::PARAM_STR);
$stmt->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt->bindParam(':suc', $suc, PDO::PARAM_STR); 
$stmt->execute();

?>

<script>
alert('El usuario a sido agregado exitosamaente');
window.location.href='nuevousuario.php';
</script>

</body>
<html>