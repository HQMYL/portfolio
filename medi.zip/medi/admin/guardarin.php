<!DOCTYPE HTML>
<html>
<head>
</head>
<body>
<?php


$piso = $_POST["piso"];
$direccion = $_POST["direccion"];
$departamento = $_POST["departamento"];
$localidad = $_POST["localidad"];
$barrio = $_POST["barrio"];
$pais = $_POST["pais"];
$propietario = $_POST["prop"];
$dni = $_POST["dni"];
$inqui = $_POST["inqui"];
$fecha = $_POST["fecha"];
$tipo = $_POST["tipo"];
$clasi = $_POST["clasi"];


$con = new PDO("mysql:host=localhost;dbname=marketpro", "root", "");
$sql = "INSERT INTO inmuebles (piso,direccion,Departamento,Localidad,Barrio, pais, propietario,Dnipropietario,inquilino,FechaIngreso, TipoInmueble,Clasificacion) VALUES (:direccion, :piso,:departamento, :localidad, :barrio, :pais, :propietario, :dni, :inqui, :fecha, :tipo, :clasi)";
$stmt = $con->prepare($sql);

$stmt->bindParam(':piso', $piso, PDO::PARAM_STR);
 $stmt->bindParam(':direccion', $direccion, PDO::PARAM_STR);
$stmt->bindParam(':departamento', $departamento, PDO::PARAM_STR);
$stmt->bindParam(':localidad', $localidad, PDO::PARAM_STR);
$stmt->bindParam(':barrio', $barrio, PDO::PARAM_STR);
$stmt->bindParam(':pais', $pais, PDO::PARAM_STR);
$stmt->bindParam(':propietario', $propietario, PDO::PARAM_STR);
$stmt->bindParam(':dni', $dni, PDO::PARAM_STR);
$stmt->bindParam(':inqui', $inqui, PDO::PARAM_STR);
$stmt->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt->bindParam(':clasi', $clasi, PDO::PARAM_STR); 
$stmt->execute();


?>
<script>
alert('El inmueble a sido agregado exitosamaente');
window.location.href='agregarinmueble.php';
</script>
</body>
</html>