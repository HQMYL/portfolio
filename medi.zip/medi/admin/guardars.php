<!doctype html>
<html>
<head>
</head>
<body>
<?php

if (isset($_POST["codigo"])) {
$codigo = $_POST["codigo"];
}

if (isset($_POST["direccion"])) {
$direccion = $_POST["direccion"];
}

if (isset($_POST["nombre"])) {
$nombre = $_POST["nombre"];
}

$con = new PDO('mysql:host=localhost;dbname=marketpro', 'root', '');
$sql = "INSERT INTO sucursales (Sucursalid, direccion, nombreSuc) VALUES (:codigo, :direccion, :nombre)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':codigo', $codigo, PDO::PARAM_STR); 
$stmt->bindParam(':direccion', $direccion, PDO::PARAM_STR);
$stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
 $stmt->execute();

?>

<script>
alert('La sucursal se a agregado exitosamaente');
window.location.href='agregarsucursal.php';
</script>
</body>
</html>