<!doctype html>
<html>
<head></head>
<body>
<?php

if (isset($_POST["codigo"])) {
$codigo = $_POST["codigo"];
}

if (isset($_POST["direccion"])) {
	$direccion = $_POST["direccion"];
}

if (isset($_POST["nombre"])) {
	$sucursal = $_POST["nombre"];
}


	
$con = new PDO('mysql:host=localhost;dbname=marketpro', 'root', '');

if (empty($direccion)){

$sql = " UPDATE sucursales SET nombreSuc =:sucursal WHERE Sucursalid =:codigo ";
$stmt = $con->prepare($sql);
$stmt->bindParam(':sucursal', $sucursal, PDO::PARAM_STR);
$stmt->bindParam(':codigo', $codigo, PDO::PARAM_INT);
$stmt->execute();

}



if (empty($sucursal)){ 
$sql = " UPDATE sucursales SET direccion=:direccion WHERE Sucursalid =:codigo ";
$stmt = $con->prepare($sql);
$stmt->bindParam(':direccion', $direccion, PDO::PARAM_STR);
$stmt->bindParam(':codigo', $codigo, PDO::PARAM_INT);
$stmt->execute();

}

?>
<script>
alert('La sucursal a sido actualizada exitosamaente');
window.location.href='actualizarsucursal.php';
</script>
</body>
</html>