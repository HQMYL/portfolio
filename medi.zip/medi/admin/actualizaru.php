<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
if (isset($_POST["usuario"])) {
	$buscar = $_POST["usuario"];
}

if (isset($_POST["apellido"])) {
	$buscar = $_POST["apellido"];
}



if (isset($_POST["direccion"])) {
	$direccion = $_POST["direccion"];
}

if (isset($_POST["sucursal"])) {
	$sucursal = $_POST["sucursal"];
}

if (isset($_POST["correo"])) {
	$contraseña = $_POST["correo"];
}


if (isset($_POST["tipo"])) {
	$tipo = $_POST["tipo"];
}


	


$con = new PDO('mysql:host=localhost;dbname=laro', 'root', '');


$sql = " SELECT * FROM usuarios WHERE usuario = '" .$buscar. "'";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
foreach ($rows as $row) {

if ( ($direccion == $row->direccion)  AND ($tipo == $row->tipo)  AND  ($contraseña == $row->CorreoE) ){

$sql2 = " UPDATE usuarios SET nombreSuc =:sucursal WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':sucursal', $sucursal, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

else

if ($tipo == $row->tipo AND $contraseña == $row->CorreoE AND $sucursal == $row->nombreSuc){
$sql2 = " UPDATE usuarios SET direccion =:direccion WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':direccion', $direccion, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}


if ($direccion == $row->direccion AND $tipo == $row->tipo AND $sucursal == $row->nombreSuc){

$sql2 = " UPDATE usuarios SET CorreoE =:contrasena WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':contrasena', $contraseña, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

else
	if ($contraseña == $row->CorreoE  AND $sucursal == $row->nombreSuc){
$sql2 = " UPDATE usuarios SET direccion =:direccion, tipo=:tipo WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':direccion', $direccion, PDO::PARAM_STR);
 $stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

else

if ($tipo == $row->tipo AND  $sucursal == $row->nombreSuc){
$sql2 = " UPDATE usuarios SET direccion =:direccion, CorreoE =:contrasena WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':direccion', $direccion, PDO::PARAM_STR);
 $stmt2->bindParam(':contrasena', $contraseña, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

else
	if ($direccion == $row->direccion  AND $sucursal == $row->nombreSuc){
$sql2 = " UPDATE usuarios SET tipo=:tipo, CorreoE =:contrasena WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR);
 $stmt2->bindParam(':contrasena', $contraseña, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}
else
	if ($contraseña == $row->CorreoE AND $sucursal == $row->nombreSuc){
$sql2 = " UPDATE usuarios SET direccion =:direccion, tipo=:tipo WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':direccion', $direccion, PDO::PARAM_STR);
 $stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

else
	if ($tipo == $row->tipo AND $sucursal == $row->nombreSuc ){
$sql2 = " UPDATE usuarios SET direccion =:direccion, CorreoE=:contrasena WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':direccion', $direccion, PDO::PARAM_STR);
 $stmt2->bindParam(':contrasena', $contraseña, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

else
if ($direccion == $row->direccion AND $sucursal == $row->nombreSuc){
$sql2 = " UPDATE usuarios SET tipo=:tipo, CorreoE=:contrasena WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR);
 $stmt2->bindParam(':contrasena', $contraseña, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

else

if ($direccion == $row->direccion AND $tipo == $row->tipo){
$sql2 = " UPDATE usuarios SET CorreoE =:contrasena, nombreSuc=:sucursal WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':contrasena', $contraseña, PDO::PARAM_STR);
$stmt2->bindParam(':sucursal', $sucursal, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

else
if ($tipo == $row->tipo AND $contraseña == $row->CorreoE){
$sql2 = " UPDATE usuarios SET direccion =:direccion, nombreSuc=:sucursal WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':direccion', $direccion, PDO::PARAM_STR);
 $stmt2->bindParam(':sucursal', $sucursal, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

else
if ($direccion == $row->direccion){ 
	

$sql2 = " UPDATE usuarios SET tipo=:tipo, CorreoE=:contrasena, nombreSuc =:sucursal WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR);
 $stmt2->bindParam(':contrasena', $contraseña, PDO::PARAM_STR);
$stmt2->bindParam(':sucursal', $sucursal, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

else
if ($tipo == $row->tipo){ 
	

$sql2 = " UPDATE usuarios SET direccion=:direccion, CorreoE=:contrasena, nombreSuc =:sucursal WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':direccion', $direccion, PDO::PARAM_STR);
 $stmt2->bindParam(':contrasena', $contraseña, PDO::PARAM_STR);
$stmt2->bindParam(':sucursal', $sucursal, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

else
if ($contraseña == $row->CorreoE){ 
	
$sql2 = " UPDATE usuarios SET direccion=:direccion, tipo =:tipo, nombreSuc =:sucursal WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':direccion', $direccion, PDO::PARAM_STR); 
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt2->bindParam(':sucursal', $sucursal, PDO::PARAM_STR); 
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

else
if ($sucursal == $row->nombreSuc){ 
	
$sql2 = " UPDATE usuarios SET direccion=:direccion, tipo=:tipo, CorreoE=:contrasena WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':direccion', $direccion, PDO::PARAM_STR);  
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt2->bindParam(':contrasena', $contraseña, PDO::PARAM_STR);
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}

else{
	$sql2 = " UPDATE usuarios SET direccion=:direccion, tipo=:tipo, CorreoE=:contrasena, nombreSuc=:sucursal WHERE usuario =:buscar ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':direccion', $direccion, PDO::PARAM_STR);  
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt2->bindParam(':contrasena', $contraseña, PDO::PARAM_STR);
$stmt2->bindParam(':sucursal', $sucursal, PDO::PARAM_STR);
$stmt2->bindParam(':buscar', $buscar, PDO::PARAM_STR);
$stmt2->execute();

}


}

?>
<script>
alert('La actualización fue realizada exitosamaente');
window.location.href='actualizacion.php';
</script>
</body>
</html>