<!DOCTYPE HTML>
<html>
<?php
include("inc/conexion.php");
?>
<body>
<?php

if (isset($_POST["colec"])) {
	$colec = $_POST["colec"];
}

if (isset($_POST["nombre"])) {
	$nombre = $_POST["nombre"];
}

if (isset($_POST["apellido1"])) {
	$apellido1 = $_POST["apellido1"];
}


if (isset($_POST["apellido2"])) {
	$apellido2 = $_POST["apellido2"];
}

if (isset($_POST["cmbpais"])) {
	$nac = $_POST["cmbpais"];
}


if (isset($_POST["correo"])) {
	$correo = $_POST["correo"];
}

if (isset($_POST["dir"])) {
	$dir = $_POST["dir"];
}

if (isset($_POST["user"])) {
	$usuario = $_POST["user"];
}

if (isset($_POST["pass"])) {
	$pass = $_POST["pass"];
}


if (isset($_POST["tipo"])) {
	$tipo = $_POST["tipo"];
}








$sql = " SELECT * FROM usuarios WHERE nombre = '" .$nombre. "'";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
foreach ($rows as $row) {

if( ( $colec == $row->colectivo)  AND ($usuario == $row->usuario) ) {

$sql2 = " UPDATE usuarios SET pass =:pass, pais =:nac, correo =:correo, dir =:dir WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':pass', $pass, PDO::PARAM_STR); 
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $colec == $row->colectivo)  AND ($nac == $row->pais) ) {

$sql2 = " UPDATE usuarios SET correo =:correo, dir =:dir, usuario =:usuario, pass =:pass WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR); 
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $colec == $row->colectivo)  AND ($correo == $row->correo) ) {

$sql2 = " UPDATE usuarios SET pais=:nac, dir=:dir,  usuario =:usuario, pass =:pass WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR); 
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $colec == $row->colectivo)  AND ($dir == $row->dir) ) {

$sql2 = " UPDATE usuarios SET pais=:nac, correo=:correo, usuario =:usuario, pass =:pass WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR); 
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $colec == $row->colectivo)  AND ($pass == $row->pass) ) {

$sql2 = " UPDATE usuarios SET pais=:nac, correo=:correo, dir =:dir, usuario =:usuario, tipo=:tipo  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $colec == $row->colectivo)  AND ($tipo == $row->tipo) ) {

$sql2 = " UPDATE usuarios SET pais=:nac, correo=:correo, dir =:dir, usuario =:usuario, pass=:pass  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}







if( ( $nac == $row->pais)  AND ($correo == $row->correo) ) {

$sql2 = " UPDATE usuarios SET colectivo=:colec, dir =:dir, usuario =:usuario, pass=:pass  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $nac == $row->pais)  AND ($dir == $row->dir) ) {

$sql2 = " UPDATE usuarios SET colectivo=:colec, correo =:correo, usuario =:usuario, pass=:pass  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $nac == $row->pais)  AND ($usuario == $row->usuario) ) {

$sql2 = " UPDATE usuarios SET colectivo=:colec, correo =:correo, dir =:dir, pass=:pass  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $nac == $row->pais)  AND ($pass == $row->pass) ) {

$sql2 = " UPDATE usuarios SET colectivo=:colec, correo =:correo, dir =:dir, usuario=:usuario  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}


if( ( $nac == $row->pais)  AND ($tipo == $row->tipo) ) {

$sql2 = " UPDATE usuarios SET colectivo=:colec, correo =:correo, dir =:dir, usuario=:usuario, pass=:pass  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}



if( ( $correo == $row->correo)  AND ($dir == $row->dir) ) {

$sql2 = " UPDATE usuarios SET colectivo=:colec, pais =:nac, usuario=:usuario,pass =:pass  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR);
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $correo == $row->correo)  AND ($usuario == $row->usuario) ) {

$sql2 = " UPDATE usuarios SET colectivo=:colec, pais =:nac, dir=:dir,pass =:pass  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR);
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR); 
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $correo == $row->correo)  AND ($pass == $row->pass) ) {

$sql2 = " UPDATE usuarios SET colectivo=:colec, pais =:nac, dir=:dir,usuario =:usuario, tipo=:tipo  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR);
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR); 
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $correo == $row->correo)  AND ($tipo == $row->tipo) ) {

$sql2 = " UPDATE usuarios SET colectivo=:colec, pais =:nac, dir=:dir,usuario =:usuario, pass=:pass  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR);
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR); 
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}




if( ( $dir == $row->dir)  AND ($usuario == $row->usuario) ) {

$sql2 = " UPDATE usuarios SET colectivo=:colec, pais =:nac, correo=:correo,pass =:pass, tipo=:tipo  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR);
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR); 
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $dir == $row->dir)  AND ($pass == $row->pass) ) {

$sql2 = " UPDATE usuarios SET colectivo=:colec, pais =:nac, correo=:correo,usuario =:usuario, tipo=:tipo  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR);
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR); 
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $dir == $row->dir)  AND ($tipo == $row->tipo) ) {

$sql2 = " UPDATE usuarios SET colectivo=:colec, pais =:nac, correo=:correo,usuario =:usuario, pass=:pass  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR);
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR); 
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}





if( ( $usuario == $row->usuario)  AND ($pass == $row->pass) ) {

$sql2 = " UPDATE usuarios SET colectivo=:colec, pais =:nac, correo=:correo,dir =:dir, tipo=:tipo  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR);
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR); 
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $usuario == $row->usuario)  AND ($tipo == $row->tipo) ) {

$sql2 = " UPDATE usuarios SET colectivo=:colec, pais =:nac, correo=:correo,dir =:dir, pass=:pass  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR);
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR); 
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}



if( ( $colec == $row->colec) AND ( $nac == $row->pais)  AND ($correo == $row->correo) ) {

$sql2 = " UPDATE usuarios SET dir =:dir,usuario =:usuario,pass=:pass, tipo=:tipo  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR); 
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $colec == $row->colec) AND ( $nac == $row->pais)  AND ($dir == $row->dir) ) {

$sql2 = " UPDATE usuarios SET correo =:correo,usuario =:usuario,pass=:pass, tipo=:tipo  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR); 
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR); 
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $colec == $row->colec) AND ( $nac == $row->pais)  AND ($usuario == $row->usuario) ) {

$sql2 = " UPDATE usuarios SET correo =:correo,dir =:dir,pass=:pass, tipo=:tipo  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR); 
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $colec == $row->colec) AND ( $nac == $row->pais)  AND ($pass == $row->pass) ) {

$sql2 = " UPDATE usuarios SET correo =:correo,dir =:dir,usuario=:usuario, tipo=:tipo  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR); 
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR); 
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( ( $colec == $row->colec) AND ( $nac == $row->pais)  AND ($tipo == $row->tipo) ) {

$sql2 = " UPDATE usuarios SET correo =:correo,dir =:dir,usuario=:usuario, tipo=:tipo  WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR); 
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR); 
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}


if( $colec == $row->colectivo) {

$sql2 = " UPDATE usuarios SET pais =:nac, dir=:dir,correo=:correo, usuario =:usuario, pass=:pass, tipo=:tipo WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':nac', $nac, PDO::PARAM_STR);
  $stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
   $stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
    $stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
 $stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
 $stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR); 
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}

if( $nac == $row->pais) {

$sql2 = " UPDATE usuarios SET colectivo =:colec, dir=:dir,correo=:correo, usuario =:usuario, pass=:pass, tipo=:tipo WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':colec', $colec, PDO::PARAM_STR);
  $stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
   $stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
    $stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
 $stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
 $stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR); 
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}




if( $correo == $row->correo) {

$sql2 = " UPDATE usuarios SET colectivo =:colec, pais=:nac, dir=:dir, usuario =:usuario, pass=:pass, tipo=:tipo WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':colec', $colec, PDO::PARAM_STR); 
 $stmt2->bindParam(':nac', $nac, PDO::PARAM_STR);
 $stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
 $stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}


if( $dir == $row->dir) {

$sql2 = " UPDATE usuarios SET colectivo =:colec, pais=:nac, correo=:correo, usuario =:usuario, pass=:pass, tipo=:tipo WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':colec', $colec, PDO::PARAM_STR); 
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->execute();

}



if( $usuario == $row->usuario) {

$sql2 = " UPDATE usuarios SET colectivo =:colec, pais=:nac, correo =:correo,  dir=:dir,  pass=:pass, tipo=:tipo WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR); 
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt2->execute();

}


if( $pass == $row->pass) {

$sql2 = " UPDATE usuarios SET colectivo =:colec, pais=:nac, correo =:correo,  dir=:dir,  usuario=:usuario, tipo=:tipo WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR); 
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt2->execute();

}

if( $tipo == $row->tipo) {

$sql2 = " UPDATE usuarios SET colectivo =:colec, pais=:nac, correo =:correo,  dir=:dir,  usuario=:usuario, pass=:pass WHERE nombre =:nombre ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colec', $colec, PDO::PARAM_STR); 
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->execute();

}

}



?>
<script>
	alert('El usuario a sido actualizado exitosamaente');
window.location.href='users.php';


</script>
</body>
</html>