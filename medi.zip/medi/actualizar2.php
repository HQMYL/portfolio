<!DOCTYPE HTML>
<html>
<?php
include("conexion.php");
?>
<body>
<?php

if (isset($_POST["cmbcolectivo"])) {
	$colec = $_POST["cmbcolectivo"];

$arri = array();
$col = utf8_decode($_POST["cmbcolectivo"]);

$sth = $con->prepare("SELECT * FROM colectivo WHERE id = ?");
$sth->bindParam(1, $col);

$sth->execute();

if ($sth->rowCount() > 0) {

foreach ($sth as $row ) {
$arri[0] = $row["nombre"];

}

$colectiv = $arri[0];
}


}

if (isset($_POST["cmbespec"])) {
	$espec = utf8_decode($_POST["cmbespec"]);
}



if (isset($_POST["nombre"])) {
	$nombre = $_POST["nombre"];
}

if (isset($_POST["apellido1"])) {
	$apellido1 = $_POST["apellido1"];
}


if (isset($_POST["apellido2"])) {
	$apellido2 = $_POST["apellido2"];
}

if (isset($_POST["nac"])) {
	$nac = $_POST["nac"];
}


if (isset($_POST["cmbpais"])) {
	$pais = $_POST["cmbpais"];
}

if (isset($_POST["correo"])) {
	$correo = $_POST["correo"];
}

if (isset($_POST["dir"])) {
	$dir = $_POST["dir"];
}

if (isset($_POST["ncalle"])) {
	$ncalle = $_POST["ncalle"];
}

if (isset($_POST["piso"])) {
	$piso = $_POST["piso"];
}


if (isset($_POST["dep"])) {
	$dep = $_POST["dep"];
}

if (isset($_POST["cp"])) {
	$cp = $_POST["cp"];
}


if (isset($_POST["loc"])) {
	$loc = $_POST["loc"];
}


if (isset($_POST["prov"])) {
	$prov = $_POST["prov"];
}

if (isset($_POST["tipo"])) {
	$tipo = $_POST["tipo"];
}

if (isset($_POST["user"])) {
	$usuario = $_POST["user"];
}

if (isset($_POST["pass"])) {
	$pass = $_POST["pass"];
}


if (isset($_POST["pagovisitas"])) {
	$pagovisitas = $_POST["pagovisitas"];
}


if (isset($_POST["pagocurri"])) {
	$pagocurri = $_POST["pagocurri"];
}

if (isset($_POST["curr1"])) {
	$curr1 = $_POST["curr1"];
}

if (isset($_POST["curr2"])) {
	$curr2 = $_POST["curr2"];
}

if (isset($_POST["id"])) {
	$id = $_POST["id"];
}


$sql2 = " UPDATE usuarios SET colectivo =:colectiv, especialidad =:espec, nombre=:nombre, apellido1=:apellido1, apellido2=:apellido2,Nacimiento=:nac,pais=:pais, correo =:correo,dir=:dir,Ncalle=:ncalle,piso=:piso,departamento=:dep,CodigoPostal=:cp, localidad =:loc,provincia=:prov, usuario=:usuario, pass=:pass, tipo=:tipo, creditos=:creditos,pagovisitas=:pagovisitas,pagocurri=:pagocurri, curr1=:curr1,curr2=:curr2 WHERE id =:id ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':colectiv', $colectiv, PDO::PARAM_STR); 
$stmt2->bindParam(':espec', $espec, PDO::PARAM_STR);
$stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt2->bindParam(':apellido1', $apellido1, PDO::PARAM_STR);
$stmt2->bindParam(':apellido2', $apellido2, PDO::PARAM_STR);
$stmt2->bindParam(':nac', $nac, PDO::PARAM_STR);
$stmt2->bindParam(':pais', $pais, PDO::PARAM_STR);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt2->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt2->bindParam(':ncalle', $ncalle, PDO::PARAM_STR);
$stmt2->bindParam(':piso', $piso, PDO::PARAM_STR);
$stmt2->bindParam(':dep', $dep, PDO::PARAM_STR);
$stmt2->bindParam(':cp', $cp, PDO::PARAM_STR);
$stmt2->bindParam(':loc', $loc, PDO::PARAM_STR);
$stmt2->bindParam(':prov', $prov, PDO::PARAM_STR);
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt2->bindParam(':creditos', $creditos, PDO::PARAM_STR);
$stmt2->bindParam(':pagovisitas', $pagovisitas, PDO::PARAM_STR);
$stmt2->bindParam(':pagocurri', $pagocurri, PDO::PARAM_STR);
$stmt2->bindParam(':curr1', $curr1, PDO::PARAM_STR);
$stmt2->bindParam(':curr2', $curr2, PDO::PARAM_STR);
$stmt2->bindParam(':id', $id, PDO::PARAM_STR);
$stmt2->execute();



?>
<script>
	alert('El usuario a sido actualizado exitosamaente');
window.location.href='consultarusuario.php';


</script>
</body>
</html>