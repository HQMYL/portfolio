<?php
include("conexion.php");

if (isset($_POST["id"])) {
	$pa = $_POST["id"];
}



 $sql = "SELECT * FROM ofertas";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

echo '<table class="table table-bordered table-hover">';
echo '<thead>';
echo '<tr>';

echo '<th>Colectivo</th>';
echo '<th>Puesto</th>';
echo '<th>Descripcion</th>';
echo '<th>Salario</th>';
echo '<th>País</th>';
echo '</tr>';
echo '</thead>';

foreach ($rows as $row) {



echo '<tbody>';
echo '<tr>';
 echo '<td>' .  utf8_encode($row->colectivo) . '</td>';
 echo '<td>' .  utf8_encode($row->puesto) . '</td>';
 echo '<td>' .  utf8_encode($row->descripcionPuesto) . '</td>';
 echo '<td>' .  utf8_encode($row->salario) . '</td>';
 echo '<td>' .  utf8_encode($row->pais) . '</td>';
 echo '</tr>';
 echo '</tbody>';
 echo '</table>';

}

 ?>