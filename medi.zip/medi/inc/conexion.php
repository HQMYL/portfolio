<?php 


try {
  $con = new PDO("mysql:host=localhost;dbname=marketpro", "root", "");
  $con->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
  $con->query("SET NAMES 'utf-8'");
  
} catch (Exception $e) {
    echo "No se ha podido conectar con la base de datos";
    exit();
}
return $con;


?>

