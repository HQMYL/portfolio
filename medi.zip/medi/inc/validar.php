<?php
session_start();


include('./conexion.php');
if (isset($_POST['usuario'])) {
$usuario = $_POST['usuario'];
}
if (isset($_POST['contraseña'])) {
	$pass = $_POST['contraseña'];
}


 $sql = "SELECT tipo FROM usuarios WHERE usuario == '$usuario' AND contrasena ==  '$pass'";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
foreach ($rows as $row) {
   

	if($row->tipo == 1) {
	header("Location: principal1.html");
exit();
}

if($row->tipo == 2) {
	header("Location: principal2.html");
	exit();
} 

if($row->tipo == 3) {
	header("Location: principal3.html");
}

if($row->tipo == 4) {
	header("Location: principal4.html");
	exit();
} 

else {

	header("Location: inmobiliaria.php");
exit();	
}

}



?>