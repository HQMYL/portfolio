<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
require("conexion.php");
$nombre = $_POST["nombre"];
$apellido = $_POST["apellido"];;
$direccion = $_POST["direccion"];
$identifi = $_POST["identifi"];
$usuario = $_POST["usuario"];
$contraseña = $_POST["contrasena"];

$sql = "INSERT INTO usuarios (nombre,apellido,direccion, identificacion, usuario, contrasena) VALUES
(:nombre, :apellido, :direccion, :identifi, :usuario, :contrasena)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR); 
$stmt->bindParam(':apellido', $apellido, PDO::PARAM_STR); 
$stmt->bindParam(':direccion', $direccion, PDO::PARAM_STR);
$stmt->bindParam(':identifi', $identifi, PDO::PARAM_STR);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':contrasena', $contraseña, PDO::PARAM_STR); 
$stmt->execute();

?>

<script>
alert('El usuario a sido agregado exitosamaente');
window.location.href='nuevousuario.php';
</script>

</body>
<html>