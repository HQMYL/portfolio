<html lang="es">
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
?>

    <head>
        <meta charset="UTF-8" />
		<meta name="description" content="	MedicalJob, bolsa de empleo con ofertas de trabajo, congresos y cursos de enfermera, médico y auxiliar en enfermería en el sector de salud
" />
		        <title>Mi Currículum</title>
        <!--[if lt IE 9]>
        	<script src="/bundles/comun/js/html5shiv.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
                <link rel="stylesheet" type="text/css" href="css2/css.css" />
        		<link rel="stylesheet" type="text/css" href="css2/reset.css" />
    <link rel="stylesheet" type="text/css" href="css2/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css2/frontend.css" />
	<link rel="stylesheet" type="text/css" href="css2/forms.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery-ui-1.10.3.custom.min.css" />

	<link rel="stylesheet" type="text/css" href="css2/usuario.css" />
    <link rel="stylesheet" type="text/css" href="css2/jquery.fancybox.css" />
	<link rel="stylesheet" type="text/css" href="css2/extranet.css" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="apple-touch-icon" sizes="114x114" href="" />
        <link rel="apple-touch-icon" sizes="72x72" href="" />
        <link rel="apple-touch-icon" href="" />
        <style type="text/css">
            .btn, .btn-danger {
    float: right;
  }
.menu-titulo {
        
        background-image: url("img/flecha.png");
        
    }


        </style>
    </head>
    <body itemscope itemtype="http://schema.org/WebPage">
		<div id="cargando" style="display:none"></div>
		    				        	<div id="pagina">
		<header id="header">
			<div id="banner">
				<img class="img-responsive" src="img/portada.jpg" 
					 alt="MedicalJob: Trabaja en el sector médico en cualquier parte del mundo"
					 title="MedicalJob: Trabaja en el sector médico en cualquier parte del mundo" />
			</div>
					</header>
		<div id="contenido">
			<div id="breadcrumb" itemprop="breadcrumb">
									<a href="seccion-usuarios.php"><span class="glyphicon glyphicon-home"></span> Inicio</a> >
											<a href="seccion-usuarios.php">Mi Cuenta</a> >
					 
				 Mi Currículum			</div>
					
			<aside id="sidebar">
				<div id="cuadro-sesion">
	<p><em>BIENVENIDO</em> <span class="green">
			<?php echo $usuario; ?></span><br />
		<em>Tiene 0 mensajes en su <a class="blue" href="mis-mensajes.php">Inbox</a></em>
			</p>
	<p id="cuadro-sesion-saldo">
        <?php
        $sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { ?>
			<em>Saldo actual: <span class="green" id="cuadro-sesion-puntos"><?php echo $row->creditos;?>  créditos</span></em>
		</p>
				<img class="img-responsive img-thumbnail" src="img/default (1).png"
			 alt="Kal El" 
			 title="Kal El" 
			 width="70" style="float: left; margin: 5px 20px" />
		<a class="button button-blue" href="listado-ofertas.php">OFERTAS</a>
		<a class="button button-grey" href="logout.php">SALIR</a>
</div>				                    <div id="menu-usuario" class="menu-lateral">
	<ul id="menu-box">
		<li class="menu-titulo" data-target="submenu-datos">Mi cuenta</li>
		<li class="submenu" id="submenu-datos">
			<ul>
				<li><a href="mis-datos-acceso.php">Mis Datos de Acceso</a></li>
				<li><a href="datos-personales.php">Mis Datos Personales</a></li>
				<li><a href="curriculum.php">Mi Currículum</a></li>
				<li><a href="recomendar-usuario.php">Recomendar MedicalJob</a></li>
                <li><a href="acciones-avanzadas.php">Acciones avanzadas</a></li>
				<li><a href="eliminar-cuenta-usuario.php">Darme de baja</a></li>
			</ul>
		</li>
		<li class="menu-titulo" data-target="submenu-ofertas">Ofertas</li>
		<li class="submenu" id="submenu-ofertas">
			<ul>
				<li><a href="listado-ofertas2.php">Buscar ofertas</a></li>
				<li><a href="mis-ofertas.php">Ver mis candidaturas</a></li>
			</ul>
		</li>
		<li class="menu-titulo" data-target="submenu-inbox">Inbox</li>
		<li class="submenu" id="submenu-inbox">
			<ul>
				<li><a href="mis-mensajes.php">Ver mis mensajes</a></li>
				<li><a href="ajustes-imbox.php">Cambiar mis ajustes de Inbox</a></li>
			</ul>
		</li>
        <li class="menu-titulo" data-target="submenu-puntos">Créditos</li>
        <li class="submenu" id="submenu-puntos">
            <ul>
                <li><a href="comprar-creditos.php">Comprar</a></li>
                <li><a href="historial.php">Histórico de compras</a></li>
            </ul>
        </li>
	</ul>
</div>


<div id="curriculum-vista-previa" class="menu-lateral">
	<a href="/usuarios/curriculum-vista-previa" class="button button-blue" target="_blank">Vista previa</a>
</div>
	
<div id="progressbar-curriculum">
	<p></p>	<h3></h3><br />
	<div class="progress">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
			<span class="sr-only"></span>
		</div>
	</div>
	<p>
		Quieres mejorar tu currículum?<br />
		<a href="mi-curriculum">
			Haz click aquí<br />
			<img 
				src="img/edit_curriculum.png" 
				alt="Modificar mi curriculum" 
				title="Modificar mi curriculum" 
				width="32" 
				height="32"
			/>
		</a>
	</p>
</div>																
					<img width="200" height="200" src="img/master250x250.jpg">
				
			</aside>
		
			<div id="content-right">
				<div style="float:left;width:100%">
	</div>									<div id="publi-empresa">
						<a href="/wiki-usuarios" style="margin-left:0px">
							<img src="img/como-funcionan-los-creditos.jpg" 
							 	 alt="Como funcionan los créditos de MedicalJob"
							 	 title="Como funcionan los créditos de MedicalJob" />
						</a>
												<a href="/ofertas-trabajo/profesional-sanitario">
							<img src="img/busca-tu-trabajo.jpg" 
								 alt="Busca tu trabajo en MedicalJob"
								 title="Busca tu trabajo en MedicalJob"
								 style="float:right;margin-right:5px" />
						</a>
					</div>
									
    <div class="mediempleo-box">
        <div class="content">
            <div class="box-header">
                <div class="box-title">
                    <h1>CURRÍCULUM VITAE</h1>
                </div>
            </div>
            <div class="box-content">
                <fieldset>
                    <legend>Datos personales</legend>
                    <div class="form-errors"></div>
                    <form class="curriculum" action="guardarcurri.php" enctype="multipart/form-data" method="post">										
                        <div class="width-75">
                            <div id="imagen-curriculum">
                            	 <?php
         $sql = "SELECT * FROM curriculum WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as  $row) { ?>                                
                                <img id="avatar" src="<?php echo $row->img; ?>" width="80"  height="80" /><br />
                                <?php }?>
                                                                                        </div>
                            <div class="width-75" style="margin-left:20px">
                                <p style="width:100%">
                                    Puedes cambiar de foto las veces que quieras, recuerda que es importante tener tu currículum actualizado y con todos los campos
                                    posibles cumplimentados.
                                </p>
                                <input type="file" id="archivo" name="archivo" style="float:left" />
                                
                                <small style="float:left;margin-top:8px;margin-left:13px">(*) el tamaño máximo de la foto son 5MB</small>
                            </div>
                        </div>
                        <div id="porcentaje-curriculum">
                            Completado el<br />
                            <span id="texto-porcentaje" style="font-size:26px;color:green;">0 %</span><br />
                            de tu currículum
                        </div>
                        <div class="width-100">
							<div class="alert alert-warning" style="text-align:center;margin-bottom:0;margin-top:10px;width:93%;">
								<b>RECUERDA:</b> No está permitido por los términos y condiciones de Mediempleo publicar números de teléfono.<br />
								<b>Mediempleo</b> se reserva el derecho de <u>inhabilitar cualquier perfil que no respete esta condición.</u>
							</div>
						</div>
                        <div class="width-100">
                            <label for="presentacion">Presentación</label>
                            <textarea id="pres" name="pres"></textarea>
                        </div>
                        <div class="width-100">
                            <div class="width-50 titulacion">
                                <label for="curriculum_titulacion">Titulación</label>
                                <input type="text" id="titulacion" name="titulacion"    style="-webkit-logical-height: 24px" />
                            </div>
                            <div class="width-50 universidad">
                                <label for="curriculum_universidad">Universidad</label>
                                <input type="text" id="univer" name="univer"    style="-webkit-logical-height: 24px" />
                            </div>
                        </div>
                        <div class="width-75">
                            ¿Estudios finalizados?
                            <input type="checkbox" checked="checked" name="terminado" id="terminado" />
                        </div>
                        <div class="width-100">
                            
                            <div id="anyo-finalizacion" class="width-33">
                                <label for="curriculum_anyo">Año finalización</label>
                                <input type="text" id="anyo" name="anyo"    style="-webkit-logical-height: 24px" />
                            </div>
                            <div class="width-10 colegiado">
                                <label for="curriculum_colegiado" class="required">Colegiado?</label>
                                <select id="colegiado" name="colegiado"><option value="Sí">Sí</option><option value="No">No</option></select>
                            </div>
                            <div class="width-33 curriculum_numColegiado " >                            
                                <label for="curriculum_numColegiado">Número de colegiado</label>
                                <input type="text" id="numcol" name="numcol"    style="-webkit-logical-height: 24px" />
                            </div>
                        </div>
                        <div class="width-100">
                            <label for="curriculum_hobbies">Hobbies</label>
                            <textarea id="hobbies" name="hobbies"></textarea>
                        </div>

                        <div>
                            
                            <button type="submit" class="btn btn-danger">Actualizar Curriculum</button>
                        </div>
                    </form>
                </fieldset>
                    
                <fieldset style="margin-left:10px">
                    <legend style="margin-top:27px;float: right; width: 92%;">Formación especializada</legend>
                    <img src="/bundles/usuario/img/graduation_cap-32.png" style="float:left;margin-top:35px"/>
                        <form id="form-especialidad" class="curriculum" action="guardaresp.php"  method="post" >
                            <div class="width-100 especialidad-curriculum">
                                <label for="especialidad_curriculum_especialidad" class="required">Especialidad</label>
                                <select id="cmbespec" name="cmbespec"><option value="Analisis Clinicos">Análisis Clínicos</option><option value="Bioquímica Clínica">Bioquímica Clínica</option><option value="Farmacia">Farmacia</option><option value="Farmacia Hospitalaria">Farmacia Hospitalaria</option><option value="Farmacia Industrial y Galénica">Farmacia Industrial y Galénica</option><option value="Inmunología">Inmunología</option><option value="Microbiología y Parasitología Clínicas">Microbiología y Parasitología Clínicas</option><option value="Radiofarmacia Hospitalaria">Radiofarmacia Hospitalaria</option></select>
                                
                            </div>
                            <div class="width-25 especialidad-curriculum">
                                <label for="especialidad_curriculum_anyoObtencion" class="required">Año Obtencion</label>
                                <input type="text" id="anyoob" name="anyoob"  maxlength="4" style="-webkit-logical-height: 24px" />
                                
                            </div>
                            <div class="width-25 especialidad-curriculum">
                                <label for="especialidad_curriculum_lugar" class="required">Lugar</label>
                                <input type="text" id="lugar" name="lugar" style="-webkit-logical-height: 24px" />
                                
                            </div>
                            <div class="width-25 especialidad-curriculum">
                                <label for="residencia" class="required">FIR</label>
                                <select id="residencia" name="residencia"><option value="No">No</option><option value="Sí">Sí</option></select>
                                
                            </div>
                            <div class="width-25 especialidad-curriculum">
                                <label for="especialidad_curriculum_pais" class="required">Pais</label>
                                <select  id="cmbpais" name="cmbpais">
            <option value="">Seleccione el Pais</option>

         <?php 
      
         $con = new PDO('mysql:host=localhost;dbname=reality4_medicaljob', 'medicaljob', '1Eqejf#i');
         $sql = "SELECT idpais, nombrepais FROM pais";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->nombrepais .'">'.utf8_encode ($row->nombrepais).'</option>';

        
    }

    ?>
</select>
                                
                            </div>
                            <div>
                                <button type="sumbit" class="btn btn-danger">Añadir</button>
                            </div>
                        </form><br>
                        <?php
         $sql = "SELECT * FROM formacion  WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as  $row) { ?>   

<table class="table table-bordered table-hover">
    <thead>
        <tr>
           <th>Especialidad</th>
           <th>Año</th>
           <th>Lugar</th>
           <th>FIR</th>
           <th>País</th>
            
        </tr>
    </thead>
<tbody>
<tr>
<td><?php echo utf8_encode($row->especialidad); ?></td>
<td><?php echo utf8_encode($row->Aobtencion); ?></td>
<td><?php echo utf8_encode($row->lugar); ?></td>
<td><?php echo utf8_encode($row->residencia); ?></td>
<td><?php echo utf8_decode($row->pais); ?></td>
</tr>
</tbody>

<?php } ?>
                        <table class="resultados-busqueda" id="tabla-especialidades">
                            <thead>
                              
                            </thead>
                            <tbody>
                                                            
                                                        </tbody>
                        </table>
                </fieldset>
                    
                <fieldset style="margin-left:10px">
                    <legend style="margin-top:27px;float: right; width: 92%;">Homologaciones</legend>
                    <img src="/bundles/usuario/img/purchase_order-32.png" style="float:left;margin-top:35px"/>
                    <form id="form-homologacion" class="curriculum" action="guardarhom.php"  method="post" >
                        <div class="width-33">
                            <label for="homologacion_region" class="required">Homologado para</label>
                            <input type="text" id="homologregion" name="homologregion" required="required"    style="-webkit-logical-height: 24px" />
                            <br><i>Ejemplo: Colombia, 2012</i>
                        </div>
                        <div class="width-33">
                            <label for="homologacion_anyo" class="required">Año</label>
                            <input type="text" id="homologanyo" name="homologanyo" maxlength="4" class="anyo-homo" style="-webkit-logical-height: 24px" />
                        </div>
                        <div>
                              <button type="sumbit" class="btn btn-danger">Añadir</button>            
                        </div>
                    </form>
                    <?php
         $sql = "SELECT * FROM homologacion  WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
?>
<table class="resultados-busqueda" id="tabla-homologaciones">
                        <thead>
                            <tr><th>Homologado para</th><th>Año</th><th></th></tr>
                        </thead>
<?php foreach ($rows as  $row) { ?>   
                    
                        <tbody>
                                                    <tr><td style="" colspan=""><?php echo utf8_encode($row->homologado); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->homologanyo); ?></td>


                                                    </tr>
                                                </tbody>
                                                <?php } ?>
                    </table>
                </fieldset>
                    
                <fieldset style="margin-left:10px">
                    <legend style="margin-top:27px;float: right; width: 92%;">Idiomas</legend>
                    <img src="img/diploma2-32.png" style="float:left;margin-top:35px"/>
                    <form id="form-idioma" class="curriculum" action="guardaridioma.php"  method="post" >
                        <div class="width-100 idioma-curriculum">
                            <label for="idioma_curriculum_idioma" class="required">Idioma</label>
                            <select  id="cmbidioma" name="cmbidioma">
            <option value="">Seleccione el Idioma</option>

         <?php 
      
         $con = new PDO('mysql:host=localhost;dbname=reality4_medicaljob', 'medicaljob', '1Eqejf#i');
         $sql = "SELECT idx, descripcion FROM cod_lenguaje_pais";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->descripcion .'">'.utf8_encode($row->descripcion).'</option>';

        
    }

    ?>
</select>
                            
                        </div>
                        <div class="width-33">
                            <label for="idioma_curriculum_nivelHablado" class="required">Nivel Hablado</label>
                            <select id="nivel1" name="nivel1"><option value="Bajo">Bajo</option><option value="Medio">Medio</option><option value="Alto">Alto</option><option value="Nativo">Nativo</option></select>
                            
                        </div>
                        <div class="width-33">
                            <label for="idioma_curriculum_nivelEscrito" class="required">Nivel Escrito</label>
                            <select id="nivel2" name="nivel2"><option value="Bajo">Bajo</option><option value="Medio">Medio</option><option value="Alto">Alto</option><option value="Nativo">Nativo</option></select>
                            
                        </div>
                        <div class="width-33">
                            <label for="idioma_curriculum_nivelLeido" class="required">Nivel Leido</label>
                            <select id="nivel3" name="nivel3"><option value="Bajo">Bajo</option><option value="Medio">Medio</option><option value="Alto">Alto</option><option value="Nativo">Nativo</option></select>
                            
                        </div>
                        <div>
                            <button type="submit" class="btn btn-danger">Agregar</button>
                        </div>
                    </form>
                    <?php
         $sql = "SELECT * FROM idioma  WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
?>
                    <table class="resultados-busqueda" id="tabla-idiomas">
                        <thead>
                            <tr><th>Idioma</th><th>Nivel Hablado</th><th>Nivel Escrito</th><th>Nivel Leído</th><th></th></tr>
                        </thead>
                        <?php foreach ($rows as  $row) { ?>   
                        <tbody>
                                                    <tr><td style="" colspan=""><?php echo utf8_encode($row->idioma); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->nivelA); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->nivelE); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->nivelL); ?></td>


                                                    </tr>
                                                </tbody>
                                                <?php } ?>
                    </table>
                </fieldset>
                    
                <fieldset style="margin-left:10px">
                    <legend style="margin-top:27px;float: right; width: 92%;">Experiencia laboral</legend>
                    <img src="img/doctor_suitecase-32.png" style="float:left;margin-top:35px"/>
                    <form id="form-experiencia" class="curriculum" action="guardarexperiencia.php"  method="post" >
                        <div class="width-33">
                            <label for="experiencia_laboral_curriculum_empresa" class="required">Empresa</label>
                            <input type="text" id="empresa" name="empresa" required="required"    style="-webkit-logical-height: 24px" />
                        </div>
                        <div class="width-33">
                            <label for="experiencia_laboral_curriculum_fechaInicio" class="required">Fecha Inicio</label>
                            <input type="text" id="fechaInicio" name="fechaInicio" required="required"    class="datepicker" style="-webkit-logical-height: 24px" />
                        </div>
                        <div class="width-33">
                            <label for="experiencia_laboral_curriculum_fechaFin">Fecha Fin</label>
                            <input type="text" id="fechaFin" name="fechaFin"    class="datepicker" style="-webkit-logical-height: 24px" />
                        </div>
                        <div class="width-33">
                            <label for="experiencia_laboral_curriculum_unidad" class="required">Unidad</label>
                            <input type="text" id="unidad" name="unidad" required="required"    style="-webkit-logical-height: 24px" />
                        </div>
                        <div class="width-33">
                            <label for="experiencia_laboral_curriculum_pais" class="required">País</label>
                            <select  id="cmbpais2" name="cmbpais2">
            <option value="">Seleccione el Pais</option>

         <?php 
      
         $con = new PDO('mysql:host=localhost;dbname=reality4_medicaljob', 'medicaljob', '1Eqejf#i');
         $sql = "SELECT idpais, nombrepais FROM pais";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->nombrepais .'">'.utf8_encode ($row->nombrepais).'</option>';

        
    }

    ?>
</select>
                        </div>
                        <div class="width-100">
                            <label for="experiencia_laboral_curriculum_funcion" class="required">Función</label>
                            <textarea id="funcion" name="funcion" required="required"    style="-webkit-logical-height: 24px"></textarea>
                        </div>
                        <div>
                            <button type="submit" class="btn btn-danger">Agregar</button>
                        </div>
                    </form>
                    <?php
         $sql = "SELECT * FROM experiencia  WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
?>
                    <table class="resultados-busqueda" id="tabla-experiencias">
                        <thead>
                            <tr><th>Empresa</th><th>Fecha Inicio</th><th>Fecha Fin</th><th>Unidad</th><th>Funcion</th><th>País</th><th></th></tr>
                        </thead>
                        <?php foreach ($rows as  $row) { ?>  s
                        <tbody>
                                                    <tr><td style="" colspan=""><?php echo utf8_encode($row->empresa); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->fechaInicio); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->fechaFinal); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->unidad); ?></td>
                                                        <td style="text-align:center;" colspan=""><?php echo utf8_encode($row->funcion); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_decode($row->pais); ?></td>



                                                    </tr>
                                                </tbody>
                                                <?php } ?>
                    </table>
                </fieldset>
                    
                <fieldset style="margin-left:10px">
                    <legend style="margin-top:27px;float: right; width: 92%;">Cursos</legend>
                    <img src="/bundles/usuario/img/diploma1-32.png" style="float:left;margin-top:35px"/>
                    <form id="form-curso" class="curriculum" action="guardarcurso.php"  method="post" >
                        <div class="width-100 curso-curriculum">
                            <label for="curso_curriculum_nombre" class="required">Curso</label>
                            <input type="text" id="curso" name="curso" required="required"    style="-webkit-logical-height: 24px" />
                            
                        </div>
                        <div class="width-25 info-curso">
                            <label for="curso_curriculum_lugar" class="required">Lugar</label>
                            <input type="text" id="lugar" name="lugar" required="required"    style="-webkit-logical-height: 24px" />
                            
                        </div>
                        <div class="width-25 info-curso">
                            <label for="curso_curriculum_horas" class="required">Horas</label>
                            <input type="text" id="horas" name="horas" required="required"    style="-webkit-logical-height: 24px" />
                            
                        </div>
                        <div class="width-25 info-curso">
                            <label for="curso_curriculum_creditos" class="required">Créditos</label>
                            <input type="text" id="creditos" name="creditos" required="required"    style="-webkit-logical-height: 24px" />
                            
                        </div>
                        <div class="width-25 info-curso">
                            <label for="curso_curriculum_fechaFin" class="required">Fecha Fin</label>
                            <input type="text" id="fechaFin" name="fechaFin" required="required"    class="datepicker" style="-webkit-logical-height: 24px" />
                            
                        </div>
                        <div>
                            <button type="submit" class="btn btn-danger">Agregar</button>
                        </div>
                    </form>
                    <?php
         $sql = "SELECT * FROM cursos  WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
?>
                    <table class="resultados-busqueda" id="tabla-cursos">
                        <thead>
                            <tr><th>Curso</th><th>Horas</th><th>Créditos</th><th>Fecha Fin</th><th>Lugar</th><th></th></tr>
                            
                        </thead>
                        <?php foreach ($rows as  $row) { ?> 
                        <tbody>
                                                    <tr><td style="" colspan=""><?php echo utf8_encode($row->curso); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->horas); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->creditos); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->fechafin); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->lugar); ?></td>



                                                    </tr>
                                                </tbody>
                                                <?php } ?>
                    </table>
                </fieldset>
                    
                <fieldset style="margin-left:10px">
                    <legend style="margin-top:27px;float: right; width: 92%;">¿Dónde quieres trabajar?</legend>
                    <img src="img/airport-32.png" style="float:left;margin-top:35px"/>
                    <form id="form-movilidad" class="curriculum" action="movilidad.php"  method="post" >
                        <div class="width-33">
                            <label for="movilidad_curriculum_pais" class="required">País</label>
                            <select  id="cmbpais2" name="cmbpais2">
            <option value="">Seleccione el Pais</option>

         <?php 
      
         $con = new PDO('mysql:host=localhost;dbname=reality4_medicaljob', 'medicaljob', '1Eqejf#i');
         $sql = "SELECT idpais, nombrepais FROM pais";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->nombrepais .'">'.utf8_encode ($row->nombrepais).'</option>';

        
    }

    ?>
</select>
                        </div>
                        <div class="width-33" id="prov-mov">
                            <label>Provincia</label>
                            <select id="cmbciudad2" name="cmbciudad2">
            <option value="">Seleccione la Ciudad</option>

         <?php 
      
         $con = new PDO('mysql:host=localhost;dbname=reality4_medicaljob', 'medicaljob', '1Eqejf#i');
         $sql = "SELECT * FROM localidad";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->nombrelocalidad .'">'.utf8_encode ($row->nombrelocalidad).'</option>';

        
    }

    ?>
</select>                        </div>
                        <div class="width-33" id="ciudad-mov" style="visibility:hidden">
                            <label>Ciudad</label>
                            <select id="select-ciudades" name="select-ciudad">
                                <option value="todas">Todas</option>
                            </select>
                        </div>
                        <div>
                            
                            <button type="submit" class="btn btn-danger">Agregar</button>
                        </div>
                    </form>
                    <?php
         $sql = "SELECT * FROM movilidad  WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
?>
                    <table class="resultados-busqueda" id="tabla-movilidad">
                        <thead>
                            <tr><th>País</th><th>Ciudad</th><th></th></tr>
                        </thead>
                        <?php foreach ($rows as  $row) { ?> 
                        <tbody>
                                                            <tr>
                                                                <td style="" colspan=""><?php echo utf8_encode($row->pais); ?></td>
                                                        <td style="" colspan=""><?php echo utf8_encode($row->ciudad); ?></td>
                                                        
                                                            </tr>
                                                    </tbody>
                                                    <?php } ?>
                    </table>
                </fieldset>
            </div>
        </div>
    </div>	

			</div>
		</div>
		<footer id="footer">	
	<div id="container-footer-especialidades">
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Medicina</li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-alergologia/">Alergología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-analisis-clinicos/">Analisis Clínicos</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-anatomia-patologica/">Anatomia Patológica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-anestesiologia-y-reanimacion/">Anestesiología y Reanimación</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-angiologia-y-cirugia-vascular/">Angiología y Cirugía Vascular</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-aparato-digestivo/">Aparato Digestivo</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-bioquimica-clinica/">Bioquímica Clínica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cardiologia/">Cardiología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-cardiovascular/">Cirugía Cardiovascular</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-general-y-del-aparato-digestivo/">Cirugía General y del Aparato Digestivo</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-maxilofacial/">Cirugía Maxilofacial</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-oral-y-maxilofacial/">Cirugía Oral y Maxilofacial</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-pediatrica/">Cirugía Pediátrica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-plastica-estetica-y-reparadora/">Cirugía Plástica Estética y Reparadora</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-plastica-y-reconstructiva/">Cirugía Plástica y Reconstructiva</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-cirugia-toracica/">Cirugía Toracica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-dermatologia/">Dermatología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-endocrinologia-y-nutricion/">Endocrinología y Nutricion</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-farmacologia-clinica/">Farmacología Clínica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-geriatria/">Geriatria</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-hematologia-y-hemoterapia/">Hematología y Hemoterapia</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-hidrologia-y-balneoterapia/">Hidrología y Balneoterapia</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-inmunologia/">Inmunología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-de-la-educacion-fisica/">Medicina De La Educación Física</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-del-trabajo/">Medicina del Trabajo</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-educacion-fisica/">Medicina Educación Física</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-familiar-y-comunitaria/">Medicina Familiar y Comunitaria</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-fisica-y-rehabilitacion/">Medicina Física y Rehabilitación</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-intensiva/">Medicina Intensiva</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-interna/">Medicina Interna</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-legal-y-forense/">Medicina Legal y Forense</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-nuclear/">Medicina Nuclear</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina-preventiva-y-salud-publica/">Medicina Preventiva y Salud Pública</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-microbiologia-y-parasitologia/">Microbiología y Parasitología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-nefrologia/">Nefrología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-neumologia/">Neumología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-neurocirugia/">NeuroCirugía</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-neurofisiologia-clinica/">Neurofisiología Clínica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-neurologia/">Neurología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-obstetricia-y-ginecologia/">Obstetricia y Ginecología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-oftalmologia/">Oftalmología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-oncologia-medica/">Oncología Médica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-oncologia-radioterapeutica/">Oncología Radioterapéutica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-oncologia-radioterapica/">Oncología Radioterápica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-otorrinolaringologia/">Otorrinolaringología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-pediatria-y-areas-especificas/">Pediatría y Áreas Específicas</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-psiquiatria/">Psiquiatría</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-radiodiagnostico/">Radiodiagnóstico</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-reumatologia/">Reumatología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-traumatologia-y-cirugia-ortopedica/">Traumatología y Cirugía Ortopédica</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-urologia/">Urología</a></li>
									<li>> <a href="/ofertas-trabajo/medicina/medico-medicina/">Medicina</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Enfermería</li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-obstetrico-ginecologica-matrona/">Enfermería Obstétrico – Ginecológica (Matrona)</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-de-salud-mental/">Enfermería de Salud Mental</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-geriatrica/">Enfermería Geriátrica</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-del-trabajo/">Enfermería del Trabajo</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-de-cuidados-medico-quirurgicos/">Enfermería de Cuidados Médico – Quirúrgicos</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-familiar-y-comunitaria/">Enfermería Familiar y Comunitaria</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria-pediatrica/">Enfermería Pediátrica</a></li>
									<li>> <a href="/ofertas-trabajo/enfermeria/enfermeria-enfermeria/">Enfermería</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Farmacia</li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-analisis-clinicos/">Análisis Clínicos</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-bioquimica-clinica/">Bioquímica Clínica</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-farmacia-hospitalaria/">Farmacia Hospitalaria</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-microbiologia-y-parasitologia-clinicas/">Microbiología y Parasitología Clínicas</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-radiofarmacia-hospitalaria/">Radiofarmacia Hospitalaria</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-farmacia-industrial-y-galenica/">Farmacia Industrial y Galénica</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-inmunologia/">Inmunología</a></li>
									<li>> <a href="/ofertas-trabajo/farmacia/farmacia-farmacia/">Farmacia</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Técnico auxiliar de farmacia</li>
									<li>> <a href="/ofertas-trabajo/tecnico-auxiliar-de-farmacia/farmacia-auxiliar-de-farmacia/">Auxiliar de farmacia</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Auxiliar de enfermería</li>
									<li>> <a href="/ofertas-trabajo/auxiliar-de-enfermera/enfermeria-auxiliar-de-enfermeria/">Auxiliar de enfermería</a></li>
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Otras Ofertas</li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-indeed/">Seleccion Indeed</a></li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-infojobs-medicina-general/">Selección Infojobs Medicina General</a></li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-infojobs-medicina-especializada/">Selección Infojobs Medicina Especialista</a></li>
									<li>> <a href="/ofertas-trabajo/otras-ofertas/seleccion-infojobs-enfermeria/">Selección Infojobs Enfermería</a></li>
							</ul>
		</div>
		
		
	</div>
	<div id="footer-aside">
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Empleo Público</li>
				<li><a href="/publicaciones/1">Publicaciones</a></li>
				<li><a href="/oposiciones/1">Oposiciones</a></li>
			</ul>
		</div>
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title">Networking</li>
				<li>
					<a target="_blank" title="Perfil de Mediempleo en Linkedin" href="http://www.linkedin.com/company/mediempleo/">Linkedin</a>
				</li>
				<li>
					<a target="_blank" title="Twitter de Mediempleo" href="https://twitter.com/MediEmpleoTweet">Twitter</a>
				</li>
				<li>
					<a href="/links-interesantes">Links interesantes</a>
				</li>
			</ul>
		</div>
		<figure id="logo-footer">
			<img class="img-responsive img-thumbnail" src="img/log.jpg" alt="Logo de MedicalJob" title="MedicalJob, tu web de empleo médico" width="90%" />
		</figure>
		<div id="info-footer">
			<b>Copyright &copy; 2018 </b><br />
			<a href="/informacion-legal">Información legal</a><br />
			<a href="/politica-privacidad">Política de privacidad</a> |
			<a href="/normativa">Normativa</a> |
			<a href="/contacto">Contacto</a>
		</div>	
	</div>
	
		
</footer>	</div>
                <script type="text/javascript">
	  		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
				(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
				m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
			ga('create', 'UA-40029850-1', 'mediempleo.com');
			ga('send', 'pageview');
		</script>
        		<script src="/bundles/fosjsrouting/js/router.js"></script>
	<script src="js2/routing?callback=fos.Router.setData"></script>
	<script src="js2/jquery-1.9.1.min.js"></script>
    <script src="js2/jquery-ui-1.10.3.custom.min.js"></script>
	<script src="js2/frontend.js"></script>
	<script src="js2/bootstrap.js"></script>
			<script src="js2/usuario.js"></script>
	 

    <script src="/bundles/comun/js/jquery.fancybox.pack.js"></script>
	<script type="text/javascript" src="/bundles/usuario/js/usuario.js"></script>
	<script type="text/javascript" src="/bundles/usuario/js/curriculum.js"></script>
        <script type="text/javascript">
			$(document).ready(function(){
				$("#acepta-cookies").on("click", function(){
					var dias = 365*60*60*24*1000;
					var hoy = new Date();
			        var fecha_expira = new Date( hoy.getTime() + (dias) );
			        var cookieString = "cookies_agreement=1" + ";expires=" + fecha_expira.toGMTString();
					window.document.cookie = cookieString
					$("#cookies-bar").css('position','relative')
					$("#cookies-bar").slideDown(1200, function(){
						$(this).remove();
					});
				});

				$("#select-usuario").on("change", function(){
					$("#admin-usuario").val($(this).val());
				});
			});
        </script>
    </body>
</html>
