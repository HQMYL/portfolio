<?php


function portada($row){


 $salida = "";
 $salida = $salida . '<figure class="width-33">';
 $salida = $salida . '<a href="/ofertas-trabajo/profesional-sanitario" title="Listado de todas las Ofertas actualizadas por especialidad">';
 $salida = $salida . '<img src="img/inscribete.png" alt="Listado de todas las Ofertas actualizadas por especialidad" title="Listado de todas las Ofertas actualizadas por especialidad" width="90%" style="margin-left:5%;" />';

 $salida = $salida . '</a>';
 $salida = $salida . '<p>' .  $row->descripcion . '</p>';
 $salida = $salida . '</div>';
return $salida;
}




function portada2($row){


 $salida = "";
 $salida = $salida . '<div class="info-box blue-bg">';
 $salida = $salida . '<h2>' . $row->Sucursalid . '</h2>';
 $salida = $salida . '<p>' .  $row->direccion . '</p>';
 $salida = $salida . '<p>' .  $row->nombreSuc . '</p>';
 $salida = $salida . '</div>';
return $salida;
}

function portada1($row1){


 $salida = "";
 $salida = $salida . '<div class="info-box blue-bg">';
 $salida = $salida . '<p> Nombre:' . $row1->nombre . '</p>';
 $salida = $salida . '<p> Apellido:' .  $row1->apellido . '</p>';
 $salida = $salida . '<p> Dirección:' .  $row1->direccion . '</p>';
 $salida = $salida . '<p> Tipo de Usuario:' .  $row1->tipo . '</p>';
 $salida = $salida . '<p> Pertenece a la sucursal:' .  $row1->nombreSuc . '</p>';
 $salida = $salida . '</div>';
return $salida;
}








function portada3($row){


 $salida = "";
 $salida = $salida . '<tr>';
 $salida = $salida . '<td>'.$row->usuario.'</td>';
 $salida = $salida . '<td>'.$row->DNI.'</td>';
 $salida = $salida . '<td>'.$row->nombre.'</td>';
 $salida = $salida . '<td>'.$row->apellido.'</td>';
 $salida = $salida . '<td>'.$row->nombreSuc.'</td>';
 $salida = $salida . '<td>'.$row->tipo.'</td>';
 $salida = $salida . '<td>'.$row->CorreoE.'</td>';
 $salida = $salida . '<td>'.$row->FechaAlta.'</td>';
 $salida = $salida . '<td>'.$row->GestorAlta.'</td>';
 $salida = $salida . '</tr>';

 
return $salida;
}

function portada4($row2){


 $salida = "";
 $salida = $salida . '<div class="info-box blue-bg">';
 $salida = $salida . '<p> Descripción:' . $row2->descripcion . '</p>';
 $salida = $salida . '<p> Dirección:' .$row2->direccion .'</p>';
 $salida = $salida . '<p> Propietario:' .  $row2->propietario . '</p>';
 $salida = $salida . '<p>  Encargado:' .  $row2->usuario . '</p>';
 $salida = $salida . '<p> Estado:' .  $row2->estado . '</p>';
 $salida = $salida . '</div>';
return $salida;
}

function portadaop($row_id, $row){


 $salida = "";
 $salida = $salida . '<tr data-convocante="AGENCIA PÚBLICA EMPRESARIAL SANITARIA COSTA DEL SOL">';
 $salida = $salida . '<td>' .$row->fecha . '</td>';
 $salida = $salida . '<td>';
 $salida = $salida . '<p><a class="btn btn-danger" href="descripcion.html?id='. $row->id .'">Ver Detalles</strong> </a></p>';
 $salida = $salida . '<td>  Encargado:' .  $row->convocante . '</td>';
 $salida = $salida . '<td> Estado:' .  $row->titulacion . '</td>';
 $salida = $salida . '</div>';
return $salida;
}

function empli($row){
$total = 0;	
$total = $total + 1;

 $salida = "";
 $salida = $salida . '<div class="colectivo-ofertas">';
 $salida = $salida . '<ul class="ofertas-box-list">';
 $salida = $salida . '<li class="ofertas-box-list-title"><strong>' .utf8_encode($row->categoria). '</strong><br /><span class="num-ofertas">'. $total .' ofertas</span></li>';
 $salida = $salida . '</ul>';
 $salida = $salida . '</div>';

return $salida;
}


function portadaoferta($row_id, $row){


 $salida = "";
 $salida = $salida . '<ul class="lista-contenido">';
 $salida = $salida . '<li class="item">'; 
 $salida = $salida . '<a href="lista-candidatos.php?id='. $row->id .'">'. utf8_encode($row->colectivo).'</strong>';
 $salida = $salida . '</a>';
 $salida = $salida . '</li>';
 $salida = $salida . '</ul>';
 
return $salida;
}

function listaoferta($row_id, $row){


 $salida = "";

 $salida = $salida . '<h2 class="titulo-oferta">'. utf8_encode($row->descripcion). '</h2>'; 
 $salida = $salida . '<span class="green">'. utf8_encode($row->fecha). '</span>';

return $salida;
}



function listaof($row_id, $row){


 $salida = "";

 $salida = $salida . '<h2 class="titulo-oferta">'. utf8_encode($row->puesto). '</h2>'; 
 $salida = $salida . '<span class="green">'. utf8_encode($row->descripcionPuesto). '</span>';
 $salida = $salida . '<a class="btn btn-danger" href="aplicar.php?id='. $row->id .'">Aplicar</a>';
return $salida;
}


function listaof2($row_id, $row){


 $salida = "";

 $salida = $salida . '<h2 class="titulo-oferta">'. utf8_encode($row->puesto). '</h2>'; 
 $salida = $salida . '<span class="green">'. utf8_encode($row->descripcionPuesto). '</span>';
 $salida = $salida . '<span class="green">'. utf8_encode($row->descripcionPuesto). '</span>';
 $salida = $salida . '<span class="green">'. utf8_encode($row->descripcionPuesto). '</span>';
 $salida = $salida . '<span class="green">'. utf8_encode($row->descripcionPuesto). '</span>';
 $salida = $salida . '<span class="green">'. utf8_encode($row->descripcionPuesto). '</span>';
  

 $salida = $salida . '<a class="btn btn-danger" href="aplicar.php?id='. $row->id .'">Aplicar</a>';
return $salida;
}






function listaoferta2($row_id, $row){


 $salida = "";
 $salida = $salida . '<a class="enlace-ultimas-ofertas-dashboard" href="descripcion-oferta.php?id='. $row->id .'"  target="_blank" >';
 $salida = $salida . '<h2 class="titulo-oferta">'. utf8_encode($row->descripcion). '</h2>'; 
 $salida = $salida . '<span class="green">'. utf8_encode($row->fecha). '</span>';
 $salida = $salida . '</a>';
return $salida;
}


function candi($row_id, $row){


 $salida = "";
 $salida = $salida . '<a class="enlace-ultimas-ofertas-dashboard" href="descripcion-oferta.php?id='. $row->id .'"  target="_blank" >';
 $salida = $salida . '<h2 class="titulo-oferta">'. utf8_encode($row->descripcion). '</h2>'; 
 $salida = $salida . '<span class="green">'. utf8_encode($row->fecha). '</span>';
 $salida = $salida . '</a>';
return $salida;
}







?>