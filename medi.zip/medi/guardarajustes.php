<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
session_start();
include("conexion.php");

$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}



if (isset($_POST["recibirMail"])) {
	$recmail = "Si";
}




if (isset($_POST["periodicidad"])) {
	$per = utf8_decode($_POST["periodicidad"]);
}


if (isset($_POST["recibirUrgente"])) {
	$urgente = "Si";
}

if (isset($_POST["recibirEspecialidad"])) {
	$especialidad = "Si";
}





$sql = "INSERT INTO ajustes (usuario,NotiInbox,Periodicidad,NotiUrgente,NotiEspec) VALUES (:usuario,:recmail,:per,:urgente, :especialidad)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':recmail', $recmail, PDO::PARAM_STR);
$stmt->bindParam(':per', $per, PDO::PARAM_STR);
$stmt->bindParam(':urgente', $urgente, PDO::PARAM_STR); 
$stmt->bindParam(':especialidad', $especialidad, PDO::PARAM_STR);
$stmt->execute();
 
?>

<script>
alert('Los ajustes han sido guardados');
window.location.href='ajustes-inbox.php';
</script>

</body>
<html>