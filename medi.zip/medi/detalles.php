<!DOCTYPE html>
<html lang="es">
<?php
session_start();
include("conexion.php");
include("db.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}

$id = "";
if(isset($_GET['id'])) {
$id = $_GET['id'];}




?>
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="	MedicalJob, bolsa de empleo con ofertas de trabajo, congresos y cursos de enfermera, médico y auxiliar en enfermería en el sector de salud
" />
		        <title>Detalle de Oferta
</title>
        <!--[if lt IE 9]>
        	<script src="/bundles/comun/js/html5shiv.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
                <link rel="stylesheet" type="text/css" href="css2/css.css" />
        		<link rel="stylesheet" type="text/css" href="css2/reset.css" />
    <link rel="stylesheet" type="text/css" href="css2/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css2/frontend.css" />
	<link rel="stylesheet" type="text/css" href="css2/forms.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery-ui-1.10.3.custom.min.css" />

	<link rel="stylesheet" type="text/css" href="css2/usuario.css" />
	<link rel="stylesheet" type="text/css" href="css2/extranet.css" />
	<link rel="stylesheet" type="text/css" href="css3/new.css" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="apple-touch-icon" sizes="114x114" href="" />
        <link rel="apple-touch-icon" sizes="72x72" href="" />
        <link rel="apple-touch-icon" href="" />
        <style type="text/css">
            h1 {
            	text-align: center;
            	color: red;
            	font-size: 25px;
            }

p {
	font-family: Arial;
	color: blue;
	font-size: 15px;
}
            .menu-titulo {
        
        background-image: url("img/flecha.png");
        
    }

 
        	.pagination {
	font-family: Verdana, sans-serif;
	padding:20px;
	margin:7px;
}
.pagination a {
	margin: 2px;
	padding: 0.5em 0.64em 0.43em 0.64em;
	background-color: #ee4e4e;
	text-decoration: none;
	color: #fff;
}
.pagination a:hover, .pagination a:active {
	padding: 0.5em 0.64em 0.43em 0.64em;
	margin: 2px;
	background-color: #de1818;
	color: #fff;
}
.pagination span.current {
    padding: 0.5em 0.64em 0.43em 0.64em;
    margin: 2px;
    background-color: #f6efcc;
    color: #6d643c;
}
.pagination span.disabled {
    display:none;
}




        </style>
    </head>
    <body itemscope itemtype="http://schema.org/WebPage">
		<div id="cargando" style="display:none"></div>
		    				        	<div id="pagina">
		<header id="header">
			<div id="banner">
				<img class="img-responsive" src="img/portada.jpg" 
					 alt="MedicalJob: Trabaja en el sector médico en cualquier parte del mundo"
					 title="MedicalJob: Trabaja en el sector médico en cualquier parte del mundo" />
			</div>
					</header>
		<div id="contenido">
			<div id="breadcrumb" itemprop="breadcrumb">
									<a href="seccion-usuarios.php"><span class="glyphicon glyphicon-home"></span> Inicio</a> >
											<a href="seccion-usuarios.php">Mi Cuenta</a> >
					 
				 Detalle de Oferta</div>
					
			<aside id="sidebar">
				<div id="cuadro-sesion">
	<p><em>BIENVENIDO</em> <span class="green">
			<?php echo $usuario; ?></span><br />
		<em>Tiene 0 mensajes en su <a class="blue" href="mis-mensajes.php">Inbox</a></em>
			</p>
	<p id="cuadro-sesion-saldo">
		<?php
        $sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { ?>
			<em>Saldo actual: <span class="green" id="cuadro-sesion-puntos"><?php echo $row->creditos;?> créditos</span></em>
		</p><?php } ?>

        <?php
 $stmt = $DB_con->prepare('SELECT * FROM perfil WHERE usuario =:uid');
  $stmt->execute(array(':uid'=>$usuario));
  $stmt->execute();
  
  if($stmt->rowCount() > 0)
  {
    while($row=$stmt->fetch(PDO::FETCH_ASSOC))
    {
      extract($row); 
      ?> 
				<img class="img-responsive" src="img/<?php echo $row['userPic']; ?>"
			 alt="Foto de Perfil" 
			 title="Foto de Perfil" 
			 width="70" style="float: left; margin: 5px 20px" />
             <?php }
         } ?>
		<a class="button button-blue" href="ofertas.php">OFERTAS</a>
		<a class="button button-grey" href="logout.php">SALIR</a>
</div>				                    <div id="menu-usuario" class="menu-lateral">
	<ul id="menu-box">
		<li class="menu-titulo" data-target="submenu-datos">Mi cuenta</li>
		<li class="submenu" id="submenu-datos">
			<ul>
				<li><a href="mis-datos-acceso.php">Mis Datos de Acceso</a></li>
				<li><a href="datos-personales.php">Mis Datos Personales</a></li>
				<li><a href="curriculum.php">Mi Currículum</a></li>
				<li><a href="recomendar-usuario.php">Recomendar MedicalJob</a></li>
                <li><?php
        $sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { 
if(($row->pagovisitas == "0") AND ($row->pagocurri == "0")){ ?>
<a href="<?php echo 'acciones-avanzadas.php';?>">Acciones Avanzadas</a>
<?php } ?>

<?php 
if(($row->pagovisitas == "1") AND ($row->pagocurri == "0")){ ?>
<a href="<?php echo 'visitas-curriculum.php';?>">Acciones Avanzadas</a>
<?php } ?>

<?php 
if(($row->pagovisitas == "0") AND ($row->pagocurri == "1")){ ?>
<a href="<?php echo 'compras-curriculum.php';?>">Acciones Avanzadas</a>
<?php } ?>

<?php 
if(($row->pagovisitas == "1") AND ($row->pagocurri == "1")){ ?>
<a href="<?php echo 'acciones.php';?>">Acciones Avanzadas</a>
<?php } ?>

</li>

<?php } ?>

				<li><a href="eliminar-cuenta-usuario.php">Darme de baja</a></li>
			</ul>
		</li>
		<li class="menu-titulo" data-target="submenu-ofertas">Ofertas</li>
		<li class="submenu" id="submenu-ofertas">
			<ul>
				<li><a href="ofertas.php">Buscar ofertas</a></li>
				<li><a href="mis-ofertas.php">Ver mis candidaturas</a></li>
			</ul>
		</li>
		<li class="menu-titulo" data-target="submenu-inbox">Inbox</li>
		<li class="submenu" id="submenu-inbox">
			<ul>
				<li><a href="mis-mensajes.php">Ver mis mensajes</a></li>
				<li><a href="ajustes-inbox.php">Cambiar mis ajustes de Inbox</a></li>
			</ul>
		</li>
        <li class="menu-titulo" data-target="submenu-puntos">Créditos</li>
        <li class="submenu" id="submenu-puntos">
            <ul>
                <li><a href="creditos.php">Comprar</a></li>
                <li><a href="historial.php">Histórico de compras</a></li>
            </ul>
        </li>
	</ul>
</div>



 
<div class="border-box-aside">
	<!-- CARRUSEL -->

 <section>
                  
                  <div id="slider-container">
                      <div id="slider-box">
                          <div class="slider-element">
                              <article class="element-red">
                              <img class="img-responsive img-thumbnail" src="img/italiano.png">  
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-green">
                               <img class="img-responsive img-thumbnail" src="img/cposgrado.jpg">     
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-blue">
                                <img class="img-responsive img-thumbnail" src="img/cruz.png">  
                              </article>                            
                          </div>
                      </div>
                  </div>
                  
              </section>        


       <!-- CARRUSEL -->
</div>
	
<div id="progressbar-curriculum">
	<div class="progress">
		
	</div>
	<p>
		Quieres mejorar tu currículum?<br />
		<a href="curriculum.php"s>
			Haz click aquí<br />
			<img 
				src="img/edit_curriculum.png" 
				alt="Modificar mi curriculum" 
				title="Modificar mi curriculum" 
				width="32" 
				height="32"
			/>
		</a>
	</p>
</div>									<div id="compra-puntos-insitu-box">
        <div id="compra-puntos-izq">
        	TU SALDO<br />ACTUAL:<br/>
        </div>
        <div id="compra-puntos-der">
        	<span class="green" style="font-size:16px;line-height:18px">
        		<?php
        $sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { ?>
        		<strong style="font-size:26px;letter-spacing:-2px;"><?php echo $row->creditos; ?></strong><br />créditos
        	</span>
        	<?php } ?>
        </div>
        <input type="hidden" id="saldo-empresa" value="20"/>
		            <a href="creditos.php" class="button button-green">COMPRAR</a>
            <a href="historial.php"s class="button button-blue">HISTORIAL</a>
            <a href="javascript:location.reload()" class="button button-grey" id="actualizar-puntos">ACTUALIZAR</a>
            </div>
				
					
				
			</aside>
		
			<div id="content-right">
				<div style="float:left;width:100%">
		    	        
	    	</div>									<div id="publi-empresa">
						<a href="wiki-usuarios.php" style="margin-left:0px">
							<img src="img/como-funcionan-los-creditos.jpg" 
							 	 alt="Como funcionan los créditos de MedicalJob"
							 	 title="Como funcionan los créditos de MedicalJob" />
						</a>
												<a href="ofertas.php">
							<img src="img/busca-tu-trabajo.jpg" 
								 alt="Busca tu trabajo en MedicalJob"
								 title="Busca tu trabajo en MedicalJob"
								 style="float:right;margin-right:5px" />
						</a>
					</div>
												<div class="mediempleo-box width-50">
            
        </div>
		<div class="width-50">
	        <div class="mediempleo-box" style="width:90%;float:right">
	            
	        </div>
		</div>
		
        <div class="mediempleo-box width-100">
	        <div class="content">
	            <?php
        $sql = "SELECT * FROM ofertas WHERE id ='".$id."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { ?>
<h1>Puesto: <?php echo utf8_encode($row->puesto) ; ?></h1>
<p>Descripción: <?php echo  utf8_encode($row->descripcionPuesto); ?></p>
<p>Requerimientos: <?php echo  utf8_encode($row->requerimientos); ?></p>
<p>Salario: <?php echo  utf8_encode($row->salario); ?></p>
<p>País: <?php echo  utf8_encode($row->pais); ?></p>

<a class="btn btn-danger" href="aplicar.php?puesto=<?php echo utf8_encode($row->puesto);?>&contacto=<?php echo utf8_encode($row->nombreContacto);?>&centro=<?php echo utf8_encode($row->nombreCentro);?>">Aplicar</a>



<?php } ?>

	         <!-- FINAL PAGINADOR -->			 
		
	            <div class="box-content dashboard-empresa" id="mis-inscripciones" style="display:none">
	                	                    
	                	            </div>
	            <div class="box-content dashboard-empresa" id="ofertas-interesantes">
	                	                    
	                	            </div>

	        </div>
	    </div>
	    <!-- INICIO PAGINADOR -->
	          
	  </div>
	</div>
			</div>
		</div>
		<footer id="footer">	
	<div id="container-footer-especialidades">
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
        
        
    </div>
    <div id="footer-aside">
        <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                <li><a href=""></a></li>
                <li><a href=""></a></li>
            </ul>
        </div>
        <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                <li>
                    
                </li>
                <li>
                    
                </li>
                <li>
                    
                </li>
							</ul>
		</div>
		
		
	</div>
	<div id="footer-aside">
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
				<li></li>
				<li></li>
			</ul>
		</div>
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
				<li>
					
				</li>
				<li>
					
				</li>
				<li>
					
				</li>
							</ul>
		</div>
		
		
	</div>
	<div id="footer-aside">
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
				<li><a href=""></a></li>
				<li><a href=""></a></li>
			</ul>
		</div>
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
				<li>
					
				</li>
				<li>
					
				</li>
				<li>
					
				</li>
			</ul>
		</div>
		<figure id="logo-footer">
			<img class="img-responsive img-thumbnail" src="img/log.jpg" alt="Logo de MedicalJob" title="MedicalJob, tu web de empleo médico" width="90%" />
		</figure>
		<div id="info-footer">
			<b>Copyright &copy; 2018 </b><br />
			<a href="informacion-legal.php">Información legal</a><br />
			<a href="politica-privacidad.php">Política de privacidad</a> |
			<a href="normativa.php">Normativa</a> |
			<a href="contacto.php">Contacto</a>
		</div>	
	</div>
	
		
</footer>	</div>
                
        	<script src="/bundles/fosjsrouting/js/router.js"></script>
	<script src="js2/routing?callback=fos.Router.setData"></script>
	<script src="js2/jquery-1.9.1.min.js"></script>
    <script src="js2/jquery-ui-1.10.3.custom.min.js"></script>
	<script src="js2/frontend.js"></script>
	<script src="js2/bootstrap.js"></script>
			<script src="js2/usuario.js"></script>
	 <script>
	$(document).ready(function(){
		load(1);
	});

	function load(page){
		var parametros = {"action":"ajax","page":page};
		$("#loader").fadeIn('slow');
		$.ajax({
			url:'ofertas-ajax.php',
			data: parametros,
			 beforeSend: function(objeto){
			$("#loader").html("<img src='loader.gif'>");
			},
			success:function(data){
				$(".outer_div").html(data).fadeIn('slow');
				$("#loader").html("");
			}
		})
	}
	</script>
        
        
    </body>
</html>