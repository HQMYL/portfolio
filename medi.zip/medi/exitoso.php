<!DOCTYPE html>
<html>
<?php
session_start();
include("db.php"); 
include("conexion.php");
include("data.php");
$monto = "";
$descripcion = "";
$fecha = "";
$nom = "";
$texto = "";
$texto = "tu saldo no es suficiente compra más créditos";
$especialidad = "";
$resta = "";
$credi = "";
$op = "";
$resta2 = "";
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}


if(isset($_GET['id'])) {
$id = utf8_decode($_GET['id']);}


if(isset($_GET['col'])) {
$col = utf8_decode($_GET['col']);}




?>
<head>
	<title></title>
</head>
<body>
	<?php

if(isset($_GET['op'])) {

$op = utf8_decode($_GET['op']);
}


$resta = array();

$sql = "SELECT * FROM prcreditos WHERE especialidad ='".$op."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { 

$resta[0] = $row->sinndatos;


$resta2 = $resta[0];
}





 $credi = array();
 
$sql = "SELECT * FROM empresas WHERE user ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { 

$credi[0] = $row->creditos;

}


$monto = $credi[0];




$texto = utf8_decode($texto);
if ($monto < $resta2) {

header('Location: buscar-usuarios.php');
}


else {
$monto = $monto -$resta2;

$c = 1;

$sql2 = " UPDATE empresas SET creditos =:monto, curr1=:c WHERE user =:usuario ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':monto', $monto, PDO::PARAM_STR);
  $stmt2->bindParam(':c', $c, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();






$name = array();
$sql = "SELECT * FROM usuarios WHERE id ='".$id."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { 

$name[0] = $row->nombre;

}

$nom = $name[0];


$name2 = array();
$sql = "SELECT * FROM usuarios WHERE id ='".$id."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { 

$name2[0] = $row->usuario;

}

$nom2 = $name2[0];






$fecha=date("Y/m/d");
$sql2 = "INSERT INTO ccurriculum (usuario, profesional,user,colectivo,fecha) VALUES (:usuario,:nom,:nom2,:col,:fecha)";
$stmt2 = $con->prepare($sql2);

$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->bindParam(':nom', $nom, PDO::PARAM_STR); 
$stmt2->bindParam(':nom2', $nom2, PDO::PARAM_STR); 
$stmt2->bindParam(':col', $col, PDO::PARAM_STR); 
$stmt2->bindParam(':fecha', $fecha, PDO::PARAM_STR); 
$stmt2->execute();




$fecha=date("Y/m/d");

$descripcion = "Compra de curriculum";
$descripcion = utf8_decode($descripcion);

$sql = "INSERT INTO historialc (usuario,fecha,descripcion,profesional) VALUES (:usuario,:fecha,:descripcion,:nom)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
$stmt->bindParam(':nom', $nom, PDO::PARAM_STR);

$stmt->execute();


}



?> 
<script>
	alert('La Compra se ha realizado exitosamaente');
window.location.href='buscar-usuarios.php';


</script>


</body>
</html>

