<?php
session_start();
$tipo = "";
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
include("conexion.php");

$pa = "";
if (isset($_POST["id"])) {
	$pa = $_POST["id"];
}


$tipo = "Profesional";
 $sth = $con->prepare("SELECT * FROM usuarios WHERE CodigoPostal = ? AND tipo = ?");
$sth->bindParam(1, $pa);
$sth->bindParam(2, $tipo);
$sth->execute();

if ($sth->rowCount() > 0) {

echo '<table class="table table-bordered table-hover">';
echo '<thead>';
echo '<tr>';

echo '<th>NOMBRE</th>';
echo '<th>COLECTIVO</th>';
echo '<th>ESPECIALIDAD</th>';
echo '<th>TIPO</th>';
echo '<th>LOCALIDAD</th>';
echo '<th>CÓDIGO POSTAL</th>';
echo '</tr>';
echo '</thead>';
foreach ($sth as $row ) {

echo '<tbody>';
echo '<tr>';
 echo '<td>' .  utf8_encode($row["nombre"]) . '</td>';
 echo '<td>' .  utf8_encode($row["colectivo"]) . '</td>';
 echo '<td>' .  utf8_encode($row["especialidad"]) . '</td>';
 echo '<td>' .  utf8_encode($row["tipo"]) . '</td>';
 echo '<td>' .  utf8_encode($row["localidad"]) . '</td>';
 echo '<td>' .  utf8_encode($row["CodigoPostal"]) . '</td>';
 echo '</tr>';
 echo '</tbody>';
 

}

}
 ?>