<!DOCTYPE html>
<html lang="es">
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DemiJob</title>

    <!-- Bootstrap Core CSS -->
    <link href="css3/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css3/sb-admin.css" rel="stylesheet">
    <link href="css3/new.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css3/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <script src="js3/jquery-3.js"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
        .navbar-brand {
color: blue;
}
    </style>

    <script type="text/javascript">

$(document).ready(function() {

  $("#cmbcolectivo").change(function(){
          
      var id=$("#cmbcolectivo").val();
      $('#cmbespec').load('escoger.php?id='+id);
});
});  
</script>

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" style="color: #fff;" href="admin.php">Inicio</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
               <li><a style="color: #fff;" class=" btn btn-danger"><?php echo "Bienvenido: " .$usuario; ?></a></li>
              <li><a style="color: #fff;" class="btn btn-danger" href="logout.php">Cerrar Sesión</a></li> 
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="admin.php"><i class=""></i> Panel de Control</a>
                    </li>
                    
                    
                    
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo"><i></i> Usuarios <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="agregarusuario.php">Agregar Usuario</a>
                            </li>
                            <li>
                                <a href="consultarusuario.php">Consultar Usuario</a>
                            </li>
                            <li>
                                <a href="actualizarusuario.php">Actualizar Usuario</a>
                            </li>
                            <li>
                                <a href="eliminarusuario.php">Eliminar Usuario</a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo1"> Empresas <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo1" class="collapse">
                            <li>
                                <a href="agregarempresa.php">Agregar Empresa</a>
                            </li>
                            <li>
                                <a href="consultarempresa.php">Consultar Empresa</a>
                            </li>
                            <li>
                                <a href="actualizarempresa.php">Actualizar Empresa</a>
                            </li>
                            <li>
                                <a href="eliminarempresa.php">Eliminar Empresa</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo3"><i></i> Empleos <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo3" class="collapse">
                            <li>
                                <a href="agregarempleo.php">Agregar Empleos</a>
                            </li>
                            <li>
                                <a href="consultarempleo.php">Consultar Empleos</a>
                            </li>
                            <li>
                                <a href="actualizarempleo.php">Actualizar Empleos</a>
                            </li>
                            <li>
                                <a href="eliminarempleo.php">Eliminar Empleos</a>
                            </li>
                        </ul>
                    </li>   
                 <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo4"><i></i> Oposiciones <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo4" class="collapse">
                            <li>
                                <a href="agregaroposicion.php">Agregar Oposición</a>
                            </li>
                            <li>
                                <a href="consultaroposicion.php">Consultar Oposición</a>
                            </li>
                            <li>
                                <a href="actualizaroposicion.php">Actualizar Oposición</a>
                            </li>
                            <li>
                                <a href="eliminaroposicion.php">Eliminar Oposición</a>
                            </li>
                        </ul>
                    </li>
                     <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo5"><i></i> Reportes <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo5" class="collapse">
                            <li>
                                <a href="ventas.php">Ventas</a>
                            </li>
                            <li>
                                <a href="creditos-adquiridos.php">Creditos Adquiridos</a>
                            </li>
                            
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Agregar Empleo
                        </h1>
                        <ol class="breadcrumb">
                            
                        </ol>
                    </div>
                </div>
                <div>    
 <form class="form" name="formi" method="POST" action="guardaroferta2.php">
                <fieldset>
                    
                    <div class="col">
                        <label>COLECTIVO <span class="tooltip">?</span></label>
                        <select  id="cmbcolectivo" name="cmbcolectivo" class="select-centros">
            <option value="">Seleccione el Colectivo</option>

         <?php 
      
         
         $sql = "SELECT * FROM colectivo";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->id .'">'.utf8_encode ($row->nombre).'</option>';

        
    }

    ?>
</select>
                        <label>ESPECIALIDAD <span class="tooltip">?</span></label>
                        <select id="cmbespec" name="cmbespec" class="select-centros">
                                    <option value="">Selecciona la Especialidad</option>
                                </select>

                        <label>PUESTO<span class="tooltip">?</span></label>
                        <input type="text" name="puesto" id="puesto">
                         <label>DESCRIPCIÓN<span class="tooltip">?</span></label>
                        <input type="text" name="descripcion1" id="descripcion1">
                         
                    </div>
                    <div class="col">
                        <label>REQUERIMIENTOS <span class="tooltip">?</span></label>
                        <input type="text" name="req" id="req"> 
                        <label>SALARIO <span class="tooltip">?</span></label>
                        <input type="text" name="salario" id="salario">
                        <label>VENCIMIENTO <span class="tooltip">?</span></label>
                        <input type="text" name="fin" id="fin">
              
  </div>

                    <div class="col">
                        <label>NOMBRE DEL CENTRO <span class="tooltip">?</span></label>
                        <input type="text" name="nombre" id="nombre"> 
                        <label>TIPO<span class="tooltip">?</span></label>
                         <select id="tipo" name="tipo" class="select-centros">
                    <option value="55">Centro de salud</option>
                    <option value="56">Centro de especialidades</option>
                    <option value="57">Consultorio</option>
                    <option value="58">Hospital</option>
                    <option value="59">Centro médico</option>
                    <option value="60">Clínica</option>
                    <option value="61">Geriátrico</option>
                    <option value="62">Empresa</option>
                    <option value="63">Otros</option>
        </select>
                        <label>TELÉFONO <span class="tooltip">?</span></label>
                        <input type="text" name="telefono" id="telefono">
              
  </div>


   <div class="col">
                        <label>PAIS <span class="tooltip">?</span></label>
                        <select id="cmbpais" name="cmbpais">
            <option value="">Seleccione el Pais</option>

         <?php 
      
         
         $sql = "SELECT * FROM pais";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->nombrepais .'">'.utf8_encode ($row->nombrepais).'</option>';

        
    }

    ?>
</select> 
                        <label>CIUDAD <span class="tooltip">?</span></label>
                        <select id="cmbciudad2" name="cmbciudad2">
            <option value="">Seleccione la Ciudad</option>

         <?php 
      
         $sql = "SELECT * FROM localidad";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->nombrelocalidad .'">'.utf8_encode ($row->nombrelocalidad).'</option>';

        
    }

    ?>
</select> 
<label>DIRECCIÓN <span class="tooltip">?</span></label>
                        <input type="text" name="direccion" id="direccion"> 
                        <label>DESCRIPCIÓN<span class="tooltip">?</span></label>
                        <input type="text" name="descripcion" id="descripcion">
  </div>

  
  <div class="col">
                        <label>CONTACTO <span class="tooltip">?</span></label>
                        <input type="text" name="NombreContacto" id="tel"> 
                        <label>TELÉFONO<span class="tooltip">?</span></label>
                        <input type="text" name="sal" id="TelefonoContacto">
                        <label>CORREO<span class="tooltip">?</span></label>
                        <input type="text" name="CorreoContacto" id="CorreoContacto">
              
  </div>
                </fieldset>

                <input type="submit" value="GUARDAR">

            </form>

                
            </div>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js3/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js3/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js3/plugins/morris/raphael.min.js"></script>
    <script src="js3/plugins/morris/morris.min.js"></script>
    <script src="js3/plugins/morris/morris-data.js"></script>


    

</body>

</html>
