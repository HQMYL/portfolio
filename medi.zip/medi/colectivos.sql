INSERT INTO `colectivo` (`id`, `nombre`) VALUES
(8, '2018-04-07', 'Sam', 'HQ', '', 'Arelis es deliciosa', '1');
