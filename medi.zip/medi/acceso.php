<!DOCTYPE html>
<html>
<?php
include("conexion.php");
session_start();
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}

if (isset($_POST["id"])) {
	$pa = $_POST["id"];
}
?>
<head>
	<title></title>
	<style type="text/css">
		.kal {
			font-size: 15px;
			font-family: Arial;
			color: #333;
		}
	</style>
</head>
<body>

<?php


 $sql = "SELECT * FROM usuarios WHERE usuario ='".$pa."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {

if ($row->pass == $pa) {
	echo "";
}
else {
	echo '<p class="kal">La contraseña introducida no coincide con su contraseña actual, ingrésela nuevamente</p>';
}
}

 ?>
 </body>
</html>
