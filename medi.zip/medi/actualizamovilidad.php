<?php
include("conexion.php");
session_start();
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}

if (isset($_POST["cmbpais2"])) {
	$pais = $_POST["cmbpais2"];
}

if (isset($_POST["cmbciudad2"])) {
	$ciudad = $_POST["cmbciudad2"];
}







 $sql = "SELECT * FROM movilidad WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {

if($pais == $row->pais) {

$sql2 = " UPDATE movilidad SET ciudad =:ciudad WHERE usuario =:usuario ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':ciudad', $ciudad, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();

}

if($ciudad == $row->ciudad) {

$sql2 = " UPDATE movilidad SET pais =:pais WHERE usuario =:usuario ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':pais', $pais, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();

}





}

 ?>