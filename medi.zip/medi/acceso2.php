<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.kal {
			font-size: 15px;
			font-family: Arial;
			color: #333;
		}
	</style>
</head>
<body>

<?php
include("conexion.php");
session_start();
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}


$pa = "";
if (isset($_POST["id"])) {
	$pa = $_POST["id"];
}

$pa = $pa * 20; ?>

 <th><label for="precio-con-descuento">Total a pagar:</label></th>
 <td><input class="form-control" id="precio"  type="text" name="precio" value="<?php echo $pa; ?>" /></td>
		                            


 
 </body>
</html>
