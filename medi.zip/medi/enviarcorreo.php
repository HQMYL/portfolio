<!DOCTYPE HTML>
<html>
<body>
<?php

session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}

if (isset($_POST["mail"])) {
$mail = $_POST["mail"];	
}

$correo = "MedicalJob";


$para = $mail;
$titulo = 'Registro en Medicaljob';
$mensaje = 'Hola, la Persona:' . $usuario . ' Te invita a registrarte en el sitio web MedicalJob' ;
$cabeceras = 'De: ' . $correo .  "\r\n" .

 //La direccion de correo desde donde supuestamente se envió
    'Reply-To: ' . $correo  . "\r\n" . //La direccion de correo a donde se responderá (cuando el recepto haga click en RESPONDER)
    'X-Mailer: PHP/' . phpversion();  //información sobre el sistema de envio de correos, en este caso la version de PHP
 
mail($para, $titulo, $mensaje, $cabeceras);
?>
<script>
alert('El mensaje ha sido enviado correctamente');
window.location.href='recomendar.php';
</script>

</body>
</html>