<!DOCTYPE html>
<html lang="es">
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
?>
    <head>
        <meta charset="UTF-8" />
		<meta name="description" content="	MedicalJob, bolsa de empleo con ofertas de trabajo, congresos y cursos de enfermera, médico y auxiliar en enfermería en el sector de salud
" />
		        <title>Datos de facturación 	
</title>
        <!--[if lt IE 9]>
        	<script src="/bundles/comun/js/html5shiv.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
                <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=PT+Sans" />
            	<link rel="stylesheet" type="text/css" href="css2/reset.css" />
    <link rel="stylesheet" type="text/css" href="css2/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css2/frontend.css" />
	<link rel="stylesheet" type="text/css" href="css2/forms.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery-ui-1.10.3.custom.min.css" />

    <link rel="stylesheet" type="text/css" href="css2/empresa.css" />
    <link rel="stylesheet" type="text/css" href="css2/form-facturacion.css" />
    <link rel="stylesheet" type="text/css" href="css2/extranet.css" />
    <link rel="stylesheet" type="text/css" href="css3/new.css" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="apple-touch-icon" sizes="114x114" href="" />
        <link rel="apple-touch-icon" sizes="72x72" href="" />
        <link rel="apple-touch-icon" href="" />
         <style type="text/css">

         body {
    background-color: #FFFF00;
}
            .menu-titulo {
        
        background-image: url("img/flecha.png");
 }    

 .btn, .btn-danger {
    float: right;
 }   
        </style>
    </head>
    <body itemscope itemtype="http://schema.org/WebPage">
		<div id="cargando" style="display:none"></div>
		    				        	<div id="pagina">
		<header id="header">
			<div id="banner">
				<img class="img-responsive" src="img/portada.jpg" 
					 alt="MedicalJob: Trabaja en el sector médico en cualquier parte del mundo"
					 title="MedicalJob: Trabaja en el sector médico en cualquier parte del mundo" />
			</div>
					</header>
		<div id="contenido">
			<div id="breadcrumb" itemprop="breadcrumb">
									<a href="seccion-empresas.php"><span class="glyphicon glyphicon-home"></span> Inicio</a> >
											<a href="seccion-empresas.php">Mi Cuenta</a> >
					 
				Datos de Facturación 			</div>
					
			<aside id="sidebar">
				<div id="cuadro-sesion">
                    <?php
            $total = 0;
            $leido = 0;
        $sth = $con->prepare("SELECT * FROM aplicaciones WHERE contacto = ? AND leido = ?");
$sth->bindParam(1, $usuario);
$sth->bindParam(2, $leido);
$sth->execute();

if ($sth->rowCount() > 0) {
 foreach ($sth as $row) {
     $total = $total + 1;
 }


}
 ?>
	<p><em>BIENVENIDO</em> <span class="green">
				<?php echo $usuario; ?></span><br />
                <em><?php echo $total; ?> notificacione(s) <a class="blue" href="notificaciones-pendientes.php">Notificaciones Pendientes</a></em>
		</p>
	<p id="cuadro-sesion-saldo">
        <?php
        $sql = "SELECT * FROM empresas WHERE user ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { ?>
			<em>Saldo actual: <span class="green" id="cuadro-sesion-puntos"><?php echo $row->creditos;?> créditos</span></em>
            <?php } ?>
		</p>
			<a class="button button-green" href="nueva-oferta.php">PUBLICAR</a>
		<a class="button button-blue" href="listado-ofertas.php">OFERTAS</a>
			<a class="button button-grey" href="logout.php">SALIR</a>
</div>									<div id="menu-empresa" class="menu-lateral">
    <ul id="menu-box">
    	<li class="menu-titulo" data-target="submenu-ofertas">Ofertas</li>
        <li class="submenu" id="submenu-ofertas">
            <ul>
                <li><a href="listado-ofertas.php">Ver ofertas</a></li>
                <li><a href="nueva-oferta.php">Publicar oferta</a></li>
            </ul>
        </li>
        <li class="menu-titulo" data-target="submenu-curriculums">Currículums</li>
        <li class="submenu" id="submenu-curriculums">
            <ul>
                <li><a href="buscar-usuarios.php">Buscar candidatos</a></li>
                <li><a href="notificaciones-pendientes.php">Notificaciones Pendientes</a></li>
                <li>
                     <?php
        $sql = "SELECT * FROM empresas WHERE user ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {  

if(($row->curr1 == "0") AND ($row->curr2 == "0")) { ?> 
<a href="<?php echo 'curriculums-adquiridos.php';?>">Curriculums Adquiridos</a>
<?php  } ?> 


<?php
if(($row->curr1 == "1") AND ($row->curr2 == "0")) { ?>
<a href="<?php echo 'curriculums.php';?>">Curriculums Sin datos de Contacto</a>
<?php } ?>

<?php 
if(($row->curr1 == "0") AND ($row->curr2 == "1")){ ?>
<a href="<?php echo 'curriculum-contacto.php';?>">Curriculums con Datos de Contacto</a>
<?php } ?>

<?php
if(($row->curr1 == "1") AND ($row->curr2 == "1")) { ?>
<a href="<?php echo 'lista-curriculums.php';?>">Curriculums Comprados</a>
<?php } ?>

</li>

<?php } ?>
                </li>
            </ul>
        </li>
        <li class="menu-titulo" data-target="submenu-puntos">Créditos</li>
        <li class="submenu" id="submenu-puntos">
            <ul>
                <li><a href="comprar-creditos.php">Comprar</a></li>
                <li><a href="historico-compras.php">Histórico de compras</a></li>
                <li><a href="movimientos.php">Histórico de movimientos</a></li>
            </ul>
        </li>
        <li class="menu-titulo" data-target="submenu-centros">Centros</li>
        <li class="submenu" id="submenu-centros">
            <ul>
                <li><a href="lista-centros.php">Ver centros</a></li>
                <li><a href="nuevo-centro.php">Alta nuevo centro</a></li>
            </ul>
        </li>
        <li class="menu-titulo" data-target="submenu-datos">Mi perfil</li>
        <li class="submenu" id="submenu-datos">
            <ul>
                <li><a href="datos-acceso-empresa.php">Datos de acceso</a></li>
                <li><a href="datos-facturacion.php">Datos de facturación</a></li>
                <li><a href="recomendar.php">Recomendar MedicalJob</a></li>
                <li><a href="cerrar-cuenta.php">Darse de baja</a></li>
            </ul>
        </li>
    </ul>
</div>
			<!-- CARRUSEL -->

 <section>
                  
                  <div id="slider-container">
                      <div id="slider-box">
                          <div class="slider-element">
                              <article class="element-red">
                              <img class="img-responsive img-thumbnail" src="img/italiano.png">  
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-green">
                               <img class="img-responsive img-thumbnail" src="img/cposgrado.jpg">     
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-blue">
                                <img class="img-responsive img-thumbnail" src="img/cruz.png">  
                              </article>                            
                          </div>
                      </div>
                  </div>
                  
              </section>        


       <!-- CARRUSEL -->
			</aside>
		
			<div id="content-right">
				<div style="float:left;width:100%">
	</div>									<div id="publi-empresa">
						<a href="wiki-empresas.php" style="margin-left:50px">
							<img class="img-responsive img-thumbnail" src="img/como-funcionan-creditos.jpg" 
							 	 alt="Como funcionan los créditos en MedicalJob"
							 	 title="Como funcionan los créditos en MedicalJob" />
						</a>
						<a href="publicar-ofertas.php">
							<img class="img-responsive img-thumbnail" src="img/ayuda-para-publicar.jpg" 
								 alt="Ayuda para publicar ofertas en MedicalJob"
								 title="Ayuda para publicar ofertas en MedicalJob" />
						</a>
						<a href="nueva-oferta.php">
							<img class="img-responsive img-thumbnail" src="img/publica-tu-oferta.jpg" 
								 alt="Publica tu oferta en MedicalJob"
								 title="Publica tu oferta en MedicalJob"
								 style="float:right;margin-right:5px" />
						</a>
					</div>
								    <div class="mediempleo-box">
        <div class="content">
            <div class="box-header">
                <div class="box-title">
                    <h1>DATOS DE FACTURACIÓN</h1>
                </div>
            </div>
            <div class="box-content">
                <form action="guardarfacturacion.php" method="post" >
                    <div class="form-error"></div>
                    
                    <div class="content-mini-box-row">
                        <div class="mini-box-cell-50">
                            <label for="social" class="required">Razón social*</label>
                            <input type="text" id="razon" name="razon"     class="text-input-alta" value="" />
                        </div>
                        <div class="mini-box-cell-50">
                            <label for="cif" class="required">CIF</label>
                            <input type="text" id="cif" name="cif"  class="text-input-alta" />
                        </div>
                    </div>
                    <div class="content-mini-box-row">
                        <div class="mini-box-cell-50">
                            <label for="correo" class="required">Email facturación*</label>
                            <input type="email" id="correo" name="correo"  class="text-input-alta doble-linea" />
                        </div>
                    </div>
                    <div class="content-mini-box-row">
                        <div class="mini-box-cell-50">
                            <label for="pais" class="required">País*</label>
                            <select  id="cmbpais2" name="cmbpais2" class="select-centros">
            <option value="">Seleccione el Pais</option>

         <?php 
      
         $sql = "SELECT * FROM pais";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) {
echo '<option value="'. $row->id .'">'.utf8_encode ($row->paisnombre).'</option>';

        
    }

    ?>
</select>
                        </div>
                        
                        <div id="bloque-provincia" class="mini-box-cell-50">
                            <label id="label-select-provincias" name="selectprovincias">Ciudad</label>
                            <select id="cmbciudad2" name="cmbciudad2" class="select-centros">
                                    <option value="">Selecciona la Ciudad</option>
                                </select>    
                        </div>
                    </div>
                    <div class="content-mini-box-row">
                        <div class="mini-box-cell-50">
                            
                        </div>
                        <div class="mini-box-cell-50">
                            
                        </div>
                    </div>
                    <div class="content-mini-box-row">
                        <label for="direccion" class="required">Dirección</label>
                        <input type="text" id="dir" name="dir" required="required"    class="text-input-100" />
                    </div>
                    <div class="mini-box-row">
                        <div class="mini-box-cell-50">
                            <label for="cp" class="required">Código postal</label>
                            <input type="text" id="cp" name="cp"  class="text-input-alta" />
                        </div>
                    </div>
                    <div class="content-mini-box-row">
                        <div class="mini-box-cell-50">
                            <label for="contacto" class="required">Contacto</label>
                            <input type="text" id="contacto" name="contacto" class="text-input-alta" value="" />
                        </div>
                        <div class="mini-box-cell-50">
                            <label for="tel" class="required">Teléfono</label>
                            <input type="text" id="tel" name="tel"   class="text-input-alta" value="" />
                        </div>
                    </div>
                    <div class="content-mini-box-row">
                        <button class="btn btn-danger" type="submit">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
			</div>
		</div>
		<footer id="footer">	
	<div id="container-footer-especialidades">
			<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li> </li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                            </ul>
        </div>
        
        
    </div>
    <div id="footer-aside">
        <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                <li><a href="/publicaciones/1"></a></li>
                <li><a href="/oposiciones/1"></a></li>
            </ul>
        </div>
        <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                <li>
                    
                </li>
                <li>
                    
                </li>
                <li>
                    
                </li>
                            </ul>
        </div>
        
        
    </div>
    <div id="footer-aside">
        <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                <li></li>
                <li></li>
            </ul>
        </div>
        <div class="footer-box">
            <ul class="footer-box-list">
                <li class="footer-box-list-title"></li>
                <li>
                    
                </li>
                <li>
                    
                </li>
                <li>
                    
                </li>
							</ul>
		</div>
		
		
	</div>
	<div id="footer-aside">
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
				<li></li>
				<li></li>
			</ul>
		</div>
		<div class="footer-box">
			<ul class="footer-box-list">
				<li class="footer-box-list-title"></li>
				<li>
					
				</li>
				<li>
					
				</li>
				<li>
					
				</li>
			</ul>
		</div>
		<figure id="logo-footer">
			<img class="img-responsive img-thumbnail" src="img/log.jpg" alt="Logo de MedicalJob" title="MedicalJob, tu web de empleo médico" width="90%" />
		</figure>
		<div id="info-footer">
			<b>Copyright &copy; 2018 </b><br />
			<a href="informacion-legal.php">Información legal</a><br />
			<a href="politica-privacidad.php">Política de privacidad</a> |
			<a href="normativa.php">Normativa</a> |
			<a href="contacto.php">Contacto</a>
		</div>	
	</div>
	
		
</footer>	</div>
                
        		<script src="js2/router.js"></script>
	<script src="js2/routing?callback=fos.Router.setData"></script>
	<script src="js2/jquery-1.9.1.min.js"></script>
    <script src="js2/jquery-ui-1.10.3.custom.min.js"></script>
	<script src="js2/frontend.js"></script>
	<script src="js2/bootstrap.js"></script>
			<script src="js2/empresa.js"></script>
	 

	<script type="text/javascript" src="js2/empresa.js"></script>
	<script type="text/javascript">
        $(document).ready(function(){
                					$("#mediempleo_empleobundle_centrotype_ciudadOtras").val("");
		        });
	</script>
        <script type="text/javascript">

$(document).ready(function() {

  $("#cmbpais2").change(function(){
          
      var id=$("#cmbpais2").val();
      $('#cmbciudad2').load('escoger2.php?id='+id);
});
});  
</script>     
		
    </body>
</html>
