<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
include("conexion.php");


if (isset($_POST["fecha"])) {
	$fecha = $_POST["fecha"];
}

if (isset($_POST["desc"])) {
	$descrip = $_POST["desc"];
}

if (isset($_POST["conv"])) {
	$conv = $_POST["conv"];
}


if (isset($_POST["titulo"])) {
	$titulo = $_POST["titulo"];
}

if (isset($_POST["plazas"])) {
	$plazas = $_POST["plazas"];
}







$sql = "INSERT INTO oposiciones (fecha,descripcion, convocante,titulacion, plazas) VALUES (:fecha,:descrip,:conv, :titulo, :plazas)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':fecha', $fecha, PDO::PARAM_STR);
$stmt->bindParam(':descrip', $descrip, PDO::PARAM_STR);
$stmt->bindParam(':conv', $conv, PDO::PARAM_STR);
$stmt->bindParam(':titulo', $titulo, PDO::PARAM_STR); 
$stmt->bindParam(':plazas', $plazas, PDO::PARAM_STR); 
 
$stmt->execute();

 
?>

<script>
alert('La oposición a sido agregada exitosamaente');
window.location.href='agregaroposicion.php';
</script>

</body>
<html>