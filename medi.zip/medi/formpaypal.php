<!DOCTYPE html>
<html>
<?php 
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}


if(isset($_POST['id'])) {
$pa= $_POST['id'];}


?>
<head>
	<title></title>
</head>
<body>
<form name="myform" action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" target="_top">

<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="cancel_return" value="www.medicaljob.com.ar/medicaljob/x.php">
<input type="hidden" name="return" value="www.medicaljob.com.ar/medicaljob/exito.php">
<input type="hidden" name="business" value="hqmus-facilitator@hotmail.com">
<input type="hidden" name="lc" value="C2">
<input type="hidden" name="item_name" value="Compra Curriculum">
<input type="hidden" name="item_number" value="3456">
<input type="hidden" name="amount" value="<?php echo $pa; ?>">
<input type="hidden" name="currency_code" value="USD">
<input type="hidden" name="button_subtype" value="services">
<input type="hidden" name="no_note" value="0">
<script type="text/javascript">
	document.myform.submit();
</script>
<?php 
echo "Formulario enviado";
?>
</body>
</html>


