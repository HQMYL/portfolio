                                                                                                                                                                                                                                                                                                                                                                                                >
<html>
<head></head>                                                                                       
<body>
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}


$cvtexto = "";
if (isset($_POST["cvtexto"])) {
	$cvtexto = utf8_decode($_POST["cvtexto"]);
}

$nombre_cv = "";
if (isset($_FILES['archivo']['name'])) {
   
$nombre_cv = $_FILES['archivo']['name'];
}


$tipo = $_FILES['archivo']['type'];
$tamano = $_FILES['archivo']['size'];
 
//Si existe imagen y tiene un tamaño correcto
if (($nombre_cv == !NULL) && ($_FILES['archivo']['size'] <= 200000)) 
{
   //indicamos los formatos que permitimos subir a nuestro servidor
   if (($_FILES["archivo"]["type"] == "application/pdf")
   || ($_FILES["archivo"]["type"] == "application/msword"))
   

      $directorio = "";
      // Ruta donde se guardarán los archivos que subamos
      $directorio = "subidas/";
      // Muevo el archivo desde el directorio temporal a nuestra ruta indicada anteriormente
      move_uploaded_file($_FILES['archivo']['tmp_name'],$directorio.$nombre_cv);
      $nombre_cv = $directorio.$nombre_cv;
   }

$sql = "INSERT INTO pdf(usuario, archivo) VALUES(:usuario,:nombre_cv)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':nombre_cv',$nombre_cv, PDO::PARAM_STR);
$stmt->execute();

 
?>
<script>
alert('El Curriculum a sido agregado exitosamaente');
window.location.href='curriculum.php';
</script>



</body>
<html>