<!DOCTYPE html>
<html>
<?php
session_start();
$usuario = "";
$credi = "";
$resta = "";
include("db.php"); 
include("conexion.php");
include("data.php"); 

if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
?>
<head>
	<title></title>
</head>
<body>
	<?php
$credi = array();
$sql = "SELECT * FROM usuarios WHERE usuario ='".$usuario."'";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row) { 

$credi[0] = $row->creditos;

}


$monto = $credi[0];

$resta = 3;


if ($monto < $resta) {

header('Location: acciones-avanzadas.php');
}


else {

$monto = $monto -$resta;


$c = 1;
$sql2 = " UPDATE usuarios SET creditos =:monto, pagocurri=:c WHERE usuario =:usuario ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':monto', $monto, PDO::PARAM_STR); 
 $stmt2->bindParam(':c', $c, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();

}

?>

<script>
	alert('La Compra se ha realizado exitosamaente');
window.location.href='compras-curriculum.php';


</script>
</body>
</html>





