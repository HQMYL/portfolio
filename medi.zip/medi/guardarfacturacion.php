<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
include("conexion.php");


if (isset($_POST["razon"])) {
	$razon = $_POST["razon"];
}

if (isset($_POST["cif"])) {
	$cif = $_POST["cif"];
}

if (isset($_POST["correo"])) {
	$correo = $_POST["correo"];
}


if (isset($_POST["cmbpais"])) {
	$pais = $_POST["cmbpais"];
}

if (isset($_POST["cmbciudad"])) {
	$ciudad = $_POST["cmbciudad"];
}

if (isset($_POST["dir"])) {
	$dir = $_POST["dir"];
}

if (isset($_POST["correo"])) {
	$correo = $_POST["correo"];
}



if (isset($_POST["dir"])) {
	$dir = utf8_decode($_POST["dir"]);
}





if (isset($_POST["cp"])) {
	$codigo = $_POST["cp"];
}



if (isset($_POST["contacto"])) {
	$contacto = $_POST["contacto"];
}

if (isset($_POST["tel"])) {
	$tel = $_POST["tel"];
}



$sql = "INSERT INTO facturacion (social, cif,correo,pais,ciudad, direccion, Codigopostal,contacto,telefono) VALUES (:social,:cif,:correo,:pais,:ciudad,  :dir, :cp, :contacto, :tel)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':social', $social, PDO::PARAM_STR);
$stmt->bindParam(':cif', $cif, PDO::PARAM_STR);
$stmt->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt->bindParam(':pais', $pais, PDO::PARAM_STR); 
$stmt->bindParam(':ciudad', $ciudad, PDO::PARAM_STR); 
$stmt->bindParam(':dir', $dir, PDO::PARAM_STR);
$stmt->bindParam(':cp', $cp, PDO::PARAM_STR);
$stmt->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt->execute();

 
?>

<script>
alert('Los datos de Facturación han sido agregados exitosamente');
var 
window.location.href='datos-facturacion.php';
</script>

</body>
<html>