<?php
//include PayPalPro PHP library
require('PaypalPro.class.php');

if($_SERVER['REQUEST_METHOD'] == 'POST'){
	//product details
	$itemName = "Premium Project Purchase";
	$itemNumber = "PPP123456";
    $payableAmount = $_POST['canti'];;
	$currency = "USD";
    
    //buyer information
	$name = $_POST['name_on_card'];
	$nameArr = explode(' ', $name);
    $firstName = $nameArr[0];
    $lastName = $nameArr[1];
    $city = 'Charleston';
    $zipcode = '25301';
    $countryCode = 'US';
	
	//card details
	$creditCardNumber = trim(str_replace(" ","",$_POST['card_number']));
	$creditCardType = $_POST['card_type'];
	$expMonth = $_POST['expiry_month'];
	$expYear = $_POST['expiry_year'];
	$cvv = $_POST['cvv'];
    
    //Create an instance of PaypalPro class
	//$config = array('live'=>1);
	$config = array(
		'apiUsername' => 'kalel_api1.hotmail.com',
		'apiPassword' => '9HUENTTAEDEP9KSZ',
		'apiSignature' => 'AZH3KgIjZU63xDUvtZoAtxOm-SXBAiqQ4jqlMSKZOMbBPh3w4ELVZ1-X'

	);
	$paypal = new PaypalPro($config);
	
	//Payment details
    $paypalParams = array(
        'paymentAction' => 'Sale',
		'itemName' => $itemName,
		'itemNumber' => $itemNumber,
        'amount' => $payableAmount,
        'currencyCode' => $currency,
        'creditCardType' => $creditCardType,
        'creditCardNumber' => $creditCardNumber,
        'expMonth' => $expMonth,
        'expYear' => $expYear,
        'cvv' => $cvv,
        'firstName' => $firstName,
        'lastName' => $lastName,
        'city' => $city,
        'zip'	=> $zipcode,
        'countryCode' => $countryCode,
    );
    $response = $paypal->paypalCall($paypalParams);
    $paymentStatus = strtoupper($response["ACK"]);
    if($paymentStatus == "SUCCESS"){
		//transaction info
		$transactionID = $response['TRANSACTIONID'];
		$amount = $response['AMT'];
        $date = date("Y-m-d H:i:s");
		
		//include database config file
        include_once 'dbConfig.php';
		
		//insert tansaction data into the database
        $sql = "INSERT INTO orders(name,email,card_num,card_exp_month,card_exp_year,card_cvc,item_name,item_number,item_price,item_price_currency,paid_amount,paid_amount_currency,txn_id,payment_status,created,modified) VALUES('".$name."','','".$creditCardNumber."','".$expMonth."','".$expYear."','".$cvv."','".$itemName."','".$itemNumber."','".$payableAmount."','".$currency."','".$amount."','".$currency."','".$transactionID."','".$paymentStatus."','".$date."','".$date."')";
        $insert = $db->query($sql);
        $last_insert_id = $db->insert_id;
		
		$data['status'] = 1;
        $data['orderID'] = $last_insert_id;
    }else{
         $data['status'] = 0;
    }
	//transaction status
    echo json_encode($data);
}
?>