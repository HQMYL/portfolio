<!DOCTYPE html>
<?php
session_start();
include("conexion.php");
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
?>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DemiJob</title>

    <!-- Bootstrap Core CSS -->
    <link href="css3/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css3/sb-admin.css" rel="stylesheet">
    <link href="css3/new.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css3/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
        .navbar-brand {
color: blue;
}
    a {
            color: #fff;
        }
    </style>
    <script>
function recargar(){   
       /// Aqui podemos enviarle alguna variable a nuestro script PHP
    var US= document.getElementById("usuario").value;
       /// Invocamos a nuestro script PHP
    $.post("combo.php", { id: US }, function(data){
       /// Ponemos la respuesta de nuestro script en el DIV recargado
    $("#consi").html(data);
    });        
}
</script>

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" style="color: #fff;" href="admin.php">Inicio</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
               <li><a style="color: #fff;" class="btn btn-danger"><?php echo "Bienvenido: " .$usuario; ?></a></li>
              <li><a style="color: #fff;" class="btn btn-danger" href="logout.php">Cerrar Sesión</a></li> 
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="admin.php"><i class=""></i> Panel de Control</a>
                    </li>
                    
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo"><i></i> Usuarios <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="agregarusuario.php">Agregar Usuario</a>
                            </li>
                            <li>
                                <a href="consultarusuario.php">Consultar Usuario</a>
                            </li>
                            <li>
                                <a href="actualizarusuario.php">Actualizar Usuario</a>
                            </li>
                            <li>
                                <a href="eliminarusuario.php">Eliminar Usuario</a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo1"> Empresas <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo1" class="collapse">
                            <li>
                                <a href="agregarempresa.php">Agregar Empresa</a>
                            </li>
                            <li>
                                <a href="consultarempresa.php">Consultar Empresa</a>
                            </li>
                            <li>
                                <a href="actualizarempresa.php">Actualizar Empresa</a>
                            </li>
                            <li>
                                <a href="eliminarempresa.php">Eliminar Empresa</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo3"><i></i> Empleos <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo3" class="collapse">
                            <li>
                                <a href="agregarempleo.php">Agregar Empleos</a>
                            </li>
                            <li>
                                <a href="consultarempleo.php">Consultar Empleo</a>
                            </li>
                            <li>
                                <a href="actualizarempleo.php">Actualizar Empleo</a>
                            </li>
                            <li>
                                <a href="eliminarempleo.php">Eliminar Empleo</a>
                            </li>
                        </ul>
                    </li>
                   <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo4"><i></i> Oposiciones <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo4" class="collapse">
                            <li>
                                <a href="agregaroposicion.php">Agregar Oposición</a>
                            </li>
                            <li>
                                <a href="consultaroposicion.php">Consultar Oposición</a>
                            </li>
                            <li>
                                <a href="actualizaroposicion.php">Actualizar Oposición</a>
                            </li>
                            <li>
                                <a href="eliminaroposicion.php">Eliminar Oposición</a>
                            </li>
                        </ul>
                    </li>
                     <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo5"><i></i> Reportes <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo5" class="collapse">
                            <li>
                                <a href="ventas.php">Ventas</a>
                            </li>
                            <li>
                                <a href="creditos-adquiridos.php">Creditos Adquiridos</a>
                            </li>
                            
                        </ul>
                    </li>


                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header">
                            LISTADO DE CREDITOS COMPRADOS 
                        </h3>
                        <ol class="breadcrumb">
                            
                        </ol>
                    </div>
                </div>
                <div>    
 
             
             <div id="consi" class="table-responsive">
 

<table class="table table-bordered table-hover">
    <thead>
        <tr>
           <th>Nombre Comprador</th>
           <th>Fecha</th>
           <th>Estado</th> 
        </tr>
    </thead>
<tbody>
    <?php
         $sql = "SELECT * FROM creditos";

$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

foreach ($rows as $row->id => $row) { ?>   
<tr>
<td><?php echo utf8_encode($row->usuario); ?></td>
<td><?php echo utf8_encode($row->fecha); ?></td>
<td><?php echo utf8_encode($row->status); ?></td>

</tr>
</tbody>

<?php } ?>


  </div>
                
            </div>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js3/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js3/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js3/plugins/morris/raphael.min.js"></script>
    <script src="js3/plugins/morris/morris.min.js"></script>
    <script src="js3/plugins/morris/morris-data.js"></script>

</body>

</html>
