<!doctype html>
<html>

<body>
<?php 
include("conexion.php");
if (isset($_GET['id'])) {
	$id = $_GET['id'];
}

$sql = "DELETE FROM notificaciones WHERE id=:id";
$stmt = $con->prepare($sql);
$stmt->bindParam(':id', $id, PDO::PARAM_STR); 
$stmt->execute();

?>
<script>
alert('La notificación a sido Eliminada exitosamaente');
window.location.href='notificaciones-pendientes.php';
</script>
</body>
</html>
