<?php 
if (isset($_POST["subir"])) {

switch ($_FILES["archivo"] ["error"]) {
	case 0:
		$mensaje = "su archivo se ha subido correctamente";
		break;
	case 1:
		$mensaje = $_FILES['archivo'] ['name'] . "es demasiado grande";
		break;
	
   case 7:
   	$mensaje = "No dispone de permisos suficientes para subir el archivo";
   	break;


	default:
		$mensaje = "No se ha podido subir";
		break;
}



}

?>


<!DOCTYPE html>
<html>
<head>
	<title>Subida de Archivos</title>
</head>
<body>
<form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
	<input type="hidden" name="MAX_FILE_SIZE" value="80000">
	<label for="archivo">Seleccione su Archivo</label>
<input type="file" name="archivo" id="archivo">
<input type="submit" name="subir" value="Subir Archivo">	
</form>
</body>
</html>