<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php

session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}


if (isset($_POST["contacto"])) {
	$contacto = utf8_decode($_POST["contacto"]);
}




if (isset($_POST["social"])) {
	$social = $_POST["social"];
}


if (isset($_POST["correo"])) {
	$correo = utf8_decode($_POST["correo"]);
	
}

else {
	$correo = "N/A";
}



if (isset($_POST["dir"])) {
	$dir = utf8_decode($_POST["dir"]);
	
}

else {
	$dir = "N/A";
}


if (isset($_POST["num"])) {
	$num = utf8_decode($_POST["num"]);
	
}


if (isset($_POST["piso"])) {
	$piso = utf8_decode($_POST["piso"]);
	
}

else {
	$piso = "N/A";
}

if (isset($_POST["dep"])) {
	$dep = utf8_decode($_POST["dep"]);
	
}

else {
$dep = "N/A";
} 



if (isset($_POST["cp"])) {
	$cp = utf8_decode($_POST["cp"]);
	
}

else {
	$cp = "0";
}


if (isset($_POST["loc"])) {
	$loc = utf8_decode($_POST["loc"]);
	
}

else{
$loc ="0";	
}
 


if (isset($_POST["provincia"])) {
	$prov = utf8_decode($_POST["provincia"]);
	
}

else{
	$prov = "N/A";
}





if (isset($_POST["nacional"])) {
	$nacional = utf8_decode($_POST["nacional"]);
	
}

else {
	$nacional = "N/A";
}



if (isset($_POST["provincial"])) {
	$provincial = utf8_decode($_POST["provincial"]);
	
}

else {
	$provincial = "N/A";
}



if (isset($_POST["tel1"])) {
	$tel1 = $_POST["tel1"];
}
else {
	$tel1 = "0";
}



if (isset($_POST["tel2"])) {
	$tel2 = $_POST["tel2"];
}
else {
	$tel2 = "0";
}


if (isset($_POST["user"])) {
	$user = $_POST["user"];
}

if (isset($_POST["pass"])) {
	$pass = $_POST["pass"];
}




if (isset($_POST["tipoem"])) {
	$tipoem = utf8_decode($_POST["tipoem"]);
}



$sth = $con->prepare("SELECT * FROM empresas WHERE user = ?");
$sth->bindParam(1, $user);

$sth->execute();

if ($sth->rowCount() > 0) {


	header('Location: agregarempresa.php');
}

else {



$tipo2 = "Empresa";

$creditos = "30000";

$sql = "INSERT INTO empresas (nombre,social,correo,dir, fijo,celular,numeroC,piso,departamento,codigoPostal,localidad,provincia,MatriculaNacional,MatriculaProvincial, user, pass, tipoem, tipo2,creditos) VALUES (:contacto,:social,:correo,:dir,:tel1,:tel2,:num,:piso,:dep,:cp, :loc,:prov,:nacional,:provincial, :user, :pass, :tipoem, :tipo2,:creditos)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':contacto', $contacto, PDO::PARAM_STR); 
$stmt->bindParam(':social', $social, PDO::PARAM_STR);
$stmt->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt->bindParam(':dir', $dir, PDO::PARAM_STR); 
$stmt->bindParam(':tel1', $tel1, PDO::PARAM_STR);
$stmt->bindParam(':tel2', $tel2, PDO::PARAM_STR);
$stmt->bindParam(':num', $num, PDO::PARAM_STR);
$stmt->bindParam(':piso', $piso, PDO::PARAM_STR);
$stmt->bindParam(':dep', $dep, PDO::PARAM_STR);
$stmt->bindParam(':cp', $cp, PDO::PARAM_STR);
$stmt->bindParam(':loc', $loc, PDO::PARAM_STR);
$stmt->bindParam(':prov', $prov, PDO::PARAM_STR);
$stmt->bindParam(':nacional', $nacional, PDO::PARAM_STR);
$stmt->bindParam(':provincial', $provincial, PDO::PARAM_STR);
$stmt->bindParam(':user', $user, PDO::PARAM_STR);
$stmt->bindParam(':pass', $pass, PDO::PARAM_STR);
$stmt->bindParam(':tipoem', $tipoem, PDO::PARAM_STR);
$stmt->bindParam(':tipo2', $tipo2, PDO::PARAM_STR); 
$stmt->bindParam(':creditos', $creditos, PDO::PARAM_STR); 
$stmt->execute();

} // final else

?>


<script>
alert('La Empresa a sido agregada exitosamaente');
window.location.href='agregarempresa.php';
</script>

</body>
<html>