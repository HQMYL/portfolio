<!DOCTYPE html>
<html lang="es">
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
?>
    <head>
        <meta charset="UTF-8" />
		<meta name="description" content="Centros, clínicas y empresas en bolsa de empleo con ofertas de trabajo de enfermera, médico y auxiliar en enfermería en el sector de salud" />
		        <title>Centros y empresas con ofertas de trabajo médico y de enfermería</title>
        <!--[if lt IE 9]>
        	<script src="/bundles/comun/js/html5shiv.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
                <link rel="stylesheet" type="text/css" href="css2/css.css" />
        		<link rel="stylesheet" type="text/css" href="/bundles/comun/css/reset.css" />
    <link rel="stylesheet" type="text/css" href="css2/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css2/frontend.css" />
	<link rel="stylesheet" type="text/css" href="css2/forms.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery.fancybox.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery-ui-1.10.3.custom.min.css" />

    <link rel="stylesheet" type="text/css" href="css2/centros-empresas.css" />
    <link rel="stylesheet" type="text/css" href="css2/empresa.css" />
    <link rel="stylesheet" type="text/css" href="css2/extranet.css" />
    <link rel="stylesheet" type="text/css" href="css3/new.css" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="apple-touch-icon" sizes="114x114" href="" />
        <link rel="apple-touch-icon" sizes="72x72" href="" />
        <link rel="apple-touch-icon" href="" />
    <script type="text/javascript" src="js2/main.js" charset="UTF-8"></script>

<style type="text/css">
body {
        background-color: #FFA500;
        
       }

   
</style>



</head>
    <body itemscope itemtype="http://schema.org/WebPage">
		<div id="cargando" style="display:none"></div>
		    				        		<div id="pagina">
		<header id="header">
			<div id="banner">
				<img class="img-responsive" src="img/portada.jpg" alt="MedicalJob: Trabaja en el sector sanitario en cualquier parte del mundo" />
			</div>
					</header>
		<div id="contenido">
			<div id="breadcrumb" itemprop="breadcrumb">
								<a href="index.php">
					<span class="glyphicon glyphicon-home"></span> Inicio
				</a> > 
			 Centros / Empresas 
			</div>
					
			<aside id="sidebar">
			    				<div id="contadores">
	<div class="contador contador-profesionales">
		<div class="cifra-contador">
            <?php
            $sql = "SELECT * FROM usuarios"; 
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
$total = 0;
foreach ($rows as $row) {
$total = $total + 1;
}
?>
			<strong><?php echo $total; ?></strong>
		</div>
		<div class="texto-contador">profesionales<br />sanitarios</div>
	</div>
	<div class="contador contador-empresas">
		<div class="cifra-contador">
            <?php
            $sql = "SELECT * FROM empresas"; 
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
$total = 0;
foreach ($rows as $row) {
$total = $total + 1;
}
?>
			<strong><?php echo $total; ?></strong>
		</div>
		<div class="texto-contador">centros y<br />empresas</div>
	</div>
	</div>									<h2 class="titulo-sidebar-box">REGÍSTRATE, ES GRATIS</h2>
					<div class="sidebar-box">
						<a href="usuario.php" class="boton-registro boton-registro-profesionales">
	soy <br />profesional <br />sanitario
</a>
<a href="empresa.php" class="boton-registro boton-registro-empresas">
	soy <br />centro o <br />empresa
</a>
					</div>
					<h2 class="titulo-sidebar-box">ACCEDE A TU CUENTA</h2>
					<div class="sidebar-box sidebar-box-bordered">
						 
	<form id="login" action="validar.php" method="post" style="width:90%;margin:10px auto">
		<div class="form-widget-container">
			<label for="input-login">USUARIO</label>
			<input type="text" required="required" id="user" name="user" class="text-input-border" />
		</div>
		<div class="form-widget-container">
			<label for="input-password">CONTRASEÑA</label>
			<input type="password"  id="pass" name="pass" class="text-input-border" />
		</div>
		<div class="form-widget-container">
			<input type="checkbox" id="input-remember-me" name="_remember_me" checked />
			<label id="recuerdame" for="input-remember-me">No cerrar sesión</label>
			<input type="submit" id="submit-login" class="button button-blue submit" value="Acceder"/>
		</div>
		<div class="form-widget-container">			
			<p><strong style="font-size:9px"><a href="recuperar-contrasena.html">¿Olvidaste tu contraseña?</a></strong></p>
		</div>
	</form>
					</div>
			<!-- CARRUSEL -->

 <section>
                  
                  <div id="slider-container">
                      <div id="slider-box">
                          <div class="slider-element">
                              <article class="element-red">
                              <img class="img-responsive img-thumbnail" src="img/italiano.png">  
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-green">
                               <img class="img-responsive img-thumbnail" src="img/cposgrado.jpg">     
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-blue">
                                <img class="img-responsive img-thumbnail" src="img/cruz.png">  
                              </article>                            
                          </div>
                      </div>
                  </div>
                  
              </section>        


       <!-- CARRUSEL -->
        						
    <div class="sidebar-box">
        
     </div>
     			</aside>
		
			<div id="content-right">
				<div style="float:left;width:100%">
	</div>				        <div id="myCarousel" class="carousel slide" style="margin-bottom:20px">
            <!-- Carousel items -->
            <div class="carousel-inner">
                <div class="active item">
                    <figure>
                        <img src="img/mediempleo-centros-banner.jpg" 
                        	style="float:left;"
                        	alt="PUBLICA GRATIS TUS OFERTAS DE EMPLEO" 
                        	title="PUBLICA GRATIS TUS OFERTAS DE EMPLEO" />
                        <figcaption style="border: 1px solid #CCCCCC;font-size: 11px;width:37%;height: 141px; float:left; padding: 9px 6px 2px 10px;">
                            <h1 style="font-size:16px">PUBLICA GRATIS TUS OFERTAS DE EMPLEO</h1>
                            <p style="margin:0%">
                                Con MedicalJob podrás publicar de manera totalmente gratuita tantas ofertas de empleo como necesites.<br />
								Además puedes utilizar nuestros créditos MedicalJob para darle más visibilidad o urgencia.
                            </p>
                                                    </figcaption>
                    </figure>
                </div>
                <div class="item">
                    <figure>
                        <img src="img/slider-centros-1.jpg" 
                        	style="float:left;"
                        	alt="PUBLICA GRATIS TU OFERTA DE EMPLEO"
                        	title="PUBLICA GRATIS TU OFERTA DE EMPLEO" />
                        <figcaption style="border: 1px solid #CCCCCC;font-size: 11px;width:37%;height: 141px; float:left; padding: 9px 6px 2px 10px;">
                            <h1 style="font-size:16px">PUBLICA GRATIS TU OFERTA DE EMPLEO</h1>
                            <p style="margin:0%">
                                Con MedicalJob podrás publicar de manera totalmente gratuita tantas ofertas de empleo como necesites.<br />
								Además puedes utilizar nuestros créditos MedicalJob para darle más visibilidad o urgencia.
                            </p>
                        </figcaption>
                    </figure>
                </div>
                <div class="item">
                    <figure>
                        <img src="img/slider-centros-2.jpg" 
                        	style="float:left;"
                        	alt="RECIBE EN TU INBOX LOS CURRICULUMS DE TODOS LOS CANDIDATOS INTERESADOS"
                        	title="RECIBE EN TU INBOX LOS CURRICULUMS DE TODOS LOS CANDIDATOS INTERESADOS" />
                        <figcaption style="border: 1px solid #CCCCCC;font-size: 11px;width:37%;height: 141px; float:left; padding: 9px 6px 2px 10px;">
                            <h1 style="font-size:16px">RECIBE EN TU INBOX LOS CURRICULUMS DE TODOS LOS CANDIDATOS INTERESADOS</h1>
                            <p style="margin:0%">
                                Recibirás en tu bandeja de entrada todos los curriculums de los candidatos interesados en tu oferta y comienza a decidir que perfiles son los más adecuados a tu centro.
                            </p>
                        </figcaption>
                    </figure>
                </div>
                <div class="item">
                    <figure>
                        <img src="img/slider-centros-3.jpg" 
                        	style="float:left;"
                        	alt="ESTUDIA LOS CURRICULUMS RECIBIDOS Y SELECCIONA LOS QUE TE INTERESEN"
                        	title="ESTUDIA LOS CURRICULUMS RECIBIDOS Y SELECCIONA LOS QUE TE INTERESEN" />
                        <figcaption style="border: 1px solid #CCCCCC;font-size: 11px;width:37%;height: 141px; float:left; padding: 9px 6px 2px 10px;">
                            <h1 style="font-size:16px">ESTUDIA LOS CURRICULUMS RECIBIDOS Y SELECCIONA LOS QUE TE INTERESEN</h1>
                            <p style="margin:0%">
                                Podrás acceder al contenido de cada uno de los curriculums inscritos en tu oferta seleccionando aquellos que encajen con tus exigencias.
                            </p>
                        </figcaption>
                    </figure>
                </div>
                <div class="item">
                    <figure>
                        <img src="img/slider-centros-4.jpg" 
                        	style="float:left;"
                        	alt="PAGA SOLAMENTE POR LOS CURRICULUMS QUE HAYAS SELECCIONADO"
                        	title="PAGA SOLAMENTE POR LOS CURRICULUMS QUE HAYAS SELECCIONADO" />
                        <figcaption style="border: 1px solid #CCCCCC;font-size: 11px;width:37%;height: 141px; float:left; padding: 9px 6px 2px 10px;">
                            <h1 style="font-size:16px">PAGA SOLAMENTE POR LOS CURRICULUMS QUE HAYAS SELECCIONADO</h1>
                            <p style="margin:0%">
                                Utiliza tus créditos para comprar únicamente los curriculums que te interesen, Mediempleo es el único portal exclusivo del sector sanitario que <strong>VA A ÉXITO</strong>, es decir, <strong>SÓLO PAGAS SI TE GUSTA LO QUE VES</strong>.
                            </p>
                        </figcaption>
                    </figure>
                </div>
            </div>
                    </div>
        <div style="width: 100%; float: left;">
        	
        	<div id="como-usar-mediempleo">
        		<h1><strong>¿CÓMO PUEDO USAR MEDICALJOB?</strong></h1>
        		<h2><strong><span class="green mayor">#1</span>
        			 PUBLICA TU OFERTA </strong>DE EMPLEO GRATIS 
        			<a href="publicar-ofertas.php"><span class="green menor">(+INFO)</span></a></h2>
        		<h2><strong><span class="green mayor">#2</span>
        			 BUSCADOR ONLINE </strong>DE CANDIDATOS 
        			<a href="lista-candidatos.php"><span class="green menor">(PROBAR)</span></a></h2>
        		<h2><strong><span class="green mayor">#3</span>
        			 NAVEGA POR LA BBDD Y CONTACTA DIRECTAMENTE CON UN CANDIDATO</strong> 
        			<a href="empresa.php"><span class="green menor">(REGISTRATE GRATIS)</span></a></h2>
        		<h2><strong><span class="green mayor">#4</span>
        			 BENEFICIATE DE NUESTRO SISTEMA DE CREDITOS PARA MEJORAR TUS OFERTAS </strong> 
        			<a href="wiki-empresas.php"><span class="green menor">(+INFO)</span></a></h2>
        		<h3><strong>ADEMÁS</strong></h3>
        		<p><span class="green">> </span>Te regalamos tu primer candidato sólo por registrarte.</p>
        		<p><span class="green">> </span>Tenemos tu candidato ideal. Busca gratis y sólo paga por los que te interesen.</p>
        		<p><span class="green">> </span></p>
        		<p><span class="green">> </span>Accede a nuestra base de datos especializada en el sector sanitario.</p>
        		<p><span class="green">> </span>Sólo por registrarte te regalamos 50 créditos.</p>
        	</div>
        </div>
        <div style="border:1px solid #CCCCCC;width:99.6%;float:left;margin-top:10px">
			<div id="grupo-colectivos" style="float:left;width:100%;max-height:145px;overflow:hidden;">
        	            				
				</div>
											</div>
							
						</div>
							
			        </div>
			</div>
		</div>
		<footer id="footer">	
	<div id="container-footer-especialidades">
            <div class="footer-box">
            <ul class="footer-box-list">
                
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                            </ul>
        </div>
            <div class="footer-box">
            <ul class="footer-box-list">
                
                            </ul>
        </div>
        
        
    </div>
    <div id="footer-aside">
        <div class="footer-box">
            <ul class="footer-box-list">
                
            </ul>
        </div>
        <div class="footer-box">
            <ul class="footer-box-list">
                
            </ul>
        </div>
        <figure id="logo-footer">
            <img class="img-responsive img-thumbnail" src="img/log.jpg" alt="Logo de MedicalJob" title="MedicalJob, tu web de empleo médico" width="90%" />
        </figure>
        <div id="info-footer">
            <b>Copyright &copy; 2018 </b><br />
            <a href="informacion-legal.php">Información legal</a><br />
            <a href="politica-privacidad.php">Política de privacidad</a> |
            <a href="normativa.php">Normativa</a> |
            <a href="contacto.php">Contacto</a>
        </div>  
    </div>
	
		
</footer>	</div>
                
        		<script src="js2/router.js"></script>
	<script src="js2/routing?callback=fos.Router.setData"></script>
	<script src="js2/jquery-1.9.1.min.js"></script>
    <script src="js2/jquery-ui-1.10.3.custom.min.js"></script>
	<script src="js2/frontend.js"></script>
	<script src="js2/bootstrap.js"></script>
    <script src="js2/angular.min.js"></script>
    <script src="js2/ng-table.js"></script>
	<script type="text/javascript" src="js2/jquery.fancybox.pack.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$("a[rel='fancybox']").fancybox({
				'transitionIn'	:	'elastic',
				'transitionOut'	:	'elastic',
				'speedIn'		:	600, 
				'speedOut'		:	200, 
				'overlayShow'	:	true,
				'type'			:	'iframe',
				'showNavArrows': 	false
			});
		});
	</script>

	<script>
	    $(document).ready(function(){
	        $('.carousel').carousel({
	    	        interval:5000
	        });
	    });
	</script>
	<script id="template-resultados-busqueda" type="text/template">
    <div style="width:94%;" class="content">
        <div class='box-title'>
            <h1>LISTADO DE CANDIDATOS</h1>
        </div>
        <div class='box-subtitle resultados-busqueda'>Mostrando <span id='num-items'>#num-resultados#</span> de <strong>#total#</strong></div>
        <div class="box-content">
            <table id='tabla-candidatos' class='resultados-busqueda'>
                <thead>
                    <th>#</th>
                    <th>Nombre</th>
                    <th>Colectivo</th>
                    <th>País</th>
                    <th>Provincia</th>
                    <th>Ciudad</th>
                    <th>Ficha</th>
                </thead>
</script>

<script id="template-notificar" type="text/template">
      	<div class="box-title" style="width:50%!important;float:left;">
            <input type="button" class="button button-blue" value="Me interesan los seleccionados" id="notificar-usuarios" data-target="#ruta-notificar-candidatos#" />
       	</div>
</script>

<script id="template-boton-siguiente" type="text/template">
	<div class="box-title" style="width:50%!important;float:right;text-align:right">
        <input type="button" id="buscar-candidatos-siguiente" data-offset="#offset#" value="Ver más >" class="button button-blue"/>
    </div>
</script>

<script id="template-btn-add-idioma" type="text/template">
    <div class="width-100" style="border-top:0.5px solid #CCC;">
    </div>
    <div class="width-75" style="margin-top:15px">
        <label class="idiomas" for="idioma-<--id-->" style="width: 29.8%"></label>
        <input type="button" value="+" class="btn btn-default add-idioma-btn" style="float: left;font-weight: bold;height: 24px !important;margin-left: 5px;width: 20px !important;" />
    </div>
    <div class="width-100" id="nivel-idiomas">
        <label class="idiomas" for="tags" style="width: 22.5%;">Nivel</label>
        <div class="width-25">
            <label class="idiomas" for="nivel-escrito-idioma-<--id-->" style="width: 45%;">Escrito: </label>
            <select name="nivel-escrito-idioma-<--id-->" id="nivel-escrito-idioma-<--id-->" style="width:80%!important">
                <option value=""></option>
                <option value="Bajo">Bajo</option>
                <option value="Medio">Medio</option>
                <option value="Alto">Alto</option>
            </select>
        </div>
        <div class="width-25">
            <label class="idiomas" for="nivel-leido-idioma-<--id-->" style="width: 45%;">Leído: </label>
            <select name="nivel-leido-idioma-<--id-->" id="nivel-leido-idioma-<--id-->" style="width:80%!important">
                <option value=""></option>
                <option value="Bajo">Bajo</option>
                <option value="Medio">Medio</option>
                <option value="Alto">Alto</option>
            </select>
        </div>
        <div class="width-25">
            <label class="idiomas" for="nivel-hablado-idioma-<--id-->" style="width: 45%;">Hablado: </label>
            <select name="nivel-hablado-idioma-<--id-->" id="nivel-hablado-idioma-<--id-->" style="width:80%!important">
                <option value=""></option>
                <option value="Bajo">Bajo</option>
                <option value="Medio">Medio</option>
                <option value="Alto">Alto</option>
            </select>
        </div>
    </div>
</script>
       
    </body>
</html>