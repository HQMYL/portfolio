<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}



if (isset($_POST["cmbidioma"])) {
	$cmbidioma = utf8_decode($_POST["cmbidioma"]);
}


if (isset($_POST["nivel1"])) {
	$nivel1 = utf8_decode($_POST["nivel1"]);
}


if (isset($_POST["nivel2"])) {
	$nivel2 = utf8_decode($_POST["nivel2"]);
}



if (isset($_POST["nivel3"])) {
	$nivel3 = utf8_decode($_POST["nivel3"]);
}


$sql = "INSERT INTO idioma (usuario,idioma,nivelA, nivelE,nivelL) VALUES (:usuario,:cmbidioma,:nivel1, :nivel2,:nivel3)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt->bindParam(':cmbidioma', $cmbidioma, PDO::PARAM_STR);
$stmt->bindParam(':nivel1', $nivel1, PDO::PARAM_STR);
$stmt->bindParam(':nivel2', $nivel2, PDO::PARAM_STR); 
$stmt->bindParam(':nivel3', $nivel3, PDO::PARAM_STR); 
$stmt->execute();
 
?>

<script>
alert('El idioma a sido agregado exitosamaente');
window.location.href='curriculum.php';
</script>

</body>
<html>