<!doctype html>
<html>

<body>
<?php 
include("conexion.php");
if (isset($_GET['id'])) {
	$user = $_GET['id'];
}

$sql = "DELETE FROM oposiciones WHERE id=:user";
$stmt = $con->prepare($sql);
$stmt->bindParam(':user', $user, PDO::PARAM_STR); 
$stmt->execute();

?>
<script>
alert('La Oposición a sido Eliminada exitosamente');
window.location.href='eliminaroposicion.php';
</script>
</body>
</html>
