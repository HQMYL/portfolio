<!DOCTYPE HTML>
<html>
<head></head>
<body>
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}



if (isset($_POST["nombre"])) {
	$nombre = $_POST["nombre"];
}


if (isset($_POST["direccion"])) {
	$direccion = utf8_decode($_POST["direccion"]);
}


if (isset($_POST["tipo"])) {
	$tipo = utf8_decode($_POST["tipo"]);
}



if (isset($_POST["telefono"])) {
	$telefono = $_POST["telefono"];
}



if (isset($_POST["cmbpais"]) ) {
  $pais = utf8_decode($_POST["cmbpais"]);

  }

   

if (isset($_POST["cmbciudad"])) {
   $ciudad = utf8_decode($_POST["cmbciudad"]);
}



if (isset($_POST["descripcion"])) {
	$descripcion = utf8_decode($_POST["descripcion"]);
}

if (isset($_POST["NombreContacto"])) {
  $contacto = utf8_encode($_POST["NombreContacto"]);
}


if (isset($_POST["Correocontacto"])) {
  $correo = $_POST["Correocontacto"];
}


if (isset($_POST["telefonoContacto"])) {
  $tel = $_POST["telefonoContacto"];
}









$nombre_img = $_FILES['archivo']['name'];
$tipo = $_FILES['archivo']['type'];
$tamano = $_FILES['archivo']['size'];
 
//Si existe imagen y tiene un tamaño correcto
if (($nombre_img == !NULL) && ($_FILES['archivo']['size'] <= 800000)) 
{
   //indicamos los formatos que permitimos subir a nuestro servidor
   if (($_FILES["archivo"]["type"] == "image/gif")
   || ($_FILES["archivo"]["type"] == "image/jpeg")
   || ($_FILES["archivo"]["type"] == "image/jpg")
   || ($_FILES["archivo"]["type"] == "image/png"))
   
      // Ruta donde se guardarán las imágenes que subamos
      $directorio = "./img/";
      // Muevo la imagen desde el directorio temporal a nuestra ruta indicada anteriormente
      move_uploaded_file($_FILES['archivo']['tmp_name'],$directorio.$nombre_img);
      $nombre_img = $directorio.$nombre_img;
   }


$sql = " SELECT * FROM centros WHERE NombreContacto = '" .$usuario. "'";
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
foreach ($rows as $row) {

if( $nombre != $row->nombre)  {

$sql2 = " UPDATE centros SET  nombre=:nombre  WHERE NombreContacto =:usuario ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':nombre', $nombre, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();

}

if( $direccion != $row->direccion)  {

$sql2 = " UPDATE centros SET  direccion=:direccion  WHERE NombreContacto =:usuario ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':direccion', $direccion, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();

}


if( $tipo != $row->tipo)  {

$sql2 = " UPDATE centros SET  tipo=:tipo  WHERE NombreContacto =:usuario ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':tipo', $tipo, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();

}

if( $telefono != $row->telefono)  {

$sql2 = " UPDATE centros SET  telefono=:telefono  WHERE NombreContacto =:usuario ";
$stmt2 = $con->prepare($sql2);
 $stmt2->bindParam(':telefono', $telefono, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();

}

if( $ciudad != $row->ciudad)  {

$sql2 = " UPDATE centros SET  ciudad=:ciudad  WHERE NombreContacto =:usuario ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':ciudad', $ciudad, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();

}


if( $descripcion != $row->descripcion)  {

$sql2 = " UPDATE centros SET  descripcion=:descripcion  WHERE NombreContacto =:usuario ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':descripcion', $descripcion, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();

}

if( $nombre_img != $row->img)  {

$sql2 = " UPDATE centros SET  img=:nombre_img  WHERE NombreContacto =:usuario ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':nombre_img', $nombre_img, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();

}

if( $correo != $row->CorreoContacto)  {

$sql2 = " UPDATE centros SET  CorreoContacto=:correo  WHERE NombreContacto =:usuario ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':correo', $correo, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();

}

if( $tel != $row->TelefContacto)  {

$sql2 = " UPDATE centros SET  TelefContactoe=:tel  WHERE NombreContacto =:usuario ";
$stmt2 = $con->prepare($sql2);
$stmt2->bindParam(':tel', $tel, PDO::PARAM_STR); 
$stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt2->execute();

}



}































$sql = "INSERT INTO centros (nombre,direccion, tipo,telefono,pais, ciudad,descripcion,NombreContacto,CorreoContacto,TelefContacto,img) VALUES (:nombre,:direccion,:tipo, :telefono, :pais,:ciudad,:descripcion,:contacto,:correo, :tel, :nombre_img)";
$stmt = $con->prepare($sql);
$stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
$stmt->bindParam(':direccion', $direccion, PDO::PARAM_STR);
$stmt->bindParam(':tipo', $tipo, PDO::PARAM_STR);
$stmt->bindParam(':telefono', $telefono, PDO::PARAM_STR); 
$stmt->bindParam(':pais', $pais, PDO::PARAM_STR); 
$stmt->bindParam(':ciudad', $ciudad, PDO::PARAM_STR);
$stmt->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
$stmt->bindParam(':contacto', $contacto, PDO::PARAM_STR);
$stmt->bindParam(':correo', $correo, PDO::PARAM_STR);
$stmt->bindParam(':tel', $tel, PDO::PARAM_STR);
$stmt->bindParam(':nombre_img', $nombre_img, PDO::PARAM_STR);
 
$stmt->execute();

 
?>

<script>
alert('El Centro a sido agregado exitosamaente');
window.location.href='nuevo-centro.php';
</script>

</body>
<html>