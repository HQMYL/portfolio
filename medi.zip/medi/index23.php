<!DOCTYPE html>
<html lang="es">
<?php
session_start();
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
?>
    <head>
        <meta charset="UTF-8" />
		<meta name="description" content="	MedicalJob, bolsa de empleo con ofertas de trabajo, congresos y cursos de enfermera, médico y auxiliar en enfermería en el sector de salud
" />
		        <title>	MedicalJob, bolsa de empleo con ofertas de trabajo en sector de salud
</title>
        <!--[if lt IE 9]>
        	<script src="/bundles/comun/js/html5shiv.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
                <link rel="stylesheet" type="text/css" href="css2/css.css" />
        	<link rel="stylesheet" type="text/css" href="css2/reset.css" />
    <link rel="stylesheet" type="text/css" href="css2/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css2/frontend.css" />
	<link rel="stylesheet" type="text/css" href="css2/forms.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery.fancybox.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery-ui-1.10.3.custom.min.css" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="apple-touch-icon" sizes="114x114" href="" />
        <link rel="apple-touch-icon" sizes="72x72" href="" />
        <link rel="apple-touch-icon" href="" />
        <style type="text/css">
        	.u {
        		font-size: 15px;
        	}
        	#per {
        		font-size: 15px;
        	}
        </style>
    </head>
    <body itemscope itemtype="http://schema.org/WebPage">
		<div id="cargando" style="display:none"></div>
		    				        		<div id="pagina">
		<header id="header">
			<div id="banner">
				<img class="img-responsive img-thumbnail" src="img/log.jpg" alt="Mediempleo: Trabaja en el sector sanitario en cualquier parte del mundo" />
			</div>
					</header>
		<div id="contenido">
			<div id="breadcrumb" itemprop="breadcrumb">
			 <a href=""><a href="/"><span class="glyphicon glyphicon-home"></span> Inicio</a> 			</div>
					
			<aside id="sidebar">
							<div id="contadores">
	<div class="contador contador-profesionales">
		<div class="cifra-contador">
			<?php
			$sql = "SELECT * FROM usuarios"; 
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
$total = 0;
foreach ($rows as $row) {
$total = $total + 1;
}
?>
			<strong><?php echo $total; ?></strong>
		</div>
		<div class="texto-contador">profesionales<br />sanitarios</div>
	</div>
	<div class="contador contador-empresas">
		<div class="cifra-contador">
			<?php
			$sql = "SELECT * FROM empresas"; 
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
$total = 0;
foreach ($rows as $row) {
$total = $total + 1;
}
?>
			<strong><?php echo $total; ?></strong>
		</div>
		<div class="texto-contador">centros y<br />empresas</div>
	</div>
	</div>									<h2 class="titulo-sidebar-box"></h2>
					<div class="sidebar-box">
						

					</div>
					
					<div class="sidebar-box sidebar-box-bordered">
						 <p style="color: #333;" class="u"><?php echo "Bienvenido: " .$usuario; ?></p>
                         <a id="per" style="color: #333;" href="editar.php" class="btn-danger">Editar Perfil</a><br>
                         <a id="per" style="color: #333;" href="logout.php" class="btn-danger">Cerrar Sesión</a>	
					</div>
									 
						
						<img width="200" height="200" src="img/italiano.png">
					
        									</aside>
		
			<div id="content-right">
				<div style="float:left;width:100%">
	</div>					<article id="acciones-mediempleo">
<figure class="width-33">
			<a href="/centros-empresas/publicar-ofertas" title="Te ayudamos a encontrar al mejor profesional">
				<img class="img-responsive img-thumbnail" src="img/publica.png" alt="Te ayudamos a encontrar al mejor profesional" title="Te ayudamos a encontrar al mejor profesional" width="90%" style="margin-left:5%;" />
			</a>
		</figure>
		<figure class="width-33">
			<a href="ofertas-empleos.php" title="Listado de todas las Ofertas actualizadas por especialidad">
				<img class="img-responsive img-thumbnail" src="img/inscribete.png" alt="Listado de todas las Ofertas actualizadas por especialidad" title="Listado de todas las Ofertas actualizadas por especialidad" width="90%" style="margin-left:5%;" />
			</a>
		</figure>
		<figure class="width-33">
			<a href="oposiciones.php" title="Oposiciones y material actualizado para prepararse">
				<img class="img-responsive img-thumbnail" src="img/inscribete-opos.png" alt="Oposiciones y material actualizado para prepararse" title="Oposiciones y material actualizado para prepararse" width="90%" style="margin-left:5%;" />
			</a>
		</figure>


		

		
	</article>
	<article id="empresa-sanitario-index" class="categoria-index">
        		
		<section class="wiki-categoria-index empresa">
			<h2>
				Si soy <strong>centro o empresa</strong><br />
				¿Cómo me ayuda MedicalJob?
			</h2>
			<div class="texto-wiki">
				<div class="bloque-wiki left">
					<img class="img-responsive img-thumbnail" width="100" height="100" src="img/ejecutivo.jpg" alt="Logo de Publica ofertas gratis" title="Publica ofertas gratis" />
					<h3>Publica ofertas gratis</h3>
					<p>
						Medijob es el único portal de empleo dedicado
						100% al sector sanitario en donde puedes publicar
						tus ofertas de manera totalmente gratuita de forma
						sencilla y eficaz.<br />
						<a href="/alta-empresa">
							<strong>Regístrate y empieza a publicar tus ofertas ahora.</strong>
						</a>
					</p>
				</div>
				
				<div class="bloque-wiki right">
					<img  class="img-responsive img-thumbnail" width="100" height="100"  src="img/tiro.jpg" alt="Logo de Encuentra tu candidato ideal" title="Encuentra tu candidato ideal" />
					<h3>Encuentra tu candidato ideal</h3>
					<p>
						Realiza búsquedas de manera gratuita entre
						nuestros más de 31.000 profesionales sanitarios
						registrados y sólo paga por los que te interesen.<br />
                        <a href="/centros-empresas">
                            <strong>Leer más</strong>
                        </a>
					</p>
				</div>
				
				<div class="bloque-wiki left">
					<img class="img-responsive img-thumbnail" width="100" height="100"  src="img/candidato.jpg" alt="Logo de Tu primer candidato gratis" title="Tu primer candidato gratis" />
					<h3>Tu primer candidato gratis</h3>
					<p>
						¿Eres nuevo en Medijob? Sólo por registrarte
						podrás ver los datos de tu primer candidato
						gratuitamente.
					</p>
				</div>
			</div>
		</section>
	</article>
	
	<article id="profesional-sanitario-index" class="categoria-index">
        		
		<section class="wiki-categoria-index profesional-sanitario">
			<h2>
				Si soy <strong>profesional sanitario</strong><br />
				¿Cómo me ayuda MedicalJob?
			</h2>
			<div class="texto-wiki">
				<div class="bloque-wiki left">
					<img class="img-responsive img-thumbnail" width="100" height="100" src="img/ofertas.jpg" alt="Logo de Ofertas de empleo exclusivas" title="Ofertas de empleo exclusivas" />
					<h3>Ofertas de empleo exclusivas</h3>
					<p>
						Medicaljob te da la oportunidad de acceder de 
						forma gratuita a la única bolsa de trabajo 100% 
						dedicada al mundo sanitario.<br />
						
					</p>
				</div>
				
				<div class="bloque-wiki right">
					<img class="img-responsive img-thumbnail" src="img/notebook.jpg" width="100" height="100" alt="Logo de Actualidad laboral" title="Actualidad laboral" />
					<h3>Te informamos On line</h3>
					<p>
						Para que no pierdas ninguna oportunidad, cuando recibamos una oferta que coincida con tus preferencias y tu curriculum te la enviaremos si quieres a tu email para que tu decidas si te quieres registrar
					</p>
				</div>
				
				<div class="bloque-wiki left">
					<img class="img-responsive img-thumbnail" src="img/mano.jpg" width="100" height="100" alt="Logo de Oferta formativa" title="Oferta formativa" style="margin-top:18px"/>
					<h3>Contacto directo con el contratante</h3>
					<p>
						Registrate a las ofertas que te interesen  y tu curriculum irá directo a la persona que tomará la decisión de contratar o de presentarte como candidato. No pierdas tiempo e ilusión!
					</p>
				</div>
				<div class="bloque-wiki left">
					<img class="img-responsive img-thumbnail" src="img/mano.jpg" width="100" height="100" alt="Logo de Oferta formativa" title="Oferta formativa" style="margin-top:18px"/>
					<h3>Curriculum con chequeo de Datos</h3>
					<p>
						Registrate a las ofertas que te interesen  y tu curriculum irá directo a la persona que tomará la decisión de contratar o de presentarte como candidato. No pierdas tiempo e ilusión!
					</p>
				</div>
			</div>
		</section>
	</article>
				</div>
		</div>
		<footer id="footer">	
	<div id="container-footer-especialidades">
			<div class="footer-box">
			<ul class="footer-box-list">
				
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				
							</ul>
		</div>
		
		
	</div>
	<div id="footer-aside">
		<div class="footer-box">
			<ul class="footer-box-list">
				
			</ul>
		</div>
		<div class="footer-box">
			<ul class="footer-box-list">
				
			</ul>
		</div>
		<figure id="logo-footer">
			<img src="/bundles/comun/img/logo-footer.jpg" alt="Logo de Mediempleo" title="Mediempleo, tu web de empleo médico" width="90%" />
		</figure>
		<div id="info-footer">
			<b>Copyright &copy; 2017 </b><br />
			<a href="/informacion-legal">Información legal</a><br />
			<a href="/politica-privacidad">Política de privacidad</a> |
			<a href="/normativa">Normativa</a> |
			<a href="/contacto">Contacto</a>
		</div>	
	</div>
	
		
</footer>	</div>
                	
                <script type="text/javascript">
	  		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
				(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
				m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
			ga('create', 'UA-40029850-1', 'mediempleo.com');
			ga('send', 'pageview');
		</script>
        	<script src="js2/router.js"></script>
	<script src="js2/routing?callback=fos.Router.setData"></script>
	<script src="js2/jquery-1.9.1.min.js"></script>
    <script src="js2/jquery-ui-1.10.3.custom.min.js"></script>
	<script src="js2/frontend.js"></script>
	<script src="js2/bootstrap.js"></script>
    <script src="js2/angular.min.js"></script>
    <script src="js2/ng-table.js"></script>
	<script type="text/javascript" src="js2/jquery.fancybox.pack.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$("a[rel='fancybox']").fancybox({
				'transitionIn'	:	'elastic',
				'transitionOut'	:	'elastic',
				'speedIn'		:	600, 
				'speedOut'		:	200, 
				'overlayShow'	:	true,
				'type'			:	'iframe',
				'showNavArrows': 	false
			});
		});
	</script>
        <script type="text/javascript">
			$(document).ready(function(){
				$("#acepta-cookies").on("click", function(){
					var dias = 365*60*60*24*1000;
					var hoy = new Date();
			        var fecha_expira = new Date( hoy.getTime() + (dias) );
			        var cookieString = "cookies_agreement=1" + ";expires=" + fecha_expira.toGMTString();
					window.document.cookie = cookieString
					$("#cookies-bar").css('position','relative')
					$("#cookies-bar").slideDown(1200, function(){
						$(this).remove();
					});
				});

				$("#select-usuario").on("change", function(){
					$("#admin-usuario").val($(this).val());
				});
			});
        </script>
    </body>
</html>