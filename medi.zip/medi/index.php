<!DOCTYPE html>
<html lang="es">
<?php
session_start();
$total = "";
$tipo = "";
include("conexion.php");
$usuario = "";
if(isset($_SESSION['usuario'])) {
$usuario = $_SESSION['usuario'];}
?>
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="	MedicalJob, bolsa de empleo con ofertas de trabajo, congresos y cursos de enfermera, médico y auxiliar en enfermería en el sector de salud
" />
		        <title>	MedicalJob, bolsa de empleo con ofertas de trabajo en sector de salud
</title>
        <!--[if lt IE 9]>
        	<script src="/bundles/comun/js/html5shiv.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
                <link rel="stylesheet" type="text/css" href="css2/css.css" />
        	<link rel="stylesheet" type="text/css" href="css2/reset.css" />
    <link rel="stylesheet" type="text/css" href="css2/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css2/frontend.css" />
	<link rel="stylesheet" type="text/css" href="css2/forms.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery.fancybox.css" />
	<link rel="stylesheet" type="text/css" href="css2/jquery-ui-1.10.3.custom.min.css" />
	<link rel="stylesheet" type="text/css" href="css3/new.css" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="icon" type="image/x-icon" href="" />
        <link rel="apple-touch-icon" sizes="114x114" href="" />
        <link rel="apple-touch-icon" sizes="72x72" href="" />
        <link rel="apple-touch-icon" href="" />
        <style type="text/css">

        body {
	background-color: #FFFF00;
}
        	#pagina {
width: 95%;	
}

.col-lg-1 {
	width: 16%;
}



.jk {
	text-align: center;
	color: #333;
}

.btn, .btn-danger {
	float: right;
}
        </style>
    </head>
    <body itemscope itemtype="http://schema.org/WebPage">
		<div id="cargando" style="display:none"></div>
		    				        		<div id="pagina">
		<header id="header">
			<div id="banner">
				<img class="img-responsive img-thumbnail" src="img/portada.jpg" alt="MedicalJob: Trabaja en el sector sanitario en cualquier parte del mundo" />
			</div>
					</header>
		<div id="contenido">
			<div id="breadcrumb" itemprop="breadcrumb">
			 <a href=""><a href="index.php"><span class="glyphicon glyphicon-home"></span> Inicio</a> 			</div>
					
			<aside id="sidebar">
							<div id="contadores">
	<div class="contador contador-profesionales">
		<div class="cifra-contador">
			<?php
			$total = 0;
			$tipo = "Profesional";
			$sth = $con->prepare("SELECT * FROM usuarios WHERE tipo = ?");
$sth->bindParam(1, $tipo);

$sth->execute();

if ($sth->rowCount() > 0) {

foreach ($sth as $row ) {
	$total = $total +1;

}
}
?>
			<strong><?php echo $total; ?></strong>
		</div>
		<div class="texto-contador">profesionales<br />sanitarios</div>
	</div>
	<div class="contador contador-empresas">
		<div class="cifra-contador">
			<?php
			$sql = "SELECT * FROM empresas"; 
$stmt = $con->prepare($sql);
$results = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
$total = 0;
foreach ($rows as $row) {
$total = $total + 1;
}
?>
			<strong><?php echo $total; ?></strong>
		</div>
		<div class="texto-contador">centros y<br />empresas</div>
	</div>
	</div>									<h2 class="titulo-sidebar-box">REGÍSTRATE, ES GRATIS</h2>
					<div class="sidebar-box">
						<a  href="usuario.php" class="boton-registro boton-registro-profesionales">
	soy <br />profesional <br />sanitario
</a>
<a href="empresa.php" class="boton-registro boton-registro-empresas">
	soy <br />centro o <br />empresa
</a>
					</div>
					<h2 class="titulo-sidebar-box">ACCEDE A TU CUENTA</h2>
					<div class="sidebar-box sidebar-box-bordered">
						 
	<form id="formul" name="formul" action="validar.php" method="post" style="width:90%;margin:10px auto">
		<div class="form-widget-container">
			<label for="input-login">USUARIO</label>
			<input type="text"  id="user" name="user" class="text-input-border" />
		</div>
		<div class="form-widget-container">
			<label for="input-password">CONTRASEÑA</label>
			<input type="password"  id="pass" name="pass" class="text-input-border" />
		</div><br>
		<div class="form-widget-container">
			<input type="checkbox" id="input-remember-me" name="_remember_me" checked />
			<label id="recuerdame" for="input-remember-me">No cerrar sesión</label>
			<button type="submit" class="btn btn-danger">Acceder</button>
		</div>
		<div class="form-widget-container">			
			<p><strong style="font-size:9px"><a href="recuperar-contrasena.html">¿Olvidaste tu contraseña?</a></strong></p>
		</div>
	</form>
					</div>
	
  <!-- CARRUSEL -->

 <section>
                  
                  <div id="slider-container">
                      <div id="slider-box">
                          <div class="slider-element">
                              <article class="element-red">
                              <img class="img-responsive img-thumbnail" src="img/italiano.png">  
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-green">
                               <img class="img-responsive img-thumbnail" src="img/cposgrado.jpg">     
                              </article>
                          </div>
                          <div class="slider-element">
                              <article class="element-blue">
                                <img class="img-responsive img-thumbnail" src="img/cruz.png">  
                              </article>                            
                          </div>
                      </div>
                  </div>
                  
              </section>        


       <!-- CARRUSEL -->




			 
</aside>
		
			<div id="content-right">
				<div style="float:left;width:100%">
	</div>		<article id="acciones-mediempleo">
		<!-- INICIO CONTAINER EJ -->
	
<div class="container">
        
      <div class="row">
        <div class="col-lg-1">
          
			<a href="publicar-ofertas.php" title="Te ayudamos a encontrar al mejor profesional">
				<img class="img-responsive img-thumbnail" src="img/publica.png" alt="Información Publicaciones" title="Publica tu Oferta" width="100%" style="margin-left:5%;" />
			</a>
		
        </div>
        <div class="col-lg-1">
        
			<a href="oposiciones.php" title="Listado de Oposiciones">
				<img class="img-responsive img-thumbnail" src="img/inscribete-opos.png" alt="Listado de Oposiciones" title="Te ayudamos a encontrar al mejor profesional" width="100%" style="margin-left:5%;" />
			</a>
		
            
      </div>

        <div class="col-lg-1">
        
			<a href="lista-ofertas.php" title="Listado de Ofertas">
				<img class="img-responsive img-thumbnail" src="img/inscribete.png" alt="Listado de Ofertas" title="Listado de Ofertas" width="100%" style="margin-left:5%;" />
			</a>
		
            
      </div>



<div class="col-lg-1">
        
			<a href="bibliografia-ponencias.php" title="Bibliografía y Ponencias">
				<img class="img-responsive img-thumbnail" src="img/biblio.jpg" alt="Bibliografía y Ponencias" title="Bibliografía y Ponencias" width="100%" style="margin-left:5%;" />
			</a>
		        
      </div>

<div class="col-lg-1">
        
			<a href="material-medico.php" title="Equipos y material Médico">
				<img class="img-responsive img-thumbnail" src="img/equipo.jpg" alt="Equipos y material Médico" title="Equipos y material Médico" width="100%" style="margin-left:5%;" />
			</a>
		        
      </div>

    </div> <!-- FINAL ROW -->
</div>
 <!-- FINAL JUMBOTRON -->
<!-- FINAL CONTAINER EJ -->

	</article>

	<article id="empresa-sanitario-index" class="categoria-index">
        		
		<section class="wiki-categoria-index empresa">
			<h2>
				Si soy <strong>centro o empresa</strong><br />
				¿Cómo me ayuda MedicalJob?
			</h2>
			<div class="texto-wiki">
				<div class="bloque-wiki left">
					<img class="img-responsive img-thumbnail" width="100" height="100" src="img/ejecutivo.jpg" alt="Logo de Publica ofertas gratis" title="Publica ofertas gratis" />
					<h3>Publica ofertas gratis</h3>
					<p>
						MedicalJob es el único portal de empleo dedicado
						100% al sector sanitario en donde puedes publicar
						tus ofertas de manera totalmente gratuita de forma
						sencilla y eficaz.<br />
						<a href="empresa.php">
							<strong>Regístrate y empieza a publicar tus ofertas ahora.</strong>
						</a>
					</p>
				</div>
				
				<div class="bloque-wiki right">
					<img  class="img-responsive img-thumbnail" width="100" height="100"  src="img/tiro.jpg" alt="Logo de Encuentra tu candidato ideal" title="Encuentra tu candidato ideal" />
					<h3>Encuentra tu candidato ideal</h3>
					<p>
						Realiza búsquedas de manera gratuita entre
						nuestros más de 31.000 profesionales sanitarios
						registrados y sólo paga por los que te interesen.<br />
                        <a href="centros-empresas.php">
                            <strong>Leer más</strong>
                        </a>
					</p>
				</div>
				
				<div class="bloque-wiki left">
					<img class="img-responsive img-thumbnail" width="100" height="100"  src="img/candidato.jpg" alt="Logo de Tu primer candidato gratis" title="Tu primer candidato gratis" />
					<h3>Tu primer candidato gratis</h3>
					<p>
						¿Eres nuevo en Medijob? Sólo por registrarte
						podrás ver los datos de tu primer candidato
						gratuitamente.
					</p>
				</div>
			</div>
		</section>
	</article>
	
	<article id="profesional-sanitario-index" class="categoria-index">
        		
		<section class="wiki-categoria-index profesional-sanitario">
			<h2>
				Si soy <strong>profesional sanitario</strong><br />
				¿Cómo me ayuda MedicalJob?
			</h2>
			<div class="texto-wiki">
				<div class="bloque-wiki left">
					<img class="img-responsive img-thumbnail" width="100" height="100" src="img/ofertas.jpg" alt="Logo de Ofertas de empleo exclusivas" title="Ofertas de empleo exclusivas" />
					<h3>Ofertas de empleo exclusivas</h3>
					<p>
						Medicaljob te da la oportunidad de acceder de 
						forma gratuita a la única bolsa de trabajo 100% 
						dedicada al mundo sanitario.<br />
						
					</p>
				</div>
				
				<div class="bloque-wiki right">
					<img class="img-responsive img-thumbnail" src="img/notebook.jpg" width="100" height="100" alt="Logo de Actualidad laboral" title="Actualidad laboral" />
					<h3>Te informamos On line</h3>
					<p>
						Para que no pierdas ninguna oportunidad, cuando recibamos una oferta que coincida con tus preferencias y tu curriculum te la enviaremos si quieres a tu email para que tu decidas si te quieres registrar
					</p>
				</div>
				
				<div class="bloque-wiki left">
					<img class="img-responsive img-thumbnail" src="img/mano.jpg" width="100" height="100" alt="Logo de Oferta formativa" title="Oferta formativa" style="margin-top:18px"/>
					<h3>Contacto directo con el contratante</h3>
					<p>
						Registrate a las ofertas que te interesen  y tu curriculum irá directo a la persona que tomará la decisión de contratar o de presentarte como candidato. No pierdas tiempo e ilusión!
					</p>
				</div>
				<div class="bloque-wiki left">
					<img class="img-responsive img-thumbnail" src="img/lupa.jpg" width="100" height="100" alt="Logo de Oferta formativa" title="Oferta formativa" style="margin-top:18px"/>
					<h3>Curriculum con chequeo de Datos</h3>
					<p>
						Registrate a las ofertas que te interesen  y tu curriculum irá directo a la persona que tomará la decisión de contratar o de presentarte como candidato. No pierdas tiempo e ilusión!
					</p>
				</div>
			</div>
		</section>
	</article>
				</div>
		</div>
		<footer id="footer">	
	<div id="container-footer-especialidades">
			<div class="footer-box">
			<ul class="footer-box-list">
				
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
							</ul>
		</div>
			<div class="footer-box">
			<ul class="footer-box-list">
				
							</ul>
		</div>
		
		
	</div>
	<div id="footer-aside">
		<div class="footer-box">
			<ul class="footer-box-list">
				
			</ul>
		</div>
		<div class="footer-box">
			<ul class="footer-box-list">
				
			</ul>
		</div>
		<figure id="logo-footer">
			<img class="img-responsive img-thumbnail" src="img/log.jpg" alt="Logo de MedicalJob" title="MedicalJob, tu web de empleo médico" width="90%" />
		</figure>
		<div id="info-footer">
			<b>Copyright &copy; 2018 </b><br />
			<a href="informacion-legal.php">Información legal</a><br />
			<a href="politica-privacidad.php">Política de privacidad</a> |
			<a href="normativa.php">Normativa</a> |
			<a href="contacto.php">Contacto</a>
		</div>	
	</div>
	
		
</footer>	</div>
                	
               
        	<script src="js2/router.js"></script>
	<script src="js2/routing?callback=fos.Router.setData"></script>
	<script src="js2/jquery-1.9.1.min.js"></script>
    <script src="js2/jquery-ui-1.10.3.custom.min.js"></script>
	<script src="js2/frontend.js"></script>
	<script src="js2/bootstrap.js"></script>
    <script src="js2/angular.min.js"></script>
    <script src="js2/ng-table.js"></script>
	<script type="text/javascript" src="js2/jquery.fancybox.pack.js"></script>
	



	<script type="text/javascript">
		$(document).ready(function(){
			$("a[rel='fancybox']").fancybox({
				'transitionIn'	:	'elastic',
				'transitionOut'	:	'elastic',
				'speedIn'		:	600, 
				'speedOut'		:	200, 
				'overlayShow'	:	true,
				'type'			:	'iframe',
				'showNavArrows': 	false
			});
		});
	</script>
        
    </body>
</html>